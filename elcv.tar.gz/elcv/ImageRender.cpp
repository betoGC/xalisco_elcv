/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Definition of ImageRender class functions.
//
// 2015: Roberto Flores-Moreno
// ******************************************************************

#include <QtWidgets>

#include <QtOpenGL/QGLWidget>
#include <ImageRender.h>
#include <Panel.h>
#include <Viewer.h>
#include <Plotter.h>

ImageRender::ImageRender( Viewer *iviewer )
           : QWidget( 0 ) 
{
  viewer = iviewer;
  QVBoxLayout *mainLayout = new QVBoxLayout;

  QGroupBox *labelGroupBox = new QGroupBox(tr("Label"));
  QHBoxLayout *labellayout = new QHBoxLayout;
  label = new QLineEdit( labelGroupBox ); 
  label->setText( QString( "Xalisco" ) ); 
  labellayout->addWidget( label );
  labelGroupBox->setLayout( labellayout );
  mainLayout->addWidget( labelGroupBox );

  QGroupBox *horizontalGroupBox = new QGroupBox(tr("Axis"));
  QHBoxLayout *axislayout = new QHBoxLayout;
  for (int i = 0; i < 3; i++) 
  {
    axised[i] = new QLineEdit( horizontalGroupBox ); 
    axised[i]->setText( QString::number( 1.0 ) ); 
    axislayout->addWidget( axised[i] );
  };
  horizontalGroupBox->setLayout( axislayout );
  mainLayout->addWidget( horizontalGroupBox );

  QHBoxLayout *descLayout = new QHBoxLayout;
  formatCombo = new QComboBox;
  formatCombo->addItem( QString( "PNG" ));
  descLayout->addWidget( formatCombo );
  connect( formatCombo, SIGNAL(activated(const QString &)),
           this, SLOT( ChangeFormat(const QString &)));

  QPushButton *writeB = new QPushButton( tr("Write") );
  connect( writeB, SIGNAL(clicked()), this, SLOT(Write()));
  descLayout->addWidget( writeB );

  QPushButton *doneB = new QPushButton( tr("Done") );
  connect( doneB, SIGNAL(clicked()), this, SLOT(close()));
  descLayout->addWidget( doneB );

  mainLayout->addLayout( descLayout );
  setLayout( mainLayout );

  setWindowTitle( "Image Renderer" );
}

ImageRender::~ImageRender()
{
}

bool ImageRender::GetFileName( char* format )
{
  QString initialPath = QDir::currentPath();
  QString fn = QFileDialog::getSaveFileName(this, 
  "Save Image to File", initialPath,format);
  if ( fn.isEmpty() || fn.isNull() ) 
  {
    return false;
  }
  else
  {
    sprintf(filename,"%s",(fn.toLatin1()).data());
    return true;
  }
}

void ImageRender::ChangeFormat( const QString& newfmt )
{
  axised[0]->setEnabled( false );
  axised[1]->setEnabled( false );
  axised[2]->setEnabled( false );
}

void ImageRender::Write( )
{
  viewer->plotter->use_lists = false;

  QString text = formatCombo->currentText();
  char format[64];
  sprintf( format , "%s", ((text.toLower()).toLatin1()).data() );
  if ( GetFileName( format ) )
  {
    viewer->panel->Report( "Writing %s image file %s ...",
                           format ,  filename );
    QPixmap pixmap = viewer->renderPixmap(viewer->width(), 
                                          viewer->height());
    pixmap.save( filename , format , 0 );
    viewer->panel->Report( "Writing %s image file %s ... DONE",
                           format , filename);
  };

  viewer->plotter->use_lists = true;
}


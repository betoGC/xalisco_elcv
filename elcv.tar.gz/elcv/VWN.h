/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#ifndef X_VWN_H
#define X_VWN_H

extern double VWN_energy(double*);
extern double VWN_potential(double*,int);
extern double VWN_kernel(double*,int,int);

#endif

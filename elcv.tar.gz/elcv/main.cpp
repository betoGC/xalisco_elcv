/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Xalisco software
//
// 2015: Roberto Flores Moreno
// ******************************************************************

#include <iostream>
#include <iomanip>

#include <Xalisco.h>
#include <JobManager.h>
#include <System.h>
#include <Molecular.h>
#include <Bessel.h>
#include <Harmonic.h>
#include <Integrator.h>

using namespace std;

int main(int argc, char **argv)
{
  System* sys = new System();

  Xalisco* xal = new Xalisco( sys, argc , argv );
  if (!(xal->status & QUEUED)) xal->exec();

  if (xal->status & QUEUED)
  {
    JobManager* jm = new JobManager( sys , xal->input_file );
    jm->Run();
  } 

  delete xal;

  return 0;
}

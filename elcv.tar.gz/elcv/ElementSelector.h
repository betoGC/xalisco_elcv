/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Declaration of class ElementSelector 
//
// 2003-2012: Roberto Flores-Moreno
// ******************************************************************

#ifndef X_ELEMENT_SELECTOR_H
#define X_ELEMENT_SELECTOR_H

#include <Parameter.h>

#include "qdialog.h"

class QToolButton;

class ElementSelector : public QDialog 
{
  Q_OBJECT

  public:
    ElementSelector( QWidget *parent = 0 , int guess=0 );

  public slots:
    void SetDefaultElement( void );
    int GetSelectedElement( void );

  protected:
    QToolButton *element[120]; 
    int selected_element;

};

#endif

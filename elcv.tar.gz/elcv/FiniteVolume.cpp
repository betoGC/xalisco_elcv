/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <stdlib.h>
#include <math.h>

#include <iostream>
#include <iomanip>

#include <Parameter.h>
#include <FiniteVolume.h>
#include <Chemistry.h>
#include <Species.h>
#include <Math.h>

using namespace std;

FiniteVolume::FiniteVolume(double *r, double vol, Chemistry *ichem)
            : Center( (char*)"FV", r[0], r[1], r[2] )
{
  int i;

  // Save pointer
  chem = ichem;
  volume = vol;

  // Make a copy of the concentrations
  for (i=0;i<chem->NumberOfSpecies();i++)
    concentration[i] = chem->specie[i]->Concentration();

  nneigh = 0;
}

void FiniteVolume::EvolveChemistry(double dt, double temperature, double voltage, double *charge_collected, bool has_electrode)
{
  int i;

  // Chemistry leads
  Chemistry *loc_chem = new Chemistry( *chem );
  for (i=0;i<loc_chem->NumberOfSpecies();i++)
    loc_chem->specie[i]->SetConcentration( concentration[i] );
  loc_chem->Evolve(temperature,voltage,dt,charge_collected,has_electrode);
  for (i=0;i<loc_chem->NumberOfSpecies();i++)
    concentration[i] = loc_chem->specie[i]->Concentration();
  delete loc_chem;
}

void FiniteVolume::EvolveTransport(double dt)
{
  int i,ineigh;
  double der,dist,local_dt,t,xx,yy,zz;

  // Transport phenomena
  for (i=0;i<chem->NumberOfSpecies();i++)
    concentration_estimate[i] = 0.0;

  for (ineigh=0;ineigh<nneigh;ineigh++)
  {
    // FIXME: Assuming x direction
    xx = neigh[ineigh]->x - x;
    //yy = neigh[ineigh]->y - y;
    //zz = neigh[ineigh]->z - z;
    //dist = shared_area[ineigh]/sqrt(xx*xx+yy*yy+zz*zz); 
    dist = shared_area[ineigh]/(X_ABS(xx)*volume); 
    for (i=0;i<chem->NumberOfSpecies();i++)
    {
      // Make sure NOT to "transport" electrons
      if (!chem->specie[i]->IsElectron())   
      {
        der = (neigh[ineigh]->concentration[i] - concentration[i])*dist;
        der *= chem->specie[i]->DiffusionCoefficient();
        concentration_estimate[i] += der*dt;
      }
    }
  }
}

void FiniteVolume::Save()
{
  int i;

  for (i=0;i<chem->NumberOfSpecies();i++)
  {
    concentration[i] += concentration_estimate[i];
    if (concentration[i]<0.0) concentration[i] = 0.0; //FIXME
  }
}

void FiniteVolume::AddNeighbor(FiniteVolume *other, double area)
{
  if (nneigh>=X_MAX_N_NEIGH)
  {
    cout << "Maximum number of neighbors reached"<<endl;
    return;
  }
  neigh[nneigh] = other; 
  shared_area[nneigh] = area;
  nneigh++;
}

void FiniteVolume::Show()
{
  int i;
  return;
  cout << "Elementos "<<endl;
  for (i=0;i<chem->NumberOfSpecies();i++)
    cout << i << "  "<< fixed << setw(15) << setprecision(10) << concentration[i]<<endl;
}


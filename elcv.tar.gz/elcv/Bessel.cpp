/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// R. Flores-Moreno, R. J. Alvarez-Mendez, A. Vela, A. M. Koster
// J. Comput. Chem. 27, 1009 (2006).
////////////////////////////////////////////
#include <math.h>

#include <iostream>

#include <Parameter.h>
#include <Bessel.h>
#include <Matrix.h>
#include <Xalisco.h>

using namespace std;

Bessel::Bessel(int lmax)
{
  // Pretabulation
  nztab = 16*100;         // Inherited from old deMon implementation
  SKMSExpTab(lmax);
}

void Bessel::SKMSExp(int n, double z, double* K)
{
//     Purpose: Calculate exponential weighted modified spherical Bessel 
//              function K(z) for the semi-local ECP integrals.
//
//     Lit.: a) L.E. McMurchie, E. Davidson, J. Comp. Phys. 44, 289 (1981)
//           b) G. Arfken, H.J. Weber, Mathematical Methods for Physicists,
//              Fourth Edition, Academic Press London, 1995, pp. 688
//           c) R. Flores-Moreno, R. J. Alvarez-Mendez, A. Vela, A. M. Koster
//              J. Comput. Chem. 27, 1009 (2006).
//
//     History: - Creation (04.11.05, RFM)
//              - Translated to C (17.07.15, RFM)
//              - C version validated with old version (22.07.15, RFM) 
//
//     K(I): Vector with function values of K(z).
//     N   : Highest index for K(z).
//     Z   : Argument value of K(z) (>= 0).

  int i,j,l,m,loop;
  double fa,fb;
  double *a,*d;   

  // 1. z = 0 ==> Zero order approximation 
  double eps = 1.0e-7;
  if (z<=eps)
  {
    if (z<=0.0) 
    {
      K[0] = 1.0; 
      for (i=1;i<=n;i++)
        K[i] = 0.0; 
    }
    else
    {
      K[0] = 1.0 - z; 
      for (i=1;i<=n;i++)
        K[i] = K[i-1]*z/double(i+i+1);
    }
  }
  // 2. 0 < z < 16 ==> Taylor series expansion 
  else if (z<16.0)
  {
    a = new double[n+7];
    d = new double[n+7];

    loop = n + 5;
    fb = double(nztab/16);
    i = int(z*fb+0.5);
    fa = z - double(i)/fb;
    fb = 1.0;
    for (l=0;l<=loop;l++)
      d[l] = (*SKMSTab)(l,i);
    for (l=0;l<=n;l++)
      K[l] = d[l];
    for (i=1;i<=5;i++)
    {
      j = loop - i;
      // (I-1)th derivatives 
      m = j + 1;
      for (l=0;l<=m;l++)
        a[l] = d[l];
      // Calculate Ith derivatives
      d[0] = a[1] - a[0];
      for (l=1;l<=j;l++)
      {
        m = l + 1;
        d[l] = (double(l)/double(l+l+1))*(a[l-1]-a[m])-a[l]+a[m];
      }
      // Add term to funcion values
      fb *= fa/double(i);
      for (l=0;l<=n;l++)
        K[l] += fb*d[l];
    }
    delete[] a;
    delete[] d;
  }
  // 3. z > 16 ==> Asymptotic formula 
  else
  {
    a = new double[n+1];

    a[0] = 0.5/z;
    for (l=0;l<=n;l++)
      K[l] = a[0];
    for (l=1;l<=n;l++)
    {
      fa = double((l+1)*l);
      for (i=1;i<l;i++)
      {
        K[l] += fa*a[i];
        fa *= double((l+i+1)*(l-i));
      }
      a[l] = -a[0]*a[l-1]/double(l);
      K[l] += fa*a[l];
    }
    delete[] a;
  }
}


void Bessel::SKMSExpTab(int lmax)
{
//     Purpose: Calculation and tabulation of K(z) for Taylor series
//              expansion in BESFUN. The K(z) values are calculated
//              by a truncated series expansion.
//
//     History: - Creation (04.12.04, RFM).
//              - Translated to C (17.07.15, RFM)
//              - C version validated with old version (22.07.15, RFM) 
//
//     maxterm: Maximum mumber of terms in power series expansion.
//     SKMSTab: Table of K(z) values for Taylor expansion.
//     ztab   : Value of z.

  int i,l,m,n;
  double s,u,ztab;
  double *t,*f;
  int maxterm = 200;

  SKMSTab = new Matrix(lmax+7,nztab+1);
  SKMSTab->SetValue( 0, 0, 1.0 );

  t = new double[maxterm+1];
  f = new double[maxterm+1+lmax+6];

  // Loop over all points of K(z) 
  for (i=0;i<nztab;i++)
  {
    ztab = double(i)/double(nztab/16); 
    // Calculation of K(0) values 
    n = 0;
    u = ztab*ztab/2.0;
    f[n] = 1.0;
    t[n] = exp(-ztab);
    l = int(0.25*sqrt(1.0+16.0*u));
    // Series expansion 
    while ((t[n]/f[n]>X_TOL_NUM)||(n<=l))
    {
      SKMSTab->ShiftValue(0,i,t[n]/f[n]);
      n++;
      if (n>maxterm)
        cout << "ERROR in SKMSExpTab: K(z) SERIES IS NOT CONVERGED"<<endl;
      f[n] = f[n-1]*double(2*n+1);
      t[n] = t[n-1]*u/double(n);
    }
    for (l=1;l<=lmax+6;l++)
      f[n+l] = f[n+l-1]*double(2*n+2*l+1);
    // Calculation of K(m) with K(0) expansion 
    u = ztab;
    for (m=1;m<=lmax+6;m++)
    {
      s = 0.0;
      for (l=0;l<=n;l++)
        s += t[l]/f[l+m];
      SKMSTab->SetValue(m,i,u*s);
      u *= ztab;
    }
  }
}

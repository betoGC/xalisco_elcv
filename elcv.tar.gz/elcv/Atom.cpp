/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Definition of Atom
//
// 2015: Roberto Flores Moreno
// ******************************************************************

#include <ctype.h>
#include <stdlib.h>
#include <string.h>

#include <Atom.h>
#include <Center.h>
#include <Element.h>
#include <Units.h>

Atom::Atom(char* il,double x,double y, double z)
      : Center(il,x,y,z)
{
  atomic_number = SymbolToAtomicNumber( il );

  // notice that charge is set
  SetCharge( double(atomic_number) );
};

Atom::Atom(int an,double x,double y, double z)
      : Center((char*)ELEMENT_SYMBOL[an],x,y,z)
{
  atomic_number = an;

  // notice that charge is reset
  SetCharge( double(atomic_number) );
};

void Atom::SetAtomicNumber(int an)
{
  atomic_number = an;

  // notice that charge is reset
  SetCharge( double(atomic_number) );
}

void Atom::SetSymbol(char* is)
{
  atomic_number = SymbolToAtomicNumber( is );

  // notice that charge is reset
  SetCharge( double(atomic_number) );
}

void Atom::SetCharge(double c)
{
  charge = c;
}

double Atom::GetCovalentRadius(void)
{
  double r;

  r = ELEMENT_COV_R[atomic_number];

  return r;
};

double Atom::GetVDWRadius(void)
{
  double r;

  r = ELEMENT_VDW_R[atomic_number];

  return r;
};

static double color[3];
double* Atom::GetColor(void)
{
  //double color[3];

  color[0] = ELEMENT_COLOR[atomic_number][0];
  color[1] = ELEMENT_COLOR[atomic_number][1];
  color[2] = ELEMENT_COLOR[atomic_number][2];

  return color;
};

int Atom::SymbolToAtomicNumber( char *sym )
{
  int an = 0;
  char tst[3];

  if ( strlen(sym) == 0 )
  {
    return 0;
  }
  else
  {
    tst[0] = toupper(sym[0]);
    if ( strlen(sym) == 1 )
    {
      tst[1] = '\0';
    }
    else
    {
      if ( sym[1] >= '0' && sym[1] <= '9' )
      {
        tst[1] = '\0';
      }
      else
      {
        tst[1] = tolower(sym[1]);
        tst[2] = '\0';
      };
    };
  };

  for ( int i = 0 ; i <= X_MAX_ATOMIC_NUMBER ; i++ )
  {
    if ( strcmp( tst , ELEMENT_SYMBOL[i] ) == 0 )
    {
      an = i;
      break;
    };
  };
  return an;

}


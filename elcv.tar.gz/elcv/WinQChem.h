/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Declaration of class WinQChem
//
// 2012: Roberto Flores-Moreno
// ******************************************************************
#ifndef X_WIN_QCHEM_H
#define X_WIN_QCHEM_H

#include <QtGui>

#include <Parameter.h>
//Qt5 port
#include <QtWidgets/QToolButton>
class QComboBox;
class QCheckBox;
class QToolButton;
class QDoubleSpinBox;
class QTabWidget;

class System;
class Xalisco;
class WinSCF;
class WinIon;
class WinProp;
class WinPType;
class QChem;

class WinQChem : public QWidget 
{
  Q_OBJECT

  public:

    WinQChem(Xalisco*,System*);

    Xalisco *xalisco;
    WinSCF *winscf;
    WinIon *winion;
    WinProp *winprop;
    WinPType *wine;
    WinPType *winh;
    WinPType *wins;
    QChem *qchem;

  public slots:
 
    void Setup(void);

  protected:

    System* sys;

    QToolButton *setButton;
    QToolButton *stepButton;

    QTabWidget *tabWidget;
    QTabWidget *tabPType;
};

#endif // X_WIN_QCHEM_H


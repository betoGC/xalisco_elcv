/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <iostream>

#include <QtWidgets>

#include <Parameter.h>
#include <Math.h>
#include <WinRxns.h>   
#include <Chemistry.h>   
#include <Reaction.h>   
#include <Xalisco.h>

using namespace std;

WinRxns::WinRxns( Xalisco *ix, Chemistry *ichem)
      : QWidget( 0 )
{
  xalisco = ix;
  chem = ichem;

  timer = new QTimer(this);

  setWindowTitle( "Reactions" );
  tabWidget = new QTabWidget;

  QGridLayout *mainLayout = new QGridLayout;

  QToolButton *addButton =  new QToolButton( this );
  addButton->setText( "Add Reaction" ); 
  connect(addButton,SIGNAL(clicked()), this,SLOT(AddReaction())); 

  frame = new QWidget( 0 );
  tabWidget->addTab( frame , tr("Reactions") );

  mainLayout->addWidget( addButton       , 1 , 2 , 1, 1 );
  mainLayout->addWidget( tabWidget       , 2 , 0 , 6, 4 );
  setLayout( mainLayout );

  ListBox = new QTableWidget(X_MAX_N_REACTIONS,25);
  connect( ListBox , SIGNAL( itemChanged(QTableWidgetItem*) ), 
           this , SLOT( Edited( QTableWidgetItem*) ));
  QStringList Headers;

  QString MathSymbolDelta(0x0394);
  QString G ="G";
  MathSymbolDelta.append(G);

  QString MathSymbolLambda(0x03BB);
  MathSymbolLambda += "/";
  MathSymbolLambda += QString(0x03B1);

  Headers << "Id"      << "hetRxn"
          << MathSymbolDelta << MathSymbolLambda
          << "H_RP/k_std"
          << "Formula" << "Coefficient"
          << "Formula" << "Coefficient"
          << "Formula" << "Coefficient"
          << "Formula" << "Coefficient"
          << "Formula" << "Coefficient"
          << "Formula" << "Coefficient"
          << "Formula" << "Coefficient"
          << "Formula" << "Coefficient"
          << "Formula" << "Coefficient"
          << "Formula" << "Coefficient";

  ListBox->setHorizontalHeaderLabels(Headers);

  layout = new QVBoxLayout;
  layout->addWidget( ListBox );
  frame->setLayout( layout );

  rxn = new Reaction( chem );
  rxn->SetDeltaG( 44.55e3 );
  rxn->SetLambda( 23.49e3 );
  rxn->SetCoupling( 7.66e3 );
  (void) rxn->AddSpecies((char*)"A",-1.0);
  (void) rxn->AddSpecies((char*)"B",1.0);
  (void) rxn->AddSpecies((char*)"H",1.0);
  AddReaction();
  rxn = new Reaction( chem );
  rxn->SetDeltaG( -44.55e3 );
  rxn->SetLambda( 7.16e3 );
  rxn->SetCoupling( 7.66e3 );
  (void) rxn->AddSpecies((char*)"A",1.0);
  (void) rxn->AddSpecies((char*)"B",-1.0);
  (void) rxn->AddSpecies((char*)"H",-1.0);
  AddReaction();
  rxn = new Reaction( chem );
  rxn->SetDeltaG( 32.98e3 );
  rxn->SetLambda( 10.0 );
  rxn->SetCoupling( 440.0 );
  (void) rxn->AddSpecies((char*)"electron",1.0);
  (void) rxn->AddSpecies((char*)"B",-1.0);
  (void) rxn->AddSpecies((char*)"C",1.0);
  AddReaction();
  rxn = new Reaction( chem );
  rxn->SetDeltaG( -32.98e3 );
  rxn->SetLambda( 1.75e3 );
  rxn->SetCoupling( 440.0 );
  (void) rxn->AddSpecies((char*)"electron",-1.0);
  (void) rxn->AddSpecies((char*)"B",1.0);
  (void) rxn->AddSpecies((char*)"C",-1.0);
  AddReaction();
  rxn = new Reaction( chem );
  rxn->SetDeltaG( 25.34e3 );
  rxn->SetLambda( 5.71e3 );
  rxn->SetCoupling( 2.33e3 );
  (void) rxn->AddSpecies((char*)"C",-1.0);
  (void) rxn->AddSpecies((char*)"D",1.0);
  (void) rxn->AddSpecies((char*)"H",1.0);
  AddReaction();
  rxn = new Reaction( chem );
  rxn->SetDeltaG( -25.34e3 );
  rxn->SetLambda( 3.62e3 );
  rxn->SetCoupling( 2.33e3 );
  (void) rxn->AddSpecies((char*)"C",1.0);
  (void) rxn->AddSpecies((char*)"D",-1.0);
  (void) rxn->AddSpecies((char*)"H",-1.0);
  AddReaction();
  rxn = new Reaction( chem );
  rxn->SetDeltaG( 43.71e3 );
  rxn->SetLambda( 1.62e3 );
  rxn->SetCoupling( 410.0 );
  (void) rxn->AddSpecies((char*)"electron",1.0);
  (void) rxn->AddSpecies((char*)"D",-1.0);
  (void) rxn->AddSpecies((char*)"E",1.0);
  AddReaction();
  rxn = new Reaction( chem );
  rxn->SetDeltaG( -43.71e3 );
  rxn->SetLambda( 10.0 );
  rxn->SetCoupling( 410.0 );
  (void) rxn->AddSpecies((char*)"electron",-1.0);
  (void) rxn->AddSpecies((char*)"D",1.0);
  (void) rxn->AddSpecies((char*)"E",-1.0);
  AddReaction();
}

void WinRxns::AddReaction()
{
  int nrxn = chem->NumberOfReactions();

  char str[X_MAX_STR_SIZE];
  sprintf(str,"%d",nrxn);
  ListBox->setItem(nrxn,0, new QTableWidgetItem( QString(str) ));

  chem->AddReaction( rxn );
  Update(chem->reaction[nrxn],nrxn);
}

void WinRxns::Update(Reaction *rxn,int id)
{
  char str[X_MAX_STR_SIZE];

  disconnect( ListBox , SIGNAL( itemChanged(QTableWidgetItem*) ), 
           this , SLOT( Edited( QTableWidgetItem*) ));

  if (rxn->IsHeterogeneous())
    ListBox->setItem(id,1, new QTableWidgetItem(QString("true")));
  else
    ListBox->setItem(id,1, new QTableWidgetItem(QString("false")));
  sprintf(str,"%f",rxn->DeltaG());
  ListBox->setItem(id,2, new QTableWidgetItem(QString(str)));
  sprintf(str,"%f",rxn->Lambda());
  ListBox->setItem(id,3, new QTableWidgetItem(QString(str)));
  sprintf(str,"%f",rxn->Coupling());
  ListBox->setItem(id,4, new QTableWidgetItem(QString(str)));
  for (int i=0;i<rxn->NumberOfSpecies();i++)
  {
    sprintf(str,"%s",rxn->SpeciesName(i));
    ListBox->setItem(id,2*i+5, new QTableWidgetItem(QString(str)));
    sprintf(str,"%f",rxn->SpeciesCoefficient(i));
    ListBox->setItem(id,2*i+6, new QTableWidgetItem( QString(str)));
  }
  connect( ListBox , SIGNAL( itemChanged(QTableWidgetItem*) ), 
           this , SLOT( Edited( QTableWidgetItem*) ));
}

void WinRxns::Edited( QTableWidgetItem* item ) 
{
  int row = ListBox->currentRow();
  int col = ListBox->currentColumn();

  if (col<0||row<0) return;   // For acknowledgment of connection

  if (row>=(signed)chem->NumberOfReactions()) 
  {
    item->setText( QString( " " ) );
    return;
  }

  if ( col == 0 )
  {
    char str[X_MAX_STR_SIZE];
    sprintf(str,"%d",row);
    item->setText( QString( str ) );
  }
  else if ( col == 1 )
  {
    if (chem->reaction[row]->IsHeterogeneous())
      item->setText( QString( "true" ) );
    else
      item->setText( QString( "false" ) );
  }
  else if (col == 2 )
  {
    chem->reaction[row]->SetDeltaG((item->text().toDouble()));
  }
  else if (col == 3 )
  {
    chem->reaction[row]->SetLambda((item->text().toDouble()));
  }
  else if (col == 4 )
  {
    chem->reaction[row]->SetCoupling((item->text().toDouble()));
  }
  else if ( X_MOD(col,2) == 1 && col > 4 )
  {
    int nspec = chem->reaction[row]->NumberOfSpecies();
    int ispec = (col-5)/2;
    if (ispec>nspec) item->setText(QString(" "));
    else if (ispec==nspec) 
    {
      if (chem->reaction[row]->AddSpecies( (item->text().toLatin1()).data(),10.0))
        Update(chem->reaction[row],row);
      else
        xalisco->ErrorMessage(__FILE__,__LINE__,"Unknown species, edit again",0);
    }
    else
      if (!chem->reaction[row]->SetSpeciesByName(ispec,(item->text().toLatin1()).data()))
        xalisco->ErrorMessage(__FILE__,__LINE__,"Unknown species, edit again",0);
      else Update(chem->reaction[row],row);
/*
    // hetRxn is only informative, cannot be edited
    // and may change with any edition of species type
    if (chem->reaction[row]->IsHeterogeneous())
      ListBox->setItem(row,1, new QTableWidgetItem(QString("true")));
    else
      ListBox->setItem(row,1, new QTableWidgetItem(QString("false")));
*/
  }
  else if ( X_MOD(col,2) == 0 && col > 5 )
  {
    int nspec = chem->reaction[row]->NumberOfSpecies();
    int ispec = (col-5)/2;
    cout << "NSPEC = "<<nspec<< " ISPEC = "<<ispec<<endl;
    if (ispec>=nspec) item->setText(QString(" "));
    else
      chem->reaction[row]->SetSpeciesCoefficient(ispec,item->text().toDouble());
  }

}

// Reading from files is mediated by windows
// (File substitutes user, not window)
void WinRxns::Read(char* filename)
{
  size_t i,is,ns,nr;
  char line[X_MAX_STR_SIZE];
  double c;

  chem->reaction.clear();

  ifstream f(filename);
  while (f.getline(line,X_MAX_STR_SIZE))
  {
    string stringLine=line;
    int sindex=stringLine.find("Number of reactions:");
    if((sindex>=0)&&(sindex<(signed)stringLine.size()))
    { 
      nr = atoi(&line[20]);
      for (i=0;i<nr;i++)
      {
        rxn->Clear();
        f >> line; f >> line; f >> line; f >> c; rxn->SetDeltaG( c );
        f >> line; f >> line; f >> c; rxn->SetLambda( c );
        f >> line; f >> c; rxn->SetCoupling( c );
        f >> line; f >> line; f >> line; f >> ns; 
        for (is=0;is<ns;is++)
        { 
          
          f >> line; 
          f >> c;  
          rxn->AddSpecies( line , c );
        }
        AddReaction();
      }
    }
  }

  f.close();
}


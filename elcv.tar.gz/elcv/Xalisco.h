/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Declaration of class Xalisco
//
// 2015: Roberto Flores-Moreno
// ******************************************************************

#ifndef X_XALISCO_H
#define X_XALISCO_H
 
#include "qapplication.h"
 
#include <Parameter.h>

#define SFB    0x00000010L           // Selecting for bond
#define SFA    0x00000020L           // Selecting for angle
#define SFD    0x00000040L           // Selecting for dihedral
#define SFRV   0x00000080L           // Selecting for distance value
#define SFAV   0x00000100L           // Selecting for angle value
#define SFDV   0x00000200L           // Selecting for diheral value
#define SFSURF 0x00000400L           // Selecting for surface
#define SFPG   0x00000800L           // Selecting for point group
#define SFFV   0x00001000L           // Selecting for fitting value
#define SFPB   0x00002000L           
#define QUEUED 0x00004000L           // GUI has been switched off     
 
class Panel;
class ElementSelector;
class System;

class Xalisco : public QApplication 
{
  Q_OBJECT

  public:
    Xalisco( System*, int argc = 0, char *argv[] = 0);

    char input_file[X_MAX_STR_SIZE];
    long status;
 
    void SetCursor( const char* );
    void ErrorMessage(const char*, int, const char*, int);
    bool GetFileName(char*);
 
    System *sys;
    Panel *panel;

    ElementSelector *es;

  protected:

};
 
#endif // XALISCO_H

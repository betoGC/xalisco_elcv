/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <iostream>
#include <iomanip>

#include <Gradient.h>
#include <QChem.h>
#include <System.h>
#include <Molecular.h>
#include <GaussianGas.h>
#include <GaussianSet.h>
#include <GaussianShell.h>
#include <Atom.h>
#include <SCF.h>
#include <Vector.h>
#include <Integrator.h>

using namespace std;

Gradient::Gradient(QChem *iqchem)
{
  qchem = iqchem;
  sys = qchem->sys;
  gi = new Integrator();

  gradient.clear();
  for (int iatom=0;iatom<sys->mol->Natom();iatom++)
    gradient.push_back( Vector(0.0,0.0,0.0) );
};

// Debugging of gradients
// Roberto Flores-Moreno, Oct 2010
void Gradient::Test()
{
  int i,iatom,ig;
  double em,ep,gnum,shift;

  cout << "Testing gradients:"<<endl;
  cout << "============================================="<<endl;
  cout << "Index     Numerical   Analytical    Deviation"<<endl;
  cout << "---------------------------------------------"<<endl;

  shift = 0.01;
  for (iatom=0;iatom<sys->mol->Natom();iatom++)
  {
    cout << endl;
    for (i=0;i<3;i++)
    {
      (*sys->mol->atom[iatom])[i] += shift;
      for (ig=0;ig<sys->ngas;ig++)
      {
        (*sys->gas[ig]->basis[iatom])[i] += shift;
        (*sys->gas[ig]->auxis[iatom])[i] += shift;
        sys->gas[ig]->SetupSCF(qchem->method[sys->gas[ig]->type],(char*)"File",ig
            ,qchem->direct[sys->gas[ig]->type]);
      }
      qchem->scf->Setup();
      qchem->scf->SeekConvergence();
      if (!qchem->scf->Converged())
        cout << "WARNING: Gradient testing, SCF did not converged"<<endl;
      ep = qchem->SCFEnergy();

      (*sys->mol->atom[iatom])[i] -= 2.0*shift;
      for (ig=0;ig<sys->ngas;ig++)
      {
        (*sys->gas[ig]->basis[iatom])[i] -= 2.0*shift;
        (*sys->gas[ig]->auxis[iatom])[i] -= 2.0*shift;
        sys->gas[ig]->SetupSCF(qchem->method[sys->gas[ig]->type],(char*)"File",ig
            ,qchem->direct[sys->gas[ig]->type]);
      }
      qchem->scf->Setup();
      qchem->scf->SeekConvergence();
      if (!qchem->scf->Converged())
        cout << "WARNING: Gradient testing, SCF did not converged"<<endl;
      em = qchem->SCFEnergy();

      // Recover original
      (*sys->mol->atom[iatom])[i] += shift;
      for (ig=0;ig<sys->ngas;ig++)
      {
        (*sys->gas[ig]->basis[iatom])[i] += shift;
        (*sys->gas[ig]->auxis[iatom])[i] += shift;
        sys->gas[ig]->SetupSCF(qchem->method[sys->gas[ig]->type],
            (char*)"File",ig,qchem->direct[sys->gas[ig]->type]);
      }

      gnum = 0.5*(ep-em)/shift;

      cout << setw(3) << 3*iatom+i << "  "
           << fixed << setw(12) << setprecision(5) << gnum << "  "
           << fixed << setw(12) << setprecision(5) 
           << gradient[iatom][i] << "  "
           << fixed << setw(12) << setprecision(5) 
           << gradient[iatom][i]-gnum << "  "
           << endl;
    }
  }

  cout << "============================================="<<endl;
}

void Gradient::Evaluate()
{
  int i,iatom,ig;

  // Initialize
  for (iatom=0;iatom<sys->mol->Natom();iatom++)
    for (i=0;i<3;i++)
      gradient[iatom][i] = 0.0;

  NuclearRepulsion();

  for (ig=0;ig<sys->ngas;ig++)
  {
    // Pulay
    Matrix *W = new Matrix(sys->gas[ig]->nco,sys->gas[ig]->nco);
    sys->gas[ig]->BuildPulayMatrix(W);
    TwoCenterMatrixDerivatives(sys->gas[ig],W,(char*)"overlap");
    delete W;

    // Core
    //rfm sys->gas[ig]->BuildDensityMatrix();
    TwoCenterMatrixDerivatives(sys->gas[ig],sys->gas[ig]->P,(char*)"kinetic");
    CoreMatrixDerivatives(sys->gas[ig],sys->gas[ig]->P);
  }
};

// Get nuclear repulsion energy gradients
// Roberto Flores-Moreno, May 2009
void Gradient::NuclearRepulsion()
{
  int i,iatom,jatom,natom;
  double ab,za,zb;
  Vector ra,rb;

  natom = sys->mol->Natom();
  for (iatom=0;iatom<natom-1;iatom++)
  {
    za = sys->mol->atom[iatom]->charge;
    ra = Vector(sys->mol->atom[iatom]->x,
                sys->mol->atom[iatom]->y,
                sys->mol->atom[iatom]->z);
    for (jatom=iatom+1;jatom<natom;jatom++)
    {
      zb = sys->mol->atom[jatom]->charge;
      rb = Vector(sys->mol->atom[jatom]->x,
                  sys->mol->atom[jatom]->y,
                  sys->mol->atom[jatom]->z);
      rb -= ra;
      ab = rb.Norm();
      rb *= za*zb/(ab*ab*ab);
      for (i=0;i<3;i++)
      {
        gradient[iatom][i] += rb[i];
        gradient[jatom][i] -= rb[i];
      }
    }
  }
}

// Apropiately pack gradients
// Roberto Flores-Moreno, Oct 2008
void Gradient::Pack(int la,int lb,Vector *gblk,double **pblk,double **iblk,char* option)
{
  int a,ax,ay,az,b,bx,by,bz;
  double factor;

  if (strncmp(option,"up",2)==0)
  {
    for (bx=0;bx<=lb;bx++)
    {
      for (by=0;by<=lb-bx;by++)
      {
        bz = lb-bx-by;
        b = raop[bx][by][bz];
        for (ax=0;ax<=la;ax++)
        {
          for (ay=0;ay<=la-ax;ay++)
          {
            az = la-ax-ay;
            a = raop[ax][ay][az];
            factor = 2.0*pblk[a][b];
            (*gblk)[0] += factor*iblk[raop[ax+1][ay][az]][b];
            (*gblk)[1] += factor*iblk[raop[ax][ay+1][az]][b];
            (*gblk)[2] += factor*iblk[raop[ax][ay][az+1]][b];
          }
        }
      }
    }
  }
  else if (strncmp(option,"down",4)==0)
  {
    for (bx=0;bx<=lb;bx++)
    {
      for (by=0;by<=lb-bx;by++)
      {
        bz = lb-bx-by;
        b = raop[bx][by][bz];
        for (ax=0;ax<=la;ax++)
        {
          for (ay=0;ay<=la-ax;ay++)
          {
            az = la-ax-ay;
            a = raop[ax][ay][az];
            if (ax>0) (*gblk)[0]-=ax*pblk[a][b]*iblk[raop[ax-1][ay][az]][b];
            if (ay>0) (*gblk)[1]-=ay*pblk[a][b]*iblk[raop[ax][ay-1][az]][b];
            if (az>0) (*gblk)[2]-=az*pblk[a][b]*iblk[raop[ax][ay][az-1]][b];
          }
        }
      }
    }
  }
}

// Apropiately pack gradients
// Roberto Flores-Moreno, Oct 2008 (Translated to C in Aug 2015)
void Gradient::Save(Vector gblk,int atoml,int atomr)
{
  // Direct contributions
  gradient[atoml] += gblk;

  // Traslational invariance contributions
  gradient[atomr] -= gblk;
}


void Gradient::TwoCenterMatrixDerivatives(GaussianGas *g,Matrix *W, char* option)
{
  int dao,i,ib,is,j,jb,js,lla,llb,lmax,na,nb;
  double ra[3],rb[3];
  double **intblk,**wblk;
  GaussianShell *sa,*sb;
  Vector gblk;

  lmax = g->LMax(g->basis) + 1;  // Increase 1 for derivatives
  dao = ((lmax+1)*(lmax+2))/2;

  intblk = new double*[dao];
  for (i=0;i<dao;i++)
    intblk[i] = new double[dao];

  wblk = new double*[dao];
  for (i=0;i<dao;i++)
    wblk[i] = new double[dao];

  for (ib=0;ib<(signed)g->basis.size();ib++)
  {
    ra[0] = g->basis[ib]->x; 
    ra[1] = g->basis[ib]->y; 
    ra[2] = g->basis[ib]->z; 
    for (jb=0;jb<(signed)g->basis.size();jb++)
    {
      gblk = Vector(0.0,0.0,0.0);
      rb[0] = g->basis[jb]->x; 
      rb[1] = g->basis[jb]->y; 
      rb[2] = g->basis[jb]->z; 
      for (is=0;is<(signed)g->basis[ib]->shell.size();is++)
      {
        sa = g->basis[ib]->shell[is];
        na = ((sa->l+1)*(sa->l+2))/2;
        lla = g->basis[ib]->ll+sa->ll;
        for (js=0;js<(signed)g->basis[jb]->shell.size();js++)
        {
          sb = g->basis[jb]->shell[js];
          nb = ((sb->l+1)*(sb->l+2))/2;
          llb = g->basis[jb]->ll+sb->ll;

          if ((jb>ib)||((jb==ib)&&(js>=is))) 
          {
            for (i=0;i<na;i++)
            {
              for (j=0;j<nb;j++)
              {
                wblk[i][j] = (*W)(lla+i,llb+j)*sa->ncsto[i]*sb->ncsto[j];
                if ((jb==ib)&&(js==is))
                { 
                  if (j<i) wblk[i][j] = 0.0;
                  else if (j>i) wblk[i][j] *= 2.0;
                }
                else wblk[i][j] *= 2.0;
                if ( strncmp(option,"kinet",5) == 0 )
                  wblk[i][j] /= g->particle_mass;
              }
            }
            // Left up
            sa->l += 1;
            if ( strncmp(option,"kinet",5) == 0 )
              gi->Kinetic(ra,rb,sa,sb,intblk,1,false);
            else if ( strncmp(option,"overl",5) == 0 )
              gi->Overlap(ra,rb,sa,sb,intblk,1,false);
            sa->l -= 1;
            Pack(sa->l,sb->l,&gblk,wblk,intblk,(char*)"up");
            // Left down
            if (sa->l>0)
            {
              sa->l -= 1;
              if ( strncmp(option,"kinet",5) == 0 )
                gi->Kinetic(ra,rb,sa,sb,intblk,0,false);
              else if ( strncmp(option,"overl",5) == 0 )
                gi->Overlap(ra,rb,sa,sb,intblk,0,false);
              sa->l += 1;
              Pack(sa->l,sb->l,&gblk,wblk,intblk,(char*)"down");
            }
          }
        }
      }
      Save(gblk,ib,jb);
    }
  }

  for (i=0;i<dao;i++)
    delete[] intblk[i];
  delete[] intblk;

  for (i=0;i<dao;i++)
    delete[] wblk[i];
  delete[] wblk;
}

void Gradient::CoreMatrixDerivatives(GaussianGas *g,Matrix *W)
{
  int dao,i,ib,is,j,jb,js,katom,lla,llb,lmax,na,nb;
  double ra[3],rb[3],rc[3];
  double **intblk,**wblk,**kwblk;
  GaussianShell *sa,*sb;
  Vector gblk;

  gblk = Vector(0.0,0.0,0.0);

  lmax = g->LMax(g->basis) + 1;  // Increase 1 for derivatives
  dao = ((lmax+1)*(lmax+2))/2;

  intblk = new double*[dao];
  for (i=0;i<dao;i++)
    intblk[i] = new double[dao];

  wblk = new double*[dao];
  for (i=0;i<dao;i++)
    wblk[i] = new double[dao];

  kwblk = new double*[dao];
  for (i=0;i<dao;i++)
    kwblk[i] = new double[dao];

  for (ib=0;ib<(signed)g->basis.size();ib++)
  {
    ra[0] = g->basis[ib]->x; 
    ra[1] = g->basis[ib]->y; 
    ra[2] = g->basis[ib]->z; 
    for (jb=0;jb<(signed)g->basis.size();jb++)
    {
      rb[0] = g->basis[jb]->x; 
      rb[1] = g->basis[jb]->y; 
      rb[2] = g->basis[jb]->z; 
      for (is=0;is<(signed)g->basis[ib]->shell.size();is++)
      {
        sa = g->basis[ib]->shell[is];
        na = ((sa->l+1)*(sa->l+2))/2;
        lla = g->basis[ib]->ll+sa->ll;
        for (js=0;js<(signed)g->basis[jb]->shell.size();js++)
        {
          sb = g->basis[jb]->shell[js];
          nb = ((sb->l+1)*(sb->l+2))/2;
          llb = g->basis[jb]->ll+sb->ll;

          //if ((jb>ib)||((jb==ib)&&(js>=is))) 
          {
            for (i=0;i<na;i++)
            {
              for (j=0;j<nb;j++)
              {
                wblk[i][j] = (*W)(lla+i,llb+j)*sa->ncsto[i]*sb->ncsto[j];
                wblk[i][j] *= g->particle_charge;
                wblk[i][j] = 0.1/2.0;
/*
                if ((jb==ib)&&(js==is))
                { 
                  if (j<i) wblk[i][j] = 0.0;
                  else if (j>i) wblk[i][j] *= 2.0;
                }
                else wblk[i][j] *= 2.0;
*/
              }
            }
            cout << "Shell : "<<is<<" "<<js<<endl;
            for (katom=0;katom<sys->mol->Natom();katom++)
            {
              if (sys->mol->atom[katom]->charge>0.0)
              {
                cout << "Katom : "<<katom<<endl;
                rc[0] = sys->mol->atom[katom]->x; 
                rc[1] = sys->mol->atom[katom]->y; 
                rc[2] = sys->mol->atom[katom]->z; 
                // === Left ===
                gblk[0] = 0.0;
                gblk[1] = 0.0;
                gblk[2] = 0.0;
                // Left up
                sa->l += 1;
                cout << "XX : "<<sa->l<<"   "<<sb->l<<endl;
                gi->CoreAlt(ra,rb,rc,sa,sb,intblk,1,0,false);
                cout << "XXXXXXXXXX : "<<sa->l<<"   "<<sb->l<<endl;
                sa->l -= 1;
                //for (i=0;i<dao;i++)
                //  for (j=0;j<dao;j++)
                //    intblk[i][j] =0.1;
                Pack(sa->l,sb->l,&gblk,wblk,intblk,(char*)"up");
/*
                // Left down
                if (sa->l>0)
                {
                  sa->l -= 1;
                  gi->Core(ra,rb,rc,sa,sb,intblk,0,0,false);
                  sa->l += 1;
                  Pack(sa->l,sb->l,&gblk,wblk,intblk,(char*)"down");
                }
*/
                gblk *= sys->mol->atom[katom]->charge;
                Save(gblk,ib,katom);
/*
                // === Right ===
                gblk[0] = 0.0;
                gblk[1] = 0.0;
                gblk[2] = 0.0;
                for (i=0;i<na;i++)
                  for (j=0;j<nb;j++)
                    kwblk[j][i] = wblk[i][j];
                gblk = Vector(0.0,0.0,0.0);
                // Right up
                sb->l += 1;
                gi->Core(rb,ra,rc,sb,sa,intblk,1,0,false);
                sb->l -= 1;
                Pack(sb->l,sa->l,&gblk,kwblk,intblk,(char*)"up");
                // Right down
                if (sb->l>0)
                {
                  sb->l -= 1;
                  gi->Core(rb,ra,rc,sb,sa,intblk,0,0,false);
                  sb->l += 1;
                  Pack(sb->l,sa->l,&gblk,kwblk,intblk,(char*)"down");
                }
                gblk *= sys->mol->atom[katom]->charge;
                Save(gblk,jb,katom);
*/
              }
            }
          }
        }
      }
    }
  }

  for (i=0;i<dao;i++)
    delete[] intblk[i];
  delete[] intblk;

  for (i=0;i<dao;i++)
    delete[] wblk[i];
  delete[] wblk;

  for (i=0;i<dao;i++)
    delete[] kwblk[i];
  delete[] kwblk;
}

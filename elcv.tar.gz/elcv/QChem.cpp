/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// Master object for Quantum Chemistry calculations
#include <stdlib.h>
#include <string.h>

#include <iostream>
#include <fstream>

#include <QChem.h>
#include <System.h>
#include <Molecular.h>
#include <Atom.h>
#include <GaussianGas.h>
#include <GaussianSet.h>
#include <Element.h>
#include <SCF.h>
#include <ADFT.h>
#include <ADPT.h>

using namespace std;

QChem::QChem(System *isys)
{
  sys = isys;
  scf = new SCF(this);

  temperature = 0.0;    // Standard orbital calculations
  chemical_potential = 0.0;   

  for (int itype=0;itype<NTYPES;itype++)
  {
    restricted[itype] = false;
    direct[itype] = false;
  }
}

void QChem::Setup()
{
  sys->Setup(this,basname);

  for (int itype=0;itype<NTYPES;itype++)
  {
    if (restricted[itype]&&(sys->Alpha(itype)!=sys->Beta(itype)))
    {
      cout << "Restricted open shell not available"<<endl;
      exit(EXIT_FAILURE);
    }
  }

  // XC
  if ( strncmp(method[ELECTRON],"Hartree-Fock",12) == 0 ) adft = 0;
  else adft = new ADFT(this,method[ELECTRON]);

  for (int ig=0;ig<sys->ngas;ig++)
  {
    int type = sys->gas[ig]->type;
    sys->gas[ig]->copy_source = -1;
    if ( restricted[type] ) 
      for (int jg=0;jg<ig;jg++)
        if (type==sys->gas[jg]->type)
          sys->gas[ig]->copy_source = jg;
    sys->gas[ig]->SetupSCF(method[type],guess[type],ig,direct[type]);
  }

};

// SCF energy
double QChem::SCFEnergy()
{
  return sys->energy;
}

// Moller Plesset perturbation theory main module
double QChem::MP2Energy()
{
  double mp2ce;

  int i,ig,j,jg,a,b,nco1,nco2,nmo1,nmo2,nh1,nh2;
  double ei,ej,ea,eb,e,t,d;

  mp2ce = 0.0;
  for (ig=0;ig<sys->ngas;ig++)
  {
    nh1 = sys->gas[ig]->HOMO + 1;
    nco1 = sys->gas[ig]->nco;
    nmo1 = sys->gas[ig]->nmo;
    for (jg=ig;jg<sys->ngas;jg++)
    {
      nh2 = sys->gas[jg]->HOMO + 1;
      nco2 = sys->gas[jg]->nco;
      nmo2 = sys->gas[jg]->nmo;
      Matrix eri(nco1,nco2); // NCO >= NMO

      for (i=0;i<nh1;i++)
      {
        ei = sys->gas[ig]->energies[i];
        for (j=0;j<nh2;j++)
        {
          ej = sys->gas[jg]->energies[j];
          sys->gas[ig]->EvaluateERI4Batch(sys->gas[jg],i,j,eri);
          for (a=nh1;a<nmo1;a++)
          {
            ea = sys->gas[ig]->energies[a];
            for (b=nh2;b<nmo2;b++)
            {
              eb = sys->gas[jg]->energies[b];
              d = ei + ej - ea - eb;
              if (ig==jg) e = (eri(a,b) - eri(b,a))*0.5;
              else e = eri(a,b);
              t = e*e/d;
              mp2ce += t;
            }
          }
        }
      }
    }
  }

  return mp2ce;
}

void QChem::Polarizability(Matrix alpha)
{
  ADPT *adpt = new ADPT(this);
  alpha.SetZero();
  adpt->Polarizability(alpha);
  delete adpt;
};

// Compute atomic density matrices for Hirshfeld charges
void QChem::EvaluatePromolecularDensity(Matrix *P0)
{
  int an,iatom,jatom,jg,na,natom,nb;
  bool *done;
  ofstream ff("Hirshfeld.xal");
  ff << "Pro-molecular density matrices "<<endl;
  ff.close();

  System *asys = new System();
  asys->ChangeAlpha( 0 , PROTON );
  asys->ChangeBeta( 0 , PROTON );
  asys->ChangeAlpha( 0 , SOLVENT );
  asys->ChangeBeta( 0 , SOLVENT );
  QChem *oqchem = new QChem(asys);
  oqchem->scf->atomic = true;

  natom = sys->mol->Natom();
  done = new bool[natom];
  for (iatom=0;iatom<natom;iatom++)
    done[iatom] = false;

  P0->SetZero();
  for (iatom=0;iatom<natom;iatom++)
  {
   if (!done[iatom])
   {
    an = sys->mol->atom[iatom]->atomic_number;
    cout << "Atomic number: "<<an<<endl;
    asys->mol->AddAtom(an,0,0,0,0.0,0.0,0.0);
    nb = an/2;
    na = an - nb;
    if (an==6) 
    {
      na = 4;
      nb = 2;
    }
    else if (an==7) 
    {
      na = 5;
      nb = 2;
    }
    else if (an==8) 
    {
      na = 5;
      nb = 3;
    }
    else if (an==16) 
    {
      na = 8;
      nb = 8;
    }
    asys->ChangeAlpha( na , ELECTRON );
    asys->ChangeBeta( nb , ELECTRON );

    oqchem->ChangeBasis(basname[ELECTRON],ELECTRON);
    oqchem->ChangePseudos(potname[ELECTRON],ELECTRON);
    oqchem->ChangeMethod(method[ELECTRON],ELECTRON);
    oqchem->ChangeGuess((char*)"Core",ELECTRON);
    oqchem->scf->mixing = scf->mixing;
    oqchem->Setup();
    oqchem->scf->Setup();
    oqchem->scf->SeekConvergence();
    if (!oqchem->scf->Converged())
      cout << " Atomic SCF did not converge for " 
           << ELEMENT_SYMBOL[an] << endl;

    for (jatom=0;jatom<natom;jatom++)
    {
      if (!done[jatom]&&an==sys->mol->atom[jatom]->atomic_number)
      {
        for (jg=0;jg<asys->ngas;jg++)
          P0->Add(asys->gas[jg]->P,
              sys->gas[jg]->basis[jatom]->ll,sys->gas[jg]->basis[jatom]->ll);
        done[jatom] = true;
      }
    }

    asys->mol->DeleteLastAtom();
   }
  }
  P0->Print((char*)"P0.xal",(char*)"Promolecular density matrix",15,5);

  delete asys;
  delete done;
};

void QChem::ChangeBasis(char *newbas, int type)
{
  strcpy(basname[type],newbas);
}

void QChem::ChangePseudos(char *newpot, int type)
{
  strcpy(potname[type],newpot);
}

void QChem::ChangeMethod(char *newmethod, int type)
{
  strcpy(method[type],newmethod);
}

void QChem::ChangeGuess(char *newguess, int type)
{
  strcpy(guess[type],newguess);
}

void QChem::ChangeRestricted(int type)
{
  if (restricted[type]) restricted[type] = false;
  else restricted[type] = true;
}

void QChem::ChangeProjected(int type)
{
  if (scf->projected[type]) scf->projected[type] = false;
  else scf->projected[type] = true;
}
void QChem::ChangeDirect(int type)
{
  if (direct[type]) direct[type] = false;
  else direct[type] = true;
}

/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Definition of Model
//
// 2015: Roberto Flores Moreno
// ******************************************************************

#ifndef X_MODEL_H
#define X_MODEL_H

#include <GL/glu.h>

#include <QtCore>

class Panel;
class Atom;
class Molecular;

class Model
{
  public:

    Model(Panel*);

    Panel* panel;
    Molecular *mol;
    double srs;
    double crs;
    bool drawmol;
    GLUquadricObj* q;

    void DrawSphere( double* , double, int );
    void DrawCylinder( double* , double* , double, int );
    void DrawCone( double* , double* , double, int );
    void DrawMolecule( int, bool );
    void ChangeKind( const QString & );

  protected:

    void DrawAtom( Atom* , double, int );
    void DrawBond( Atom* , Atom* , double, int );
};

#endif // MODEL_H

/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <string.h>

#include <fstream>

#include <File.h>
#include <Matrix.h>

using namespace std;

File::File(char* ifilename, int idim_row, int idim_col)
{
  strcpy(filename,ifilename);
  dim_row = idim_row;
  dim_col = idim_col;
}

void File::Read(Matrix m,int n)
{
  int i,j;

  ifstream f(filename);

  long pos = dim_row*dim_col*n;
  f.seekg(pos,ios::beg);

  for (i=0;i<m.NRow();i++)
    for (j=0;j<m.NCol();j++)
      f >> m(i,j); 

  f.close();

};

void File::Write(Matrix m, int n)
{
  int i,j;

  ofstream f(filename);

  long pos = dim_row*dim_col*n;
  f.seekp(pos,ios::beg);

  for (i=0;i<m.NRow();i++)
    for (j=0;j<m.NCol();j++)
      f << m(i,j); 

  f.close();
};


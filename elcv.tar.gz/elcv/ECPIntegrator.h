/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#ifndef X_ECP_INTEGRATOR_H
#define X_ECP_INTEGRATOR_H

#include <vector>

#include <CFPIntegrator.h>
#include <Matrix.h>
#include <Vector.h>

using namespace std;

class GaussianGas;

class ECPIntegrator : CFPIntegrator
{
  public:
    ECPIntegrator(GaussianGas*);
 
    void BuildMatrix(Matrix*);

  protected:

    vector<Matrix> angint;
    vector<Matrix> bastab;
    vector<Matrix> slaa;
    vector<Matrix> slab;
    vector<Matrix> rint;

    void Angular(int);
    void GeometryDependent(int,int,Vector,double*,vector<Matrix>); 
    void TabulateRadialPotential(double**);
    void TabulateBasis(int,bool);
    void Block(GaussianShell*,GaussianShell*,Matrix,Matrix,double**,double**,int,int);
    void SemilocalOneCenter(int,int,int,double**);
    bool SemilocalRadial(int,int,int,Matrix,Matrix,double**);
    bool RadialQuadrature(double*,double*,double*,int,double*);
    void SemilocalOverPrimitives(GaussianShell*,GaussianShell*,int,int,int); 
    double SemilocalPotential(double,int);
};

#endif

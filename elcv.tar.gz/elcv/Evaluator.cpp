/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Evaluator class.
//
// 2015: Roberto Flores-Moreno
// ******************************************************************

#include <iostream>

#include <QtWidgets>

#include <Evaluator.h>
#include <System.h>
#include <Molecular.h>
#include <Atom.h>
#include <GaussianGas.h>
#include <GaussianSet.h>
#include <GaussianShell.h>
#include <Math.h>

using namespace std;

void GetGTODerivatives(vector<GaussianSet*> basis, int id, double* x, double *y, double *z, double *dx, double *dy, double *dz, int n)
{
  int i,ib,is,io;

  double wx[n];
  double wy[n];
  double wz[n];

  i = 0;
  for (ib=0;ib<(signed)basis.size();ib++)
  {
    for (is=0;is<(signed)basis[ib]->shell.size();is++)
    {
      GaussianShell *shell = basis[ib]->shell[is];
      for (io=0;io<shell->nco;io++)
      {
        if (i==id) 
        {
          double x0,y0,z0;

          x0 = basis[ib]->x;
          y0 = basis[ib]->y;
          z0 = basis[ib]->z;
          for (int ii=0;ii<n;ii++) 
          {
            wx[ii] = x[ii] - x0;
            wy[ii] = y[ii] - y0;
            wz[ii] = z[ii] - z0;
          }
          shell->EvaluateGTODerivative(wx,wy,wz,dx,dy,dz,io,n);
          return;
        }
        i++;
      }
    }
  }
};

void GetBasisDerivatives(vector<GaussianSet*> basis, double x, double y, double z,
 double *dx, double *dy, double *dz)
{
  int i,ib,is,io,lla;
  GaussianShell *shell;

  double xx[1];
  double yy[1];
  double zz[1];
  double dxx[1];
  double dyy[1];
  double dzz[1];

  for (ib=0;ib<(signed)basis.size();ib++)
  {
    xx[0] = x - basis[ib]->x;
    yy[0] = y - basis[ib]->y;
    zz[0] = z - basis[ib]->z;
    for (is=0;is<(signed)basis[ib]->shell.size();is++)
    {
      shell = basis[ib]->shell[is];
      lla = shell->ll + basis[ib]->ll;
      for (io=0;io<shell->nco;io++)
      {
        i = lla + io;
        //GetGTODerivatives(basis,i,xx,yy,zz,dxx,dyy,dzz,1);
        shell->EvaluateGTODerivative(xx,yy,zz,dxx,dyy,dzz,io,1);
        dx[i] = dxx[0];
        dy[i] = dyy[0];
        dz[i] = dzz[0];
      }
    }
  }
};


void GetOrbitalDerivatives(GaussianGas* gas, int id, double* x, double *y, double *z, double *dx, double *dy, double *dz, int n)
{
  int i,io;

  int nco = gas->nco;
  double moc[nco];
  gas->C->GetColValues( id , moc );

  double gto_dx[nco];
  double gto_dy[nco];
  double gto_dz[nco];

  for (i=0;i<n;i++) 
  {
    GetBasisDerivatives(gas->basis,x[i],y[i],z[i],gto_dx,gto_dy,gto_dz);
    dx[i] = 0.0;
    dy[i] = 0.0;
    dz[i] = 0.0;
    for (io=0;io<nco;io++) 
    {
      dx[i] += gto_dx[io]*moc[io];
      dy[i] += gto_dy[io]*moc[io];
      dz[i] += gto_dz[io]*moc[io];
    }
  }
};



void GetChargeDensityDerivatives(System* sys,double* x, double *y, double *z, double *dx, double *dy, double *dz, int n, bool response)
{
  int i,ig;

  double dxbuf[n],dybuf[n],dzbuf[n];

  for (i=0;i<n;i++) 
  {
    dx[i] = 0.0;
    dy[i] = 0.0;
    dz[i] = 0.0;
  }
  for (ig=0;ig<sys->ngas;ig++)
  {
    GetParticleDensityDerivatives(sys->gas[ig],x,y,z,dxbuf,dybuf,dzbuf,
       n,response);
    for (i=0;i<n;i++) 
    {
      dx[i] += dxbuf[i]*sys->gas[ig]->particle_charge;
      dy[i] += dybuf[i]*sys->gas[ig]->particle_charge;
      dz[i] += dzbuf[i]*sys->gas[ig]->particle_charge;
    }
  }
}

void GetRDGDerivatives(System* sys,double* x, double *y, double *z, double *dx, double *dy, double *dz, int n, bool response)
{
  int i;
  double factor;
  double *rho,*g,*rdx,*rdy,*rdz,*dxx,*dxy,*dxz,*dyy,*dyz,*dzz;

  rho = new double[n];
  g = new double[n];
  rdx = new double[n];
  rdy = new double[n];
  rdz = new double[n];
  dxx = new double[n];
  dxy = new double[n];
  dxz = new double[n];
  dyy = new double[n];
  dyz = new double[n];
  dzz = new double[n];
  GetRDG(sys,x,y,z,g,n,response);
  GetChargeDensity(sys,x,y,z,rho,n,response);
  GetChargeDensityDerivatives(sys,x,y,z,rdx,rdy,rdz,n,response);
  GetChargeDensityHessian(sys,x,y,z,dxx,dxy,dxz,dyy,dyz,dzz,n,response);
  for (i=0;i<n;i++) 
  {
    if ((X_ABS(g[i])>X_TOL_NUM)&&(X_ABS(rho[i])>X_TOL_NUM))
    {
      factor = -1.0/(2.0*pow(3.0*X_PI*X_PI,1.0/3.0)*pow(-rho[i],4.0/3.0));
      dx[i] = (dxx[i]*rdx[i]+dxy[i]*rdy[i]+dxz[i]*rdz[i])/g[i]
              - 4.0*rdx[i]/(3.0*rho[i]);
      dy[i] = (dxy[i]*rdx[i]+dyy[i]*rdy[i]+dyz[i]*rdz[i])/g[i]
              - 4.0*rdy[i]/(3.0*rho[i]);
      dz[i] = (dxz[i]*rdx[i]+dyz[i]*rdy[i]+dzz[i]*rdz[i])/g[i]
              - 4.0*rdz[i]/(3.0*rho[i]);
      dx[i] *= factor;
      dy[i] *= factor;
      dz[i] *= factor;
    }
    else
    {
      dx[i] = 0.0;
      dy[i] = 0.0;
      dz[i] = 0.0;
    }
  }
  delete rho;
  delete g;
  delete rdx;
  delete rdy;
  delete rdz;
  delete dxx;
  delete dxy;
  delete dxz;
  delete dyy;
  delete dyz;
  delete dzz;
}

void GetElectronicSpinDensityDerivatives(System* sys,double* x, double *y, double *z, double *dx, double *dy, double *dz, int n)
{
  int i,ig;

  double dxbuf[n],dybuf[n],dzbuf[n];

  bool leader = true;
  for (ig=0;ig<sys->ngas;ig++)
  {
    if (sys->gas[ig]->type==ELECTRON)
    {
      GetParticleDensityDerivatives(sys->gas[ig],x,y,z,dxbuf,dybuf,dzbuf,n,false);
      if (leader)
      {
        for (i=0;i<n;i++) 
        {
          dx[i] = dxbuf[i];
          dy[i] = dybuf[i];
          dz[i] = dzbuf[i];
        }
        leader = false;
      }
      else 
      {
        for (i=0;i<n;i++) 
        {
          dx[i] -= dxbuf[i];
          dy[i] -= dybuf[i];
          dz[i] -= dzbuf[i];
        }
      }
    }
  }
}

void GetShapeDerivatives(System* sys,double* x, double *y, double *z, double *dx, double *dy, double *dz, int n)
{
  int i,ig,nelec;

  double dxbuf[n],dybuf[n],dzbuf[n];

  for (i=0;i<n;i++) 
  {
    dx[i] = 0.0;
    dy[i] = 0.0;
    dz[i] = 0.0;
  }
  nelec = 0;
  for (ig=0;ig<sys->ngas;ig++)
  {
    if (sys->gas[ig]->type==ELECTRON) 
    {
      nelec += sys->gas[ig]->npart;
      GetParticleDensityDerivatives(sys->gas[ig],x,y,z,dxbuf,dybuf,dzbuf,n,false);
      for (i=0;i<n;i++) 
      {
        dx[i] += dxbuf[i];
        dy[i] += dybuf[i];
        dz[i] += dzbuf[i];
      }
    }
  }
  if ( nelec == 0 ) return;
  for (i=0;i<n;i++) 
  {
    dx[i] /= double(nelec);
    dy[i] /= double(nelec);
    dz[i] /= double(nelec);
  }
}
      
void GetGTO(vector<GaussianSet*> basis, int id, double* x, double *y, double *z, double *v, int n)
{
  int i,ib,is,io;

  double wx[n];
  double wy[n];
  double wz[n];

  i = 0;
  for (ib=0;ib<(signed)basis.size();ib++)
  {
    for (is=0;is<(signed)basis[ib]->shell.size();is++)
    {
      GaussianShell *shell = basis[ib]->shell[is];
      for (io=0;io<shell->nco;io++)
      {
        if (i==id) 
        {
          double x0,y0,z0;

          x0 = basis[ib]->x;
          y0 = basis[ib]->y;
          z0 = basis[ib]->z;
          for (int ii=0;ii<n;ii++) 
          {
            wx[ii] = x[ii] - x0;
            wy[ii] = y[ii] - y0;
            wz[ii] = z[ii] - z0;
          }
          shell->EvaluateGTO(wx,wy,wz,v,io,n);
          return;
        }
        i++;
      }
    }
  }
};

void GetBasis(vector<GaussianSet*> basis, double x, double y, double z,double *v)
{
  int i,ib,is,io,lla;

  double xx[1];
  double yy[1];
  double zz[1];

  for (ib=0;ib<(signed)basis.size();ib++)
  {
    for (is=0;is<(signed)basis[ib]->shell.size();is++)
    {
      GaussianShell *shell = basis[ib]->shell[is];
      lla = shell->ll + basis[ib]->ll;
      for (io=0;io<shell->nco;io++)
      {
        i = lla + io;
        if (basis[ib]->is_neighbor)
        {
          xx[0] = x - basis[ib]->x;
          yy[0] = y - basis[ib]->y;
          zz[0] = z - basis[ib]->z;
          shell->EvaluateGTO(xx,yy,zz,&v[i],io,1);
        }
        else v[i] = 0.0;
      }
    }
  }
};


void GetOrbital(GaussianGas* gas, int id, double* x, double *y, double *z, double *v, int n)
{
  int i,io;

  int nco = gas->nco;
  double moc[nco];
  gas->C->GetRowValues( id , moc );

  double gto[nco];

  for (i=0;i<n;i++) 
  {
    GetBasis(gas->basis,x[i],y[i],z[i],gto);
    v[i] = 0.0;
    for (io=0;io<nco;io++) 
      v[i] += gto[io]*moc[io];
  }
};




void GetChargeDensity(System* sys,double* x, double *y, double *z, double *v, int n, bool response)
{
  int i,ig;
  
  double buf[n];

  for (i=0;i<n;i++)
    v[i] = 0.0;
  for (ig=0;ig<sys->ngas;ig++)
  {
    GetParticleDensity(sys->gas[ig],x,y,z,buf,n,response);
    for (i=0;i<n;i++)
      v[i] += buf[i]*sys->gas[ig]->particle_charge;
  }
}

void GetRDG(System* sys,double* x, double *y, double *z, double *v, int n, bool response)
{
  int i;
  double factor;
  double *rho,*dx,*dy,*dz;
  
  rho = new double[n];
  dx = new double[n];
  dy = new double[n];
  dz = new double[n];

  GetChargeDensity(sys,x,y,z,rho,n,response);
  GetChargeDensityDerivatives(sys,x,y,z,dx,dy,dz,n,response);
  for (i=0;i<n;i++)
  {
    if (X_ABS(rho[i])>X_TOL_NUM)
    {
      factor =  1.0/(2.0*pow(3.0*X_PI*X_PI,1.0/3.0)*pow(-rho[i],4.0/3.0));
      v[i] = sqrt(dx[i]*dx[i]+dy[i]*dy[i]+dz[i]*dz[i])*factor;
    }
    else
    {
      v[i] = 1.0/X_TOL_NUM;
    }
  }

  delete rho;
  delete dx;
  delete dy;
  delete dz;
}

void GetElectronicSpinDensity(System* sys,double* x, double *y, double *z, double *v, int n)
{
  int i,ig;
  
  double buf[n];

  bool leader = true;
  for (ig=0;ig<sys->ngas;ig++)
  {
    if (sys->gas[ig]->type==ELECTRON)
    {
      GetParticleDensity(sys->gas[ig],x,y,z,buf,n,false);
      if (leader)
      {
        for (i=0;i<n;i++)
          v[i] = buf[i];
        leader = false;
      }
      else
      {
        for (i=0;i<n;i++)
          v[i] -= buf[i];
      }
    }
  }
}

void GetShape(System* sys,double* x, double *y, double *z, double *v, int n)
{
  int i,ig,nelec;
  
  double buf[n];

  for (i=0;i<n;i++)
    v[i] = 0.0;
  nelec = 0;
  for (ig=0;ig<sys->ngas;ig++)
  {
    if (sys->gas[ig]->type==ELECTRON) 
    {
      nelec += sys->gas[ig]->npart;
      GetParticleDensity(sys->gas[ig],x,y,z,buf,n,false);
      for (i=0;i<n;i++)
        v[i] += buf[i];
    }
  }
  if (nelec==0) return;
  for (i=0;i<n;i++)
    v[i] /= double(nelec);
}

// Functions

// ==========================
// Density like functions
void GetDensityLike(Matrix *P, vector<GaussianSet*> basis,
double* x, double *y, double *z, double *v, int n)
{
  int i,io,jo;

  int nco = basis[basis.size()-1]->ul + 1;
  double s;
  double row[nco];
  double gto[nco];

  for (int i=0;i<n;i++) 
  {
    GetBasis(basis,x[i],y[i],z[i],gto); 
    v[i] = 0.0;
    for (io=0;io<nco;io++) 
    {
      P->GetRowValues( io , row );
      s = row[io]*gto[io];
      for (jo=0;jo<io;jo++) 
        s += 2.0*row[jo]*gto[jo];
      v[i] += s*gto[io];
    }
  }
};

void GetDensityLikeDerivatives(Matrix *P,vector<GaussianSet*> basis,
double* x, double *y, double *z, double *dx, double *dy, double *dz, int n)
{
  int io,jo;

  int nco = basis[basis.size()-1]->ul + 1;
  double row[nco];

  double gto[nco];
  double gto_dx[nco];
  double gto_dy[nco];
  double gto_dz[nco];

  for (int i=0;i<n;i++) 
  {
    GetBasis(basis,x[i],y[i],z[i],gto); 
    GetBasisDerivatives(basis,x[i],y[i],z[i],gto_dx,gto_dy,gto_dz);
    dx[i] = 0.0;
    dy[i] = 0.0;
    dz[i] = 0.0;
    for (io=0;io<nco;io++) 
    {
      P->GetRowValues( io , row );
      for (jo=0;jo<nco;jo++) 
      {
        dx[i] += row[jo]*(gto_dx[io]*gto[jo]+gto[io]*gto_dx[jo]);
        dy[i] += row[jo]*(gto_dy[io]*gto[jo]+gto[io]*gto_dy[jo]);
        dz[i] += row[jo]*(gto_dz[io]*gto[jo]+gto[io]*gto_dz[jo]);
      }
    }
  }
};

// ==========================
// Particle density
void GetParticleDensity(GaussianGas* gas,double* x, double *y, double *z, double *v, int n, bool response)
{
  if (response) GetDensityLike(gas->P1,gas->basis,x,y,z,v,n);
  else GetDensityLike(gas->P,gas->basis,x,y,z,v,n);
};

void GetParticleDensityDerivatives(GaussianGas* gas,double* x, double *y, double *z, double *dx, double *dy, double *dz, int n,bool response)
{
  if (response) GetDensityLikeDerivatives(gas->P1,gas->basis,x,y,z,dx,dy,dz,n);
  else GetDensityLikeDerivatives(gas->P,gas->basis,x,y,z,dx,dy,dz,n);
};

// ==========================
// Shannon entropy based on shape function
void GetShannon(System* sys,double* x, double *y, double *z, double *v, int n)
{
  int i;
  double shape;

  GetShape(sys,x,y,z,v,n);

  for (i=0;i<n;i++)
  {
    shape = v[i];
    v[i] = -shape*log(shape);
  }
}

void GetShannonDerivatives(System* sys,double* x, double *y, double *z, double *dx, double *dy, double *dz, int n)
{
  int i;
  double shape,dshape;
  double v[n];

  GetShape(sys,x,y,z,v,n);
  GetShapeDerivatives(sys,x,y,z,dx,dy,dz,n);

  for (i=0;i<n;i++) 
  {
    shape = v[i];
    dshape = dx[i]; dx[i] = - log(shape) - dshape;
    dshape = dy[i]; dy[i] = - log(shape) - dshape;
    dshape = dz[i]; dz[i] = - log(shape) - dshape;
  }
}
      
// Hessian
void GetBasisHessian(vector<GaussianSet*> basis, double x, double y, double z,
 double *dxx, double *dxy, double *dxz, double *dyy, double *dyz, double *dzz)
{
  int i,ib,is,io,lla;
  GaussianShell *shell;

  double local_x[1];
  double local_y[1];
  double local_z[1];
  double local_dxx[1];
  double local_dxy[1];
  double local_dxz[1];
  double local_dyy[1];
  double local_dyz[1];
  double local_dzz[1];

  for (ib=0;ib<(signed)basis.size();ib++)
  {
    local_x[0] = x - basis[ib]->x;
    local_y[0] = y - basis[ib]->y;
    local_z[0] = z - basis[ib]->z;
    for (is=0;is<(signed)basis[ib]->shell.size();is++)
    {
      shell = basis[ib]->shell[is];
      lla = shell->ll + basis[ib]->ll;
      for (io=0;io<shell->nco;io++)
      {
        i = lla + io;
        shell->EvaluateGTOHessian(local_x,local_y,local_z,
               local_dxx,local_dxy,local_dxz,local_dyy,
               local_dyz,local_dzz,io,1);
        dxx[i] = local_dxx[0];
        dxy[i] = local_dxy[0];
        dxz[i] = local_dxz[0];
        dyy[i] = local_dyy[0];
        dyz[i] = local_dyz[0];
        dzz[i] = local_dzz[0];
      }
    }
  }
};

void GetDensityLikeHessian(Matrix *P,vector<GaussianSet*> basis,
double* x, double *y, double *z, double *dxx, double *dxy, double *dxz, 
double *dyy, double *dyz, double *dzz, int n)
{
  int io,jo;

  int nco = basis[basis.size()-1]->ul + 1;
  double row[nco];

  double gto[nco];
  double gto_dx[nco];
  double gto_dy[nco];
  double gto_dz[nco];
  double gto_dxx[nco];
  double gto_dxy[nco];
  double gto_dxz[nco];
  double gto_dyy[nco];
  double gto_dyz[nco];
  double gto_dzz[nco];

  for (int i=0;i<n;i++) 
  {
    GetBasis(basis,x[i],y[i],z[i],gto); 
    GetBasisDerivatives(basis,x[i],y[i],z[i],gto_dx,gto_dy,gto_dz);
    GetBasisHessian(basis,x[i],y[i],z[i],gto_dxx,gto_dxy,gto_dxz,gto_dyy,
      gto_dyz,gto_dzz);
    dxx[i] = 0.0;
    dxy[i] = 0.0;
    dxz[i] = 0.0;
    dyy[i] = 0.0;
    dyz[i] = 0.0;
    dzz[i] = 0.0;
    for (io=0;io<nco;io++) 
    {
      P->GetRowValues( io , row );
      for (jo=0;jo<nco;jo++) 
      {
        dxx[i] += row[jo]*(gto_dxx[io]*gto[jo]+gto[io]*gto_dxx[jo]+
                           gto_dx[io]*gto_dx[jo]+gto_dx[jo]*gto_dx[io]);
        dxy[i] += row[jo]*(gto_dxy[io]*gto[jo]+gto[io]*gto_dxy[jo]+
                           gto_dx[io]*gto_dy[jo]+gto_dx[jo]*gto_dy[io]);
        dxz[i] += row[jo]*(gto_dxz[io]*gto[jo]+gto[io]*gto_dxz[jo]+
                           gto_dx[io]*gto_dz[jo]+gto_dx[jo]*gto_dz[io]);
        dyy[i] += row[jo]*(gto_dyy[io]*gto[jo]+gto[io]*gto_dyy[jo]+
                           gto_dy[io]*gto_dy[jo]+gto_dy[jo]*gto_dy[io]);
        dyz[i] += row[jo]*(gto_dyz[io]*gto[jo]+gto[io]*gto_dyz[jo]+
                           gto_dy[io]*gto_dz[jo]+gto_dy[jo]*gto_dz[io]);
        dzz[i] += row[jo]*(gto_dzz[io]*gto[jo]+gto[io]*gto_dzz[jo]+
                           gto_dz[io]*gto_dz[jo]+gto_dz[jo]*gto_dz[io]);
      }
    }
  }
};

void GetParticleDensityHessian(GaussianGas* gas,double* x, double *y, double *z, double *dxx, double *dxy, double *dxz, double *dyy, double *dyz, double *dzz, int n,bool response)
{
  if (response) GetDensityLikeHessian(gas->P1,gas->basis,x,y,z,dxx,dxy,dxz,dyy,dyz,dzz,n);
  else GetDensityLikeHessian(gas->P,gas->basis,x,y,z,dxx,dxy,dxz,dyy,dyz,dzz,n);
};

void GetChargeDensityHessian(System* sys,double* x, double *y, double *z, double *dxx, double *dxy, double *dxz, double *dyy, double *dyz, double *dzz, int n, bool response)
{
  int i,ig;

  double dxxbuf[n],dxybuf[n],dxzbuf[n];
  double dyybuf[n],dyzbuf[n],dzzbuf[n];

  for (i=0;i<n;i++) 
  {
    dxx[i] = 0.0;
    dxy[i] = 0.0;
    dxz[i] = 0.0;
    dyy[i] = 0.0;
    dyz[i] = 0.0;
    dzz[i] = 0.0;
  }
  for (ig=0;ig<sys->ngas;ig++)
  {
    GetParticleDensityHessian(sys->gas[ig],x,y,z,dxxbuf,dxybuf,dxzbuf,
       dyybuf,dyzbuf,dzzbuf,n,response);
    for (i=0;i<n;i++) 
    {
      dxx[i] += dxxbuf[i]*sys->gas[ig]->particle_charge;
      dxy[i] += dxybuf[i]*sys->gas[ig]->particle_charge;
      dxz[i] += dxzbuf[i]*sys->gas[ig]->particle_charge;
      dyy[i] += dyybuf[i]*sys->gas[ig]->particle_charge;
      dyz[i] += dyzbuf[i]*sys->gas[ig]->particle_charge;
      dzz[i] += dzzbuf[i]*sys->gas[ig]->particle_charge;
    }
  }
}

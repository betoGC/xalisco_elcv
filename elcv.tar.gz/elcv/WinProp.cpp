/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Properties Window object
//
// 2015: Roberto Flores-Moreno
// ******************************************************************

#include <iostream>

#include <QtWidgets>

#include <WinProp.h>   
#include <Xalisco.h>
#include <Panel.h>
#include <WinPlot.h>
#include <CurvePlotter.h>
#include <Math.h>
#include <GaussianGas.h>
#include <Molecular.h>
#include <ADFT.h>
#include <QChem.h>

using namespace std;

WinProp::WinProp( Xalisco *ix , QChem *iqchem)
      : QWidget( 0 )
{
  xalisco = ix;
  qchem = iqchem;

  setWindowTitle( "Properties" );
  tabWidget = new QTabWidget;

  propBox = new QComboBox;
  propBox->addItem(QString("Av. Polarizability"));
  propBox->addItem(QString("Energy"));
  strcpy(property,(propBox->currentText().toLatin1()).data());
  connect(propBox, SIGNAL(activated(const QString &)),
          this, SLOT(ChangeProperty(const QString &)));

  theoryBox = new QComboBox;
  theoryBox->addItem(QString("ADPT"));
  theoryBox->addItem(QString("SCF"));
  theoryBox->addItem(QString("MP2"));
  strcpy(theory,(theoryBox->currentText().toLatin1()).data());
  connect(theoryBox, SIGNAL(activated(const QString &)),
          this, SLOT(ChangeTheory(const QString &)));

  QToolButton *evalButton =  new QToolButton( this );
  evalButton->setText( "Evaluate" ); 
  connect(evalButton,SIGNAL(clicked()), this,SLOT(Evaluate())); 

  QGridLayout *mainLayout = new QGridLayout;

  frame = new QWidget( 0 );
  tabWidget->addTab( frame , tr("Properties (a.u.)") );

  mainLayout->addWidget( tabWidget       , 1 , 0 , 6, 4 );
  mainLayout->addWidget( propBox         , 7 , 1 , 1, 1 );
  mainLayout->addWidget( theoryBox       , 7 , 2 , 1, 1 );
  mainLayout->addWidget( evalButton      , 7 , 3 , 1, 1 );
  setLayout( mainLayout );

  SCFListBox = new QListWidget;
  layout = new QVBoxLayout;
  layout->addWidget( SCFListBox );
  frame->setLayout( layout );
}

void WinProp::Evaluate()
{
  SCFListBox->clear();
  char str[X_MAX_STR_SIZE];
  double value = 0.0;

  if ( strncmp(property,"Energy",6) == 0 )
  {
    if ( strncmp(theory,"SCF",3) == 0 ) value = qchem->SCFEnergy();
    else if ( strncmp(theory,"MP2",3) == 0 ) 
    {
      value = qchem->SCFEnergy();
      value += qchem->MP2Energy();
    }
  }
  else if ( strncmp(property,"Av. Polarizability",18) == 0 )
  {
    if ( strncmp(theory,"ADPT",4) != 0 ) 
    {
      xalisco->ErrorMessage(__FILE__,__LINE__,"Select ADPT for this property",0);
      return;
    }
    Matrix alpha(3,3);
    qchem->Polarizability(alpha);

    cout << "xx "<<alpha(0,0)<<endl;
    cout << "xy "<<alpha(0,1)<<endl;
    cout << "xz "<<alpha(0,2)<<endl;
    cout << "yx "<<alpha(1,0)<<endl;
    cout << "yy "<<alpha(1,1)<<endl;
    cout << "yz "<<alpha(1,2)<<endl;
    cout << "zx "<<alpha(2,0)<<endl;
    cout << "zy "<<alpha(2,1)<<endl;
    cout << "zz "<<alpha(2,2)<<endl;
    value = alpha.Trace()/3.0;
  }
  sprintf( str,"%s(%s) = %20.8f\n", property,theory,value);
  SCFListBox->insertItem( 0, QString(str) );

}

void WinProp::ChangeProperty( const QString &newp )
{
  strcpy(property,(newp.toLatin1()).data());
}

void WinProp::ChangeTheory( const QString &newt )
{
  strcpy(theory,(newt.toLatin1()).data());
}

/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <math.h>
#include <string.h>

#include <iostream>

#include <DFT.h>
#include <Becke.h>
#include <QChem.h>
#include <System.h>
#include <Molecular.h>
#include <Atom.h>
#include <Math.h>
#include <Functional.h>
#include <GaussianGas.h>
#include <GaussianSet.h>
#include <GaussianShell.h>
#include <Evaluator.h>
#include <Time.h>

using namespace std;

DFT::DFT(QChem *iqchem,char *method)
{
  qchem = iqchem;
  sys = qchem->sys;
  if ( strncmp(method,"Dirac-VWN",9) == 0 ) 
    functional = new Functional((char*)"dirac",(char*)"vwn");
  else if ( strncmp(method,"Dirac-None",10) == 0 ) 
    functional = new Functional((char*)"dirac",(char*)"none");
  else if ( strncmp(method,"TST-None",8) == 0 ) 
    functional = new Functional((char*)"tst",(char*)"none");
  else if ( strncmp(method,"None-None",9) == 0 ) 
  {
    functional = 0; //rfm new Functional((char*)"none",(char*)"none");
  }
  else cout << "DFT: Invalid functional "<<endl;

  becke = new Becke();
  minrho = 1.0e-10;

  nradp = 75;
  nangp = 302;
  ngp = nradp*nangp;
  gxref = new double[ngp];
  gyref = new double[ngp];
  gzref = new double[ngp];
  gwref = new double[ngp];
  gx = new double[ngp];
  gy = new double[ngp];
  gz = new double[ngp];
  gw = new double[ngp];

  becke->BuildAtomicGrid(nradp,nangp,gxref,gyref,gzref,gwref);
}

void DFT::HirshfeldMatrix(Matrix *P0, Matrix *H, 
vector<GaussianSet*> basis, int llatom, int ulatom)
{
  int dbas,iatom,ib,ibas,igp,jbas,ll,ul;
  double rho0,rho0A,term;
  double *bas;

  dbas = H->NRow();
  bas = new double[dbas];

  P0->Print("P0x.xal","Aqui tenemos",15,5);

  H->SetZero();

  for (iatom=0;iatom<sys->mol->Natom();iatom++)
  {
    PrepareGrid(iatom);

  for (igp=0;igp<ngp;igp++)
  {
    GetBasis(basis,gx[igp],gy[igp],gz[igp],bas);
    rho0 = 0.0;
    rho0A = 0.0;
    for (ib=0;ib<(signed)basis.size();ib++)
    {
      ll = basis[ib]->ll;
      ul = basis[ib]->ul;
      for (ibas=ll;ibas<=ul;ibas++)
      {
        for (jbas=ll;jbas<=ul;jbas++)
        {
          term = bas[ibas]*bas[jbas]*(*P0)(ibas,jbas);
          rho0 += term;
          if (ib>=llatom&&ib<=ulatom) rho0A += term;
        }
      }
    }
    if (rho0A>minrho)
    {
      term = gw[igp]*(rho0A/rho0);
      for (ibas=0;ibas<dbas;ibas++)
      {
        for (jbas=ibas;jbas<dbas;jbas++)
        {
          H->ShiftValue(ibas,jbas,term*bas[ibas]*bas[jbas]);
        }
      }
    }
  }

  }
  delete[] bas;

  H->Symmetrize();
}

void DFT::PrepareGrid(int iatom)
{
  int i;
  Atom *a;

  a = sys->mol->atom[iatom];
  // Get atomic grid
  for (i=0;i<ngp;i++)
  {
    gx[i] = gxref[i] + a->x;
    gy[i] = gyref[i] + a->y;
    gz[i] = gzref[i] + a->z;
    gw[i] = gwref[i];
  }

  // Becke weights
  becke->Weigths(sys->mol,iatom,gx,gy,gz,gw,ngp);
}

void DFT::Neighbors(int iatom,int irad, vector<GaussianSet*> basis,char* option)
{
  int ib,is;
  double dist,dist2;
  double ra[3],rb[3],rc[0];

  rb[0] = sys->mol->atom[iatom]->x;
  rb[1] = sys->mol->atom[iatom]->y;
  rb[2] = sys->mol->atom[iatom]->z;
  rc[0] = gx[irad*nangp] - rb[0];
  rc[1] = gy[irad*nangp] - rb[1];
  rc[2] = gz[irad*nangp] - rb[2];
  dist2 = sqrt(rc[0]*rc[0]+rc[1]*rc[1]+rc[2]*rc[2]);
  for (ib=0;ib<(signed)basis.size();ib++)
  {
    if (strncmp(option,"find",4)==0)
    {
      ra[0] = basis[ib]->x - rb[0];
      ra[1] = basis[ib]->y - rb[1];
      ra[2] = basis[ib]->z - rb[2];
      dist = sqrt(ra[0]*ra[0]+ra[1]*ra[1]+ra[2]*ra[2]);
      basis[ib]->is_neighbor = false;
      for (is=0;is<(signed)basis[ib]->shell.size();is++)
      {
        if (dist<dist2+basis[ib]->shell[is]->Radius())
        {
          basis[ib]->is_neighbor = true;
          break;
        }
      }
    }
    else basis[ib]->is_neighbor = true;
    //rfm if (basis[ib]->is_neighbor) cout << ib << endl;
  }
}

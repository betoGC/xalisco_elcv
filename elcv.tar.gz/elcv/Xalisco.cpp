/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Functions related to Xalisco principal object
//
// 2015: Roberto Flores-Moreno
// ******************************************************************

#include <iostream>

#include <QtOpenGL/qgl.h>
#include <qcursor.h>
#include <QtWidgets>

#include <Xalisco.h>
#include <System.h>
#include <Panel.h>
#include <ElementSelector.h>
#include <Model.h>

#include <QMessageBox> 
#include <QFileDialog>

using namespace std;
Xalisco::Xalisco( System* isys, int argc , char* argv[] )
     : QApplication( argc , argv )
{
  sys = isys;

  // Check if GUI is required
  if ( argc > 2 )
  {
    if (QString(argv[2])=="JOB")
    { 
      status = QUEUED;
      strcpy(input_file,argv[1]);
      return;
    }
  } 

  panel = new Panel(this,sys);

  es = new ElementSelector(panel,0);

  // Without OpenGL support the program does not work
  if ( !QGLFormat::hasOpenGL() ) 
  {
    qWarning( "This system has no OpenGL support. Exiting." );
    quit();
  };

  panel->show();

  status = 0;
  panel->ChangeModel( QString("Balls & Sticks") );

  // Is there an input file (and format)?
  if ( argc > 2 ) 
    panel->DoReadFile(argv[1],argv[2]);
}

void Xalisco::SetCursor( const char *type )
{
  QString typestr = type;
  QCursor cursor;
  if ( typestr == "Normal" )
  {
    cursor = QCursor( Qt::ArrowCursor );
  }
  else if ( typestr == "Wait" )
  {
    cursor = QCursor( Qt::WaitCursor );
  }
  else if ( typestr == "Selection" )
  {
    cursor = QCursor( Qt::PointingHandCursor );
  };
  panel->setCursor( cursor );
} 

void Xalisco::ErrorMessage( const char* filename , int linenumber, const char*msg , int el )
{
  QString title = "Attention";
  QString text;
  if ( el )
  {
    text = "Error occurred in ";
  }
  else
  {
    text = "Warning received from "; 
  };
  text += filename;
  text += ", line number ";
  text += QString::number( linenumber );
  text += "\n";
  text += msg;
  text += "\n";

  if ( el )
  {
    (void)QMessageBox::critical( 0, title, text, QMessageBox::Ok,
                                 QMessageBox::NoButton, QMessageBox::NoButton);
  }
  else
  {
    (void)QMessageBox::warning( 0, title, text, QMessageBox::Ok,
                                 QMessageBox::NoButton, QMessageBox::NoButton);
  };

  if ( el ) closeAllWindows();
}

bool Xalisco::GetFileName(char* filename)
{
  QString filter("All Files (*.*)");
  filter +=      "\nOnly    (*.xal)";
  filter +=      "\nOnly    (*.xyz)";
  QString fn = QFileDialog::getOpenFileName(0,
                 QString("Read file"),
                 QDir::currentPath(),
                 filter);
  if ( ! ( fn.isEmpty() || fn.isNull() ) )
  {
    sprintf(filename,"%s",(fn.toLatin1()).data());
    return true;
  }
  return false;
}

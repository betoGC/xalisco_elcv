/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Declaration of class WinIon
//
// 2015: Roberto Flores-Moreno
// ******************************************************************
#ifndef X_WIN_ION_H
#define X_WIN_ION_H

#include <QtGui>
//Qt5 port
#include <QtWidgets/QToolButton>
#include <QStatusBar>
#include <QGridLayout>
#include <QSpinBox>
#include <QLabel>
#include <QComboBox>
#include <QCheckBox>


class QComboBox;
class QCheckBox;
class QToolButton;
class QDoubleSpinBox;

class Xalisco;
class Propagator;

class WinIon : public QWidget 
{
  Q_OBJECT

  public:

    WinIon(Xalisco*);

    Xalisco *xalisco;
    Propagator *propagator;

  public slots:
 
    void ChangeGas(int);
    void ChangeOrbital(int);
    void ChangeOrder(int);
    void ChangeMethod(const QString &);
    void Compute(void);
    void SetRI(void);

  protected:

    bool use_ri;
    char method[32];
    int gas_number;
    int orbital_number;
    int order;

    QStatusBar *statusbar;
    QComboBox *methodBox;

    void Report( const char*, ... );
};

#endif // WIN_ION_H


/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#ifndef X_REACTION_H
#define X_REACTION_H

#include <fstream>

#include <Parameter.h>

using namespace std;

class Species;
class Chemistry;

class Reaction
{
  public:
    Reaction(Chemistry*);

    Chemistry *chem;

    bool AddSpecies(char*,double);
    bool IsHeterogeneous(void);
    bool SetSpeciesByName(int,char*);
    int NumberOfSpecies(void);
    char* SpeciesName(int);
    double SpeciesCoefficient(int);
    double DeltaG(void);
    double Lambda(void);
    double MassAction(double,double,bool);
    double Coupling(void);
    double RateConstant(double,double,bool);
    void Clear(void);
    void Advance(double,double,double,bool);
    void SetSpeciesCoefficient(int,double);
    void SetDeltaG(double);
    void SetLambda(double);
    void SetCoupling(double);
    void Write(ofstream*);

  protected:

    double deltaG;                          // J mol^-1
    double lambda;                          // J mol^-1
    double hrpCoupling;                     // J mol

    int nspec;
    int specie_ptr[X_MAX_N_REACTANT];
    double coefficient[X_MAX_N_REACTANT];
};

#endif


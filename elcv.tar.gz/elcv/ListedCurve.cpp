/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Listed Curves
//
// 2003-2015: Roberto Flores-Moreno 
// ******************************************************************

#include <iostream>
#include <ctype.h>
#include <math.h>

#include <QtWidgets>

#include <ListedCurve.h>   
#include <Xalisco.h>
#include <CurvePlotter.h>

ListedCurve::ListedCurve( Xalisco *ix, const char* title )
           : QWidget( 0 )
{
  xalisco = ix;
  setWindowTitle( title );

  QGridLayout *mainLayout = new QGridLayout;

  anim_delay = 100;
  QSpinBox *adS = new QSpinBox( this );
  adS->setRange( 1 , 1000000 );
  adS->setSingleStep( 5 );
  adS->setValue( anim_delay );
  QLabel* lab = new QLabel(tr("Delay:"));
  lab->setBuddy(adS);
  connect( adS , SIGNAL(valueChanged( int )) ,
           this , SLOT( ChangeAnimSpeed( int ) ) );

  animButton =  new QToolButton( this );
  animButton->setText( "ANIMATE" ); 
  connect(animButton,SIGNAL(clicked()), this,SLOT(SetAnimation())); 

  frame = new QWidget( 0 );
  QVBoxLayout *layout = new QVBoxLayout;
  frame->setLayout( layout );

  plotter = new CurvePlotter( this );
  plotter->resize( 400 , 200 ); 
  connect(this,SIGNAL(selectionChanged(int)),
          plotter,SLOT(HighlightPoint(int)));

  mainLayout->addWidget( frame           , 1 , 0 , 6, 4 );
  mainLayout->addWidget( plotter         , 7 , 0 , 6, 4 );
  mainLayout->addWidget( lab             , 15 , 0 , 1, 1 );
  mainLayout->addWidget( adS             , 15 , 1 , 1, 1 );
  mainLayout->addWidget( animButton      , 15 , 2 , 1, 1 );
  setLayout( mainLayout );

  theListBox = new QListWidget;
  connect(theListBox,SIGNAL(currentRowChanged(int)),
          this,SLOT(ChangeSelection(int)));

  timer = new QTimer(this);
}

void ListedCurve::Load(QStringList thelist, double* xdata, double* ydata, int n)
{
  theListBox->clear();
  theListBox->insertItems( 0, thelist);
  (frame->layout())->addWidget( theListBox );
  plotter->SetData( xdata , ydata ,  n );
  update();
}

void ListedCurve::ChangeSelection(int n)
{
  emit selectionChanged(n);
  update();
}

void ListedCurve::Advance(void)
{
  int n = theListBox->currentRow();
  if (n+1<theListBox->count()) n++;
  else n = 0;
  theListBox->setCurrentRow(n);
  timer->start(anim_delay);
}

void ListedCurve::SetAnimation(void)
{
  if ( animButton->text() == "ANIMATE" )
  {
    connect(timer,SIGNAL(timeout()),this,SLOT(Advance()));
    animButton->setText("STOP");
    Advance();
  }
  else
  {
    disconnect(timer,SIGNAL(timeout()),this,SLOT(Advance()));
    animButton->setText("ANIMATE");
  }
}

void ListedCurve::ChangeAnimSpeed(int ns)
{
  anim_delay = ns;
}

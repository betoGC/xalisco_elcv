/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// *********************************************************
// Purpose: Declaration of class GeometryEditor
//
// 2005-2012, Roberto Flores Moreno
// *********************************************************

#ifndef X_GEOMETRY_EDITOR_H
#define X_GEOMETRY_EDITOR_H

#include <vector>

#include <QtGui>
#include <QStringList>

#include <Parameter.h>
//Qt5 port
#include <QTableWidgetItem>

#define Cartesians 0
#define ZMatrix    1

using namespace std;

class Xalisco;
class Panel;
class Molecular;

class GeometryEditor : public QWidget
{
  Q_OBJECT

  public:
    GeometryEditor( Panel* );

    Panel *panel;
    Xalisco *xalisco;
    Molecular *mol;
    int default_element;
    bool use_default;
    char gname[80];

    void Enabled( bool );
    void AddAtom( int, int, int );
    void AddGroup(int,int,int);
    void Read(char*,char*);

  public slots:

    void AddAtomStart( void );
    void AddGroupStart(const QString &);
    void DeleteAtom( void );
    void Edited(QTableWidgetItem*);
    void SetupMeasurement(const QString &);
    void BuildGroup( const QString & );    
    void ChangeCoordinates( void );
    void ChangeUnits( void );
    void Update( void );
    void FitDistance( void );
    void UseDefault( void );
    void GoRIS(int);
    void BuildTube(int);
    int SGDrv(int*);

  protected:

    bool bohr;
    char group[X_MAX_STR_SIZE];
    int CCSET;
    QTableWidget *tw;
    QStringList *Headers;
};

#endif // GEOMETRYEDITOR_H

/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <iostream>

#include <CFPIntegrator.h>
#include <GaussianGas.h>
#include <GaussianSet.h>
#include <GaussianShell.h>
#include <Vector.h>
#include <Integrator.h>
#include <Math.h>
#include <Bessel.h>
#include <Becke.h>
#include <Harmonic.h>

using namespace std;

CFPIntegrator::CFPIntegrator(GaussianGas* igas)
   : Integrator()
{
  int lmax;

  gas = igas;

  lmax = gas->LMax(gas->basis);
  if (gas->pps.size()<=0) return;

  int daop = PSDAOPointer(2*lmax+X_MAX_L_DER);
  powa = new double[daop];
  powb = new double[daop];

  // Pretabulation of bessel functions
  bessel = new Bessel(X_MAX_L+X_MAX_L_ECPS);

  // Prepare all required angular integrals
  harmonic = new Harmonic();

  // Gauss-Chebyshev abcisas and weights in [-1,1] interval
  becke = new Becke();
  Set((char*)"medium");

  // MINEXP parameter 
  minexp = -30.0;

}


// RADial quadrature.
bool CFPIntegrator::Radial(int lmax,double wbes,double *f,
double **t, double **tp, double **tpp)
{
//    BESSELP: Weighted Bessel function table of center P.
//    F      : Function base values (input).
//    LMAX   : Maximum angular quantum number of orbital product.
//    RPOW   : Radial powers of quadrature points.
//    SUCCESS: If true, requested tolerance (CFPTOL) was achieved.
//    T      : Table of radial integral values for 2p+1 abscissas.
//    TP     : Table of radial integral values for p abscissas.
//    TPP    : Table of radial integral values for (p-1)/2 abscissas.
//    WBES   : Weight for BESsel function argument.
  bool success;
  int gpstep,icyc,igp,l,llgp,n,ulgp;
  double left,r,right,wr;
  double *besselp,*rpow;

  besselp = new double[lmax+1];
  rpow = new double[lmax+1];

  llgp = 4;
  ulgp = ngp - llgp + 1;
  gpstep = llgp;
  for (n=0;n<=lmax;n++)
    for (l=n;l>=0;l -= 2)
      t[l][n] = 0.0;

  // Refinement loop 
  for (icyc=1;icyc<=3;icyc++)
  {
    for (igp=llgp-1;igp<ulgp;igp+=gpstep)
    {
      if (X_ABS(f[igp])>X_TOL_NUM)
      { 
        r = cfpr[igp];
        wr = wbes*r;
        bessel->SKMSExp(lmax,wr,besselp);
        rpow[0] = f[igp];
        for (n=1;n<=lmax;n++)
          rpow[n] = rpow[n-1]*r;
        for (n=0;n<=lmax;n++)
          for (l=n;l>=0;l -= 2)
            t[l][n] += rpow[n]*besselp[l];
      }
    }
    // Save current estimates 
    if (icyc==1)
    {
      for (n=0;n<=lmax;n++)
        for (l=n;l>=0;l -= 2)
          tpp[l][n] = llgp*t[l][n];
    }
    else if (icyc==2)
    {
      for (n=0;n<=lmax;n++)
        for (l=n;l>=0;l -= 2)
          tp[l][n] = llgp*t[l][n];
    }
    // Next refinement 
    if (icyc<3) 
    {
      gpstep = llgp;
      llgp = llgp/2;
      ulgp = ngp - llgp + 1;
    }
  }

  delete[] besselp;
  delete[] rpow;

  // Check convergence 
  success = true;
  for (n=0;n<=lmax;n++)
  {
    for (l=n;l>=0;l -= 2)
    {
      left = pow(t[l][n] - tp[l][n],2.0);
      right = X_ABS(t[l][n] - tpp[l][n]);
      if (left>tol*right) 
        if (right>tol) success = false;
    }
  }

  return success;
}

// Calculation of Central Force Potential integrals.
void CFPIntegrator::EvaluateMatrix(Matrix *H)
{
  // If there is no pseudopotential return fastly
  if (!HasPotential()) return;

  int dao,i,ib,igp,is,j,jb,js,kb,lla,llb,lmax;
  int lamax,lbmax;
  double s;
  double *v;
  double **intblk;
  GaussianShell *sa,*sb;
  Vector ra,rb,rc;

  v = new double[ngp];

  lmax = gas->LMax(gas->basis);
  dao = ((lmax+1)*(lmax+2))/2;

  intblk = new double*[dao];
  for (i=0;i<dao;i++)
    intblk[i] = new double[dao];

  // Loop over the potential centers
  for (kb=0;kb<(signed)gas->pps.size();kb++)
  {
    current_potential = kb;
    // Build potential
    for (igp=0;igp<ngp;igp++)
      v[igp] = Potential(cfpr[igp]);
    for (igp=1;igp<ngp;igp++)
      v[igp] *= cfpw[igp];
    rc = Vector(gas->pps[kb]->x,gas->pps[kb]->y,gas->pps[kb]->z);
    // Loop on primary basis shells
    for (ib=0;ib<(signed)gas->basis.size();ib++)
    {
      lamax = gas->basis[ib]->LMax();
      ra = Vector(gas->basis[ib]->x,gas->basis[ib]->y,gas->basis[ib]->z);
      rac = rc - ra;
      dca = rac.Norm();
      Monomial(lamax,rac,powa);
      for (jb=ib;jb<(signed)gas->basis.size();jb++)
      {
        lbmax = gas->basis[jb]->LMax();
        rb = Vector(gas->basis[jb]->x,gas->basis[jb]->y,gas->basis[jb]->z);
        rbc = rc - rb;
        dcb = rbc.Norm();
        Monomial(lbmax,rbc,powb);
        for (is=0;is<(signed)gas->basis[ib]->shell.size();is++)
        {
          sa = gas->basis[ib]->shell[is];
          lla = gas->basis[ib]->ll+sa->ll;
          for (js=0;js<(signed)gas->basis[jb]->shell.size();js++)
          {
            if ((jb!=ib)||(js>=is)) 
            {
              sb = gas->basis[jb]->shell[js];
              llb = gas->basis[jb]->ll+sb->ll;
              Block(sa,sb,v,intblk,0,0);
              for (i=0;i<sa->nco;i++)
                for (j=0;j<sb->nco;j++)
                  H->ShiftValue(lla+i,llb+j,
                     intblk[i][j]*sa->ncsto[i]*sb->ncsto[j]);
            }
          }
        }
      }
    }
  }
  for (i=0;i<dao;i++)
    delete[] intblk[i];
  delete[] intblk;

  delete[] v;

  H->Symmetrize();
}


// Evaluate geometry factors for Central Force Potential POLynomial expansion.
void CFPIntegrator::Monomial(int l,Vector r,double *gpow)
{
  int ic,lx,ly,lz;
  double wx,wy;
  double fx[X_MAX_L+1],fy[X_MAX_L+1],fz[X_MAX_L+1];

  fx[0] = 1.0;
  for (lx=1;lx<=l;lx++)
    fx[lx] = -fx[lx-1]*r[0];

  fy[0] = 1.0;
  for (ly=1;ly<=l;ly++)
    fy[ly] = -fy[ly-1]*r[1];

  fz[0] = 1.0;
  for (lz=1;lz<=l;lz++)
    fz[lz] = -fz[lz-1]*r[2];

  for (lx=0;lx<=l;lx++)
  {
    wx = fx[lx];
    for (ly=0;ly<=l-lx;ly++)
    {
      wy = wx*fy[ly];
      for (lz=0;lz<=l-lx-ly;lz++)
      {
        ic = gaop[lx][ly][lz];
        gpow[ic] = wy*fz[lz];
      }
    }
  }
}

// Calculation of CFP integral blocks. 
void CFPIntegrator::Block(GaussianShell *sa, GaussianShell *sb,double *v,double **intblk,int nsda,int nsdb)
{
  int daopa,daopb,i,ii,igp,j,jj,laa,lab,lbb,na,nb;
  double a2,b2,r,sfa,theta,phi,factor,expo,x,zp;
  double *rsph,*vtmp;
  double **ocint,**stoptm,**t,**tp,**tpp;
  bool ok;
  Vector *p,*vrac,*vrbc;

  // Initialize 
  laa = sa->l + nsda;
  lbb = sb->l + nsdb;
  lab = laa + lbb;

  daopa = PSDAOPointer(laa);
  daopb = PSDAOPointer(lbb);
  ocint = new double*[daopa];
  for (i=0;i<daopa;i++)
    ocint[i] = new double[daopb];

  for (i=0;i<daopa;i++)
    for (j=0;j<daopb;j++)
      ocint[i][j] = 0.0;

  vtmp = new double[ngp];

  rsph = new double[SHP(lab,lab)+1];

  stoptm = new double*[lab+1];
  for (i=0;i<=lab;i++)
    stoptm[i] = new double[2*lab+1];

  t = new double*[lab+1];
  for (i=0;i<=lab;i++)
    t[i] = new double[lab+1];

  tp = new double*[lab+1];
  for (i=0;i<=lab;i++)
    tp[i] = new double[lab+1];

  tpp = new double*[lab+1];
  for (i=0;i<=lab;i++)
    tpp[i] = new double[lab+1];

  int np = 0;
  a2 = dca*dca;
  b2 = dcb*dcb;
  for (i=0;i<(signed)sa->z.size();i++)
  {
    sfa = sa->d[i]*exp(-sa->z[i]*a2);
    if (nsda>0) sfa *= pow(sa->z[i],nsda);
    vrac = new Vector(rac);
    *vrac *= sa->z[i];
    for (j=0;j<(signed)sb->z.size();j++)
    {
      factor = sfa*sb->d[j]*exp(-sb->z[j]*b2);
      if (nsdb>0) factor *= pow(sb->z[j],nsdb);
      vrbc = new Vector(rbc);
      *vrbc *= sb->z[j];
      // Angular part
      zp = -(sa->z[i] + sb->z[j]);
      p = new Vector(rac);
      *p += *vrbc;
      *p *= 2.0;
      p->SphericalCoordinates(&r,&theta,&phi);
      harmonic->RealSphericalHarmonics(lab,theta,phi,rsph);

      ok = true;
      for (igp=0;igp<ngp;igp++)
      {
        x = cfpr[igp];          // x = r in paper
        expo = zp*x*x + r*x;    // r = 2 z_p P in paper
        if (expo>300) 
        {
          ok = false;
          break;
        }
        else if (expo<minexp) vtmp[igp] = 0.0;
        else vtmp[igp] = factor*v[igp]*exp(expo);
      }

      // Radial part 
      if (ok) ok = Radial(lab,r,vtmp,t,tp,tpp);
      if (!ok) 
      {
        np++;
        OverPrimitives(lab,sa->z[i],sb->z[j],r,t);
        for (jj=0;jj<=lab;jj++)
          for (ii=jj;ii>=0;ii-=2)
            t[ii][jj] *= factor;
      }
      OneCenter(laa,lbb,rsph,ocint,stoptm,t);
    }
  }
  //double perc = 100.0*double(np)/(double(sa->z.size())*double(sb->z.size()));
  //cout << perc <<"\% over primitives"<<endl;

  delete[] vtmp;
  delete[] rsph;

  for (i=0;i<=lab;i++)
    delete[] stoptm[i];
  delete[] stoptm;

  for (i=0;i<=lab;i++)
    delete[] t[i];
  delete[] t;

  for (i=0;i<=lab;i++)
    delete[] tp[i];
  delete[] tp;

  for (i=0;i<=lab;i++)
    delete[] tpp[i];
  delete[] tpp;

  // Evaluate the integral using the one-center blocks 
  ThreeCenter(laa,lbb,ocint,intblk);

  na = ((laa+1)*(laa+2))/2;
  nb = ((lbb+1)*(lbb+2))/2;
  for (i=0;i<na;i++)
    for (j=0;j<nb;j++)
      intblk[i][j] *= 4.0*X_PI;

  for (i=0;i<daopa;i++)
    delete[] ocint[i];
  delete[] ocint;
}


void CFPIntegrator::ThreeCenter(int la,int lb,double **ocint,double **intblk)
{
  int daop,i,j;
  int akc,ax,ay,az,as,ckax,ckay,ckaz,kac,kax,kay,kaz,na;
  int bkc,bx,by,bz,bs,ckbx,ckby,ckbz,kbc,kbx,kby,kbz,nb;
  double bax,bay,baz;
  double bbx,bby,bbz;
  double **tblk;

  na = ((la+1)*(la+2))/2;
  nb = ((lb+1)*(lb+2))/2;
  for (i=0;i<na;i++)
    for (j=0;j<nb;j++)
      intblk[i][j] = 0.0;

  daop = PSDAOPointer(lb);
  tblk = new double*[na];
  for (i=0;i<na;i++)
    tblk[i] = new double[daop];

  for (i=0;i<na;i++)
    for (j=0;j<daop;j++)
      tblk[i][j] = 0.0;

  // Left side expansion
  for (ax=0;ax<=la;ax++)
  {
    for (ay=0;ay<=la-ax;ay++)
    {
      az = la - ax - ay;
      as = raop[ax][ay][az];
      for (kax=0;kax<=ax;kax++)
      {
        bax = Noverk(ax,kax);
        ckax = ax - kax;
        for (kay=0;kay<=ay;kay++)
        {
          bay = bax*Noverk(ay,kay);
          ckay = ay - kay;
          for (kaz=0;kaz<=az;kaz++)
          {
            ckaz = az - kaz;
            akc = gaop[ckax][ckay][ckaz];
            baz = bay*powa[akc]*Noverk(az,kaz);
            if (X_ABS(baz)>X_TOL_NUM) 
            {
              kac = gaop[kax][kay][kaz];
              for (kbc=0;kbc<daop;kbc++)
                tblk[as][kbc] += ocint[kac][kbc]*baz;
            }
          }
        }
      }
    }
  }

  // Right side expansion 
  for (bx=0;bx<=lb;bx++)
  {
    for (by=0;by<=lb-bx;by++)
    {
      bz = lb - bx - by;
      bs = raop[bx][by][bz];
      for (kbx=0;kbx<=bx;kbx++)
      {
        bbx = Noverk(bx,kbx);
        ckbx = bx - kbx;
        for (kby=0;kby<=by;kby++)
        {
          bby = bbx*Noverk(by,kby);
          ckby = by - kby;
          for (kbz=0;kbz<=bz;kbz++)
          {
            ckbz = bz - kbz;
            bkc = gaop[ckbx][ckby][ckbz];
            bbz = bby*powb[bkc]*Noverk(bz,kbz);
            if (X_ABS(bbz)>X_TOL_NUM) 
            {
              kbc = gaop[kbx][kby][kbz];
              for (as=0;as<na;as++)
                intblk[as][bs] += tblk[as][kbc]*bbz;
            }
          }
        }
      }
    }
  }
  for (i=0;i<na;i++)
    delete[] tblk[i];
  delete[] tblk;
}

// Calculation of CFP One-Center INTegral blocks. 
void CFPIntegrator::OneCenter(int la, int lb,double *rsph, double **ocint,
double **stoptm, double **t)
{
  int kax,kay,kaz,kbx,kby,kbz,kx,ky,kz;
  int i,k,kac,kbc,l,m;
  double factor;

  // Left loop
  for (kax=0;kax<=la;kax++)
  {
    for (kay=0;kay<=la-kax;kay++)
    {
      for (kaz=0;kaz<=la-kax-kay;kaz++)
      {
        kac = gaop[kax][kay][kaz];
        // Right loop 
        for (kbx=0;kbx<=lb;kbx++)
        {
         kx = kax + kbx;
          for (kby=0;kby<=lb-kbx;kby++)
          {
            ky = kay + kby;
            for (kbz=0;kbz<=lb-kbx-kby;kbz++)
            {
              kz = kaz + kbz;
              kbc = gaop[kbx][kby][kbz];
              // Build one-center integral
              harmonic->SphericalToPolynomial(kx,ky,kz,stoptm);
              k = kx + ky + kz;
              for (l=k;l>=0;l-=2)
              {
                factor = rsph[SHP(l,l)]*stoptm[l][0];
                for (m=-l+1;m<=l;m++)
                {
                  factor += rsph[SHP(l,m)]*stoptm[l][l+m];
                }
                ocint[kac][kbc] += factor*t[l][k];
              }
            }
          }
        }
      }
    }
  }
}

// Perform one-dimensional adaptive Gauss-Chebyshev 
// quadratures over primitive Gaussians for Central
// Force Potential radial part.
// History: - Creation (25.10.05, RFM)
void CFPIntegrator::OverPrimitives(int lmax,double za,double zb,double wbes,double **t)
{
  bool converged;
  int gpstep,igp,l,llgp,lmax1,n,local_ngp,ulgp;
  double a,b,expf,expo,left,r,right,w;
  double *besselp,*rpow;
  double **tp,**tw,**tpp;

  lmax1 = lmax + 1;
  besselp = new double[lmax1];
  rpow = new double[lmax1];

  tp = new double*[lmax1];
  tw = new double*[lmax1];
  tpp = new double*[lmax1];
  for (l=0;l<=lmax;l++)
  {
    tp[l] = new double[lmax1];
    tw[l] = new double[lmax1];
    tpp[l] = new double[lmax1];
  }

  // Linear mapping 
  InitializeMapping(za,zb,&a,&b);

  converged = false;
  local_ngp = ((ngp - 1)/2 - 1)/2;
  llgp = int(pow(2,ncycmax-1));
  ulgp = ngpmax - llgp + 1;
  gpstep = llgp;
  for (n=0;n<=lmax;n++)
    for (l=n;l>=0;l -= 2)
      tw[l][n] = 0.0; 
  while (!converged)
  {
    for (igp=llgp-1;igp<ulgp;igp+=gpstep)
    {
      Map(a,b,x[igp],wx[igp],&r,&w);
      expo = - za*pow(dca-r,2.0) - zb*pow(dcb-r,2.0);
      if (expo>=minexp) 
      {
        expf = Potential(r);
        expf = w*expf*exp(expo);
        rpow[0] = expf;
        for (l=1;l<=lmax;l++)
          rpow[l] = rpow[l-1]*r;
        bessel->SKMSExp(lmax,wbes*r,besselp);
        for (n=0;n<=lmax;n++)
          for (l=n;l>=0;l -= 2)
            tw[l][n] += rpow[n]*besselp[l];
      }
    }
    for (n=0;n<=lmax;n++)
      for (l=n;l>=0;l -= 2)
      {
        tpp[l][n] = tp[l][n];
        tp[l][n] = t[l][n];
        t[l][n] = llgp*tw[l][n];
      }
    if (local_ngp>=ngp) 
    {
      converged = true;
      for (n=0;n<=lmax;n++)
        for (l=n;l>=0;l -= 2)
        {
          left = pow(t[l][n] - tp[l][n],2.0);
          right = X_ABS(t[l][n] - tpp[l][n]);
          if (left>tol*right) 
          {
            if (right>tol) 
            { 
              converged = false;
              break;
            }
          }
        }
      if ((local_ngp==ngpmax)&&(!converged)) 
      {
        cout << "CFP quadrature failed"<<endl;
        break;
      }
    }
    local_ngp = 2*local_ngp + 1;
    gpstep = llgp;
    llgp = llgp/2;
    ulgp = ngpmax - llgp + 1;
  }

  // Release memory
  for (l=0;l<=lmax;l++)
  {
    delete[] tp[l];
    delete[] tw[l];
    delete[] tpp[l];
  }
  delete[] tp;
  delete[] tw;
  delete[] tpp;

  delete[] besselp;
  delete[] rpow;
}

// Central Force Potential quadrature MAPping utility.
void CFPIntegrator::Map(double a,double b,double x,double wx,double *r,double *wr)
{
  // Linear mapping: (-1,1) ==> (r_min,r_max)
  *r = a*x + b; 
  *wr = a*wx;
}

// Central Force Potential quadrature MAPping utility.
void CFPIntegrator::InitializeMapping(double za,double zb,double *a,double *b)
{
  double p,rmax,rmin,sigma,zp;

  // Linear mapping: (-1,1) ==> (r_min,r_max) 
  // Get parameters 
  zp = za + zb;
  p = (za*dca + zb*dcb)/zp;
  sigma = 1.0/sqrt(zp);

  // Radial limits 
  rmin = X_MAX(0.0,p - 7.0*sigma);
  rmax = p + 9.0*sigma;

  // Mappint factors
  *a = 0.5*(rmax - rmin);
  *b = 0.5*(rmax + rmin);
}

void CFPIntegrator::Set(char* option)
{
  if (strncmp(option,"coarse",6) == 0 ) 
  {
    tol = 1.0e-7;
    ngp = 67;
  }
  else if (strncmp(option,"medium",6) == 0 ) 
  {
    tol = 1.0e-8;
    ngp = 99;
  }
  else if (strncmp(option,"fine",4) == 0 ) 
  {
    tol = 1.0e-9;
    ngp = 131;
  }
  else if (strncmp(option,"reference",9) == 0 ) 
  {
    tol = 1.0e-10;
    ngp = 195;
  }

  cfpr = new double[ngp];
  cfpw = new double[ngp];

  becke->RadialQuadratures(cfpr,cfpw,ngp);

  ngpmax = ngp;
  ncycmax = 0;
  while (ngpmax<MAXGP_CFP)
  {
    ngpmax = 2*ngpmax + 1;
    ncycmax = ncycmax + 1;
  }
  ngpmax = (ngpmax-1)/2;
  ncycmax = ncycmax + 2;
  becke->TSKGC(x,wx,ngpmax);
}

double CFPIntegrator::Potential(double r)
{
  int ks;
  double v;
  GaussianShell *sc;

  // Build potential
  v = 0.0;
  for (ks=0;ks<(signed)gas->pps[current_potential]->shell.size();ks++)
  {
    sc = gas->pps[current_potential]->shell[ks];
    if (sc->type==CENTRAL_FORCE_SHELL)
      v += pow(r,double(sc->n+2))*sc->RadialPotential(r);
  }
  return v;
}

bool CFPIntegrator::HasPotential()
{
  int kb,ks;
  GaussianShell *sc;

  for (kb=0;kb<(signed)gas->pps.size();kb++)
  {
    for (ks=0;ks<(signed)gas->pps[kb]->shell.size();ks++)
    {
      sc = gas->pps[kb]->shell[ks];
      if (sc->type==CENTRAL_FORCE_SHELL) 
        return true;
    }
  }
  return false;
}


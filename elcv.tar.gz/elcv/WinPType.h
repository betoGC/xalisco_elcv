/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Declaration of class WinPType
//
// 2015: Roberto Flores-Moreno
// ******************************************************************
#ifndef X_WIN_PTYPE_H
#define X_WIN_PTYPE_H

#include <QtGui>

#include <Parameter.h>
//Qt5 port
#include <QtWidgets/QToolButton>
#include <QComboBox>
#include <QLabel>
#include <QDoubleSpinBox>
#include <QGridLayout>
#include <QCheckBox>

class QComboBox;
class QCheckBox;
class QToolButton;
class QDoubleSpinBox;

class QChem;

class WinPType : public QWidget 
{
  Q_OBJECT

  public:

    WinPType(QChem*,int);

    QChem *qchem;

  public slots:
 
    void ChangeAlpha(double);
    void ChangeBeta(double);
    void Default(void);
    void ChangeBasis( const QString & );
    void ChangePseudos( const QString & );
    void ChangeMethod( const QString & );
    void ChangeGuess( const QString & );
    void SetRestricted(void);
    void SetProjected(void);
    void SetDirect(void);

  protected:

    int type;

    QComboBox *guessBox;
    QComboBox *methodBox;
    QComboBox *basisBox;
    QComboBox *potBox;

    QToolButton *contButton;
    QToolButton *setButton;
    QToolButton *stepButton;

    QDoubleSpinBox *alphaSpin;
    QDoubleSpinBox *betaSpin;

    QCheckBox* dirbox;
    QCheckBox* projbox;
    QCheckBox* resbox;
};

#endif // X_WIN_PTYPE_H


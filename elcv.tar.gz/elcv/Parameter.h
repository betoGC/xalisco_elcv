/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#ifndef X_PARAMETER_H
#define X_PARAMETER_H
 
#define ELECTRON 0
#define PROTON   1
#define SOLVENT  2
#define NTYPES   3

// Tolerances
#define X_TOL_NUM  1.0e-14

// Strings
#define X_MAX_STR_SIZE 256

// Orbital calculations
#define X_MAX_ATOMIC_NUMBER 103+2
#define X_MAX_CON      40
#define X_MAX_L_DER     1
#define X_MAX_L_BASIS   4
#define X_MAX_L_ECPS    4
#define X_MAX_L       X_MAX_L_BASIS+X_MAX_L_DER
#define X_MAX_L_I     X_MAX_L+X_MAX_L_BASIS
#define X_MAX_NCO     ((X_MAX_L+1)*(X_MAX_L+2))/2
#define X_MAX_TAB_GAM 120
#define X_MAX_N_GAS     5
#define X_MAX_NRQP    200

// Chemistry calculations
#define X_MAX_N_SPECIES    20
#define X_MAX_N_REACTIONS  20
#define X_MAX_N_REACTANT   10
#define X_MAX_N_NEIGH       6      //  6 faces of parallelepiped

#endif // PARAMETER_H

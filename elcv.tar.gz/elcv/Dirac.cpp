/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <Dirac.h>
#include <Math.h>

// Dirac exchange functional
// P. A. M. Dirac, Proc. Cambridge Phil. Soc. 26, 376 (1930).
double dirac_energy(double rho)
{
  double factor;
  double ex;

  factor = 4.0/3.0;
  ex = pow(2.0*rho,factor);
  factor = -0.75*pow(3.0/X_PI,(1.0/3.0));
  ex *= factor;
  return ex;
}

// Evaluates Dirac exchange potential
double dirac_potential(double rho)
{
 return -(pow(3.0/X_PI,1.0/3.0))*pow(2.0*rho,1.0/3.0);
}

// Evaluates Dirac exchange kernel
double dirac_kernel(double rho)
{
  double r13;

  r13 = 1.0/3.0;
  return -r13*pow(6.0/X_PI,r13)*pow(rho,-2.0*r13);
}

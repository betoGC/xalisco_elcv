/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <iostream>

#include <Xalisco.h>
#include <Propagator.h>
#include <System.h>
#include <QChem.h>
#include <GaussianGas.h>
#include <Units.h>
#include <Math.h>

using namespace std;

Propagator::Propagator()
{
}

double Propagator::IonizationEnergy(System *sys, int gas, int orbital, int order, bool i_use_ri)
{
  double pe;

  use_ri = i_use_ri;

  pe = sys->gas[gas]->GetOrbitalEnergy(orbital);
  if ( order > 1 ) 
  {
    // Newthon-Raphson
    double corr,s,ds,pekt,ppe,ps;
    double tol = eVToHartree(0.001);

    pekt = pe;
    ps = 1.0;
    for (int it=0;it<10;it++)
    {
      ppe = pe;
      cout << "eV = "<<HartreeToeV(pe) << "   "<<ps<<endl;
      SelfEnergy_GP(sys,gas,orbital,order,pe,&s,&ds);
      ps = 1.0/(1.0-ds);
      pe = ps*(pekt+s-ds*ppe);
      corr = pe - ppe;
      if (X_ABS(corr)<tol) 
      {
        corr = pe - pekt - s;
        if (X_ABS(corr)>tol) 
          continue;
        break;
      }
    }
  }

  return pe;
}

void Propagator::SelfEnergy_GP(System *sys, int gas, int orbital, int order, double omega, double *s,double *ds)
{
  if (order<2)
  { 
    *s = 0.0;
    *ds = 0.0;
  }
  else if (order==2)
  {
    SelfEnergy_GP2(sys,gas,orbital,omega,s,ds);
    //*s += GW1(sys,orbital,sys->gas[gas]);
  }
  else
  {
    cout << "Do not know wath to do"<<endl;
  }
}


// Self-Energy for QP EPT
// Lit:   R. Flores-Moreno, V. G. Zakrzewski and J. V. Ortiz, 
//        J. Chem. Phys. 127, 134106 (2007).
// 2008-2012, Roberto Flores-Moreno
void Propagator::SelfEnergy_GP2(System *sys,int gid, int p, double omega,
double *s,double *ds)
{
  int nmoo,nmoo2;
  int i,ig,j,a,b,q;
  int dorb,dorb2;
  double aaw,e,t,d;

  // initialize
  aaw = sqrt(0.5);
  dorb = sys->gas[gid]->nmo;
  nmoo = sys->gas[gid]->HOMO + 1;

  double eig[dorb];
  for (q=0;q<dorb;q++)
    eig[q] = sys->gas[gid]->GetOrbitalEnergy(q);

  *s = 0.0;
  *ds = 0.0;
  for (ig=0;ig<sys->ngas;ig++)
  {
    dorb2 = sys->gas[ig]->nmo;
    nmoo2 = sys->gas[ig]->HOMO + 1;
    double eig2[dorb2];
    for (q=0;q<dorb2;q++)
      eig2[q] = sys->gas[ig]->GetOrbitalEnergy(q);

    Matrix eri(sys->gas[gid]->nco,sys->gas[ig]->nco); // NCO >= NMO

    for (q=0;q<dorb2;q++)
    {
      if (use_ri) sys->gas[gid]->EvaluateERI4BatchRI(sys->gas[ig],p,q,eri);
      else sys->gas[gid]->EvaluateERI4Batch(sys->gas[ig],p,q,eri);
      // 2ph
      if (q<nmoo2) 
      {
        for (a=nmoo;a<dorb;a++)
          for (b=nmoo2;b<dorb2;b++)
          {
            d = omega + eig2[q] - eig[a] - eig2[b];
            if (X_ABS(d)>X_TOL_NUM) // Avoid zero in denominator
            {
              if (ig==gid) e = (eri(a,b) - eri(b,a))*aaw;
              else e = eri(a,b);
              t = e*e/d;
              *s += t;
              *ds -= t/d;
            }
          }
      }
      // 2hp
      else
      {
        for (i=0;i<nmoo;i++)
          for (j=0;j<nmoo2;j++)
          {
            d = omega + eig2[q] - eig[i] - eig2[j];
            if (X_ABS(d)>X_TOL_NUM) // Avoid zero in denominator
            {
              if (ig==gid) e = (eri(i,j)-eri(j,i))*aaw;
              else e = eri(i,j);
              t = e*e/d;
              *s += t;
              *ds -= t/d;
            }
          }
      }
    }
  }
}

double Propagator::GW1(System* sys, int p,GaussianGas *g)
{
  if (!sys->qchem->adft) return 0.0;

  int i,j;
  double intval,selfe;

  Matrix eri(g->nco,g->nco);

  g->EvaluateERI4Batch(g,p,p,eri);

  selfe = 0.0;
  // Add Hartree-Fock exchange
  for (i=0;i<=g->HOMO;i++)
  {
    intval = -eri(i,i);
    selfe += intval;
  }

  // Remove Vxc effect
  eri.SetZero();
  if (sys->qchem->adft) g->TwoParticleMatrixDF(&eri,g,g->z,1.0);
  double vpp = 0.0;
  for (i=0;i<g->nco;i++)
    for (j=0;j<g->nco;j++)
      vpp += (*g->C)(i,p)*(*g->C)(j,p)*eri(i,j);
  selfe -= vpp;

  return selfe;
}

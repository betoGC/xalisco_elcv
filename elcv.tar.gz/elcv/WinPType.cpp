/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: class WinQChem functions. 
//
// 2012: Roberto Flores-Moreno
// ******************************************************************

#include <fstream>
#include <iomanip>

#include <WinPType.h>   
#include <System.h>   
#include <Molecular.h>   
#include <QChem.h>   
#include <SCF.h>   

using namespace std;

WinPType::WinPType(QChem* iqchem, int itype)
      : QWidget( 0 )
{
  qchem = iqchem;
  type = itype;

  guessBox = new QComboBox;
  guessBox->addItem(QString("Core"));
  guessBox->addItem(QString("File"));
  ChangeGuess( guessBox->currentText() );
  connect(guessBox, SIGNAL(activated(const QString &)),
          this, SLOT(ChangeGuess(const QString &)));

  methodBox = new QComboBox;
  methodBox->addItem(QString("Hartree-Fock"));
  if (type==ELECTRON)
  {
    methodBox->addItem(QString("Dirac-VWN"));
  }
  methodBox->addItem(QString("None-None"));
  ChangeMethod( methodBox->currentText() );
  connect(methodBox, SIGNAL(activated(const QString &)),
          this, SLOT(ChangeMethod(const QString &)));

  basisBox = new QComboBox;
  if (type==ELECTRON)
  {
    basisBox->addItem(QString("6-311G"));
    basisBox->addItem(QString("DZVP"));
    basisBox->addItem(QString("QECP19|LANL2DZ"));
    basisBox->addItem(QString("DZ-ANO"));
    basisBox->addItem(QString("STO-3G"));
    basisBox->addItem(QString("4-31G"));
    basisBox->addItem(QString("CC-PVDZ"));
    basisBox->addItem(QString("CC-PVTZ"));
    basisBox->addItem(QString("CC-PVQZ"));
    basisBox->addItem(QString("CC-PV5Z"));
  }
  else if (type==PROTON)
  {
    basisBox->addItem(QString("DZVP"));
    basisBox->addItem(QString("DZSPDH"));
    basisBox->addItem(QString("STO-3G"));
  }
  else if (type==SOLVENT)
  {
    basisBox->addItem(QString("SODIUM"));
    basisBox->addItem(QString("ARGON"));
  }
  QLabel* basislab = new QLabel(tr("Basis:"));
  basislab->setBuddy(basisBox);
  ChangeBasis( basisBox->currentText() );
  connect(basisBox, SIGNAL(activated(const QString &)),
          this, SLOT(ChangeBasis(const QString &)));

  potBox = new QComboBox;
  potBox->addItem(QString("NONE"));
  if (type==ELECTRON)
  {
    potBox->addItem(QString("QECP19|LANL2DZ"));
  }
  else if (type==PROTON)
  {
    //potBox->addItem(QString("NONE"));
  }
  else if (type==SOLVENT)
  {
    potBox->addItem(QString("SODIUM"));
  }
  QLabel* potlab = new QLabel(tr("Pseudos:"));
  potlab->setBuddy(potBox);
  ChangePseudos( potBox->currentText() );
  connect(potBox, SIGNAL(activated(const QString &)),
          this, SLOT(ChangePseudos(const QString &)));

  alphaSpin = new QDoubleSpinBox( this );
  alphaSpin->setRange( 0.0 , 100000.0 );
  alphaSpin->setSingleStep( 1.0 );
  alphaSpin->setDecimals( 0 );
  alphaSpin->setValue( 0.0 );
  QLabel* alphalab = new QLabel(tr("No. alpha:"));
  alphalab->setBuddy(alphaSpin);
  ChangeAlpha( alphaSpin->value() );
  connect( alphaSpin , SIGNAL(valueChanged( double )) ,
           this, SLOT( ChangeAlpha( double ) ) );

  betaSpin = new QDoubleSpinBox( this );
  betaSpin->setRange( 0.0 , 100000.0 );
  betaSpin->setSingleStep( 1.0 );
  betaSpin->setDecimals( 0 );
  betaSpin->setValue( 0.0 );
  QLabel* betalab = new QLabel(tr("No. beta:"));
  betalab->setBuddy(betaSpin);
  ChangeBeta( betaSpin->value() );
  connect( betaSpin , SIGNAL(valueChanged( double )) ,
           this, SLOT( ChangeBeta( double ) ) );

  QGridLayout *mainLayout = new QGridLayout;

  resbox = new QCheckBox( this );
  resbox->setText( QString("Restricted SCF") ); 
  connect( resbox , SIGNAL( clicked() ) , this , SLOT( SetRestricted() ) );

  projbox = new QCheckBox( this );
  projbox->setText( QString("Project MOs") ); 
  connect( projbox , SIGNAL( clicked() ) , this , SLOT( SetProjected() ) );

  dirbox = new QCheckBox( this );
  dirbox->setText( QString("Direct") ); 
  connect( dirbox , SIGNAL( clicked() ) , this , SLOT( SetDirect() ) );

  contButton =  new QToolButton( this );  
  contButton->setText( "Count" );
  connect( contButton,SIGNAL(clicked()),this,SLOT(Default()));

  mainLayout->addWidget( basislab    ,      1 , 0 , 1 , 1);
  mainLayout->addWidget( basisBox    ,      1 , 1 , 1 , 1);
  mainLayout->addWidget( potlab      ,      1 , 2 , 1 , 1);
  mainLayout->addWidget( potBox      ,      1 , 3 , 1 , 1);

  mainLayout->addWidget( alphalab    ,      2 , 0 , 1 , 1);
  mainLayout->addWidget( alphaSpin   ,      2 , 1 , 1 , 1);
  mainLayout->addWidget( betalab     ,      2 , 2 , 1 , 1);
  mainLayout->addWidget( betaSpin    ,      2 , 3 , 1 , 1);

  mainLayout->addWidget( resbox      ,     3 , 0 , 1 , 1);
  mainLayout->addWidget( projbox     ,     3 , 1 , 1 , 1);
  mainLayout->addWidget( dirbox      ,     3 , 2 , 1 , 1);

  mainLayout->addWidget( contButton   ,     4 , 0 , 1 , 1);
  mainLayout->addWidget( methodBox    ,     4 , 1 , 1 , 1);
  mainLayout->addWidget( guessBox     ,     4 , 3 , 1 , 1);

  setLayout( mainLayout );
}

void WinPType::Default()
{
  // Count electrons
  int npart = qchem->sys->mol->NumberOfParticles(type);

  int nbeta = npart/2;
  int nalpha = npart - nbeta;

  qchem->sys->ChangeAlpha( double(nalpha) , type); 
  qchem->sys->ChangeBeta( double(nbeta) , type);
  
  alphaSpin->setValue( double(nalpha) );
  betaSpin->setValue( double(nbeta) );
}

void WinPType::ChangeBasis( const QString &newbas )
{
  qchem->ChangeBasis( (newbas.toLatin1()).data(), type );
}

void WinPType::ChangePseudos( const QString &newpot )
{
  qchem->ChangePseudos( (newpot.toLatin1()).data(), type );
}

void WinPType::ChangeMethod( const QString &newmethod )
{
  qchem->ChangeMethod( (newmethod.toLatin1()).data(), type );
}

void WinPType::ChangeGuess( const QString &newguess )
{
  qchem->ChangeGuess( (newguess.toLatin1()).data(), type );
}

void WinPType::SetRestricted( )
{ 
  qchem->ChangeRestricted(type);
}
void WinPType::SetProjected( )
{ 
  qchem->ChangeProjected(type);
}
void WinPType::SetDirect( )
{ 
  qchem->ChangeDirect(type);
}

void WinPType::ChangeAlpha( double n )
{
  qchem->sys->ChangeAlpha( n , type );
}

void WinPType::ChangeBeta( double n )
{
  qchem->sys->ChangeBeta( n , type );
}


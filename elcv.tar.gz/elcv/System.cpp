/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Definition of System
//
// 2015: Roberto Flores Moreno
// ******************************************************************

#include <stdlib.h>
#include <math.h>
#include <string.h>

#include <iostream>
#include <fstream>

#include <System.h>
#include <Molecular.h>
#include <Element.h>
#include <Atom.h>
#include <GaussianGas.h>
#include <GaussianSet.h>
#include <ADFT.h>
#include <SCF.h>
#include <QChem.h>
#include <Units.h>

using namespace std;

System::System()
{
  mol = new Molecular();
  ngas = 0;
  charges = 0;

  temperature = 0.0;    // Standard orbital calculations
  chemical_potential = 0.0;   
};

void System::Setup(QChem *iqchem, char basname[NTYPES][X_MAX_STR_SIZE])
{
  qchem = iqchem;

  if (ngas>0)
    for (int i=0;i<ngas;i++)
      delete gas[i];

  ngas = 0;
  for (int itype=0;itype<NTYPES;itype++)
  {
    if (nalpha[itype]>0)
    {
      gas[ngas] = new GaussianGas(this,ngas,itype,nalpha[itype]);
      gas[ngas]->FromMolecular(mol,basname[itype]);
      if (gas[ngas]->nco<1) cout << "Something was wrong in setting gas"<<endl;
      ngas++;
    }
    if (nbeta[itype]>0)
    {
      gas[ngas] = new GaussianGas(this,ngas,itype,nbeta[itype]);
      gas[ngas]->FromMolecular(mol,basname[itype]);
      if (gas[ngas]->nco<1) cout << "Something was wrong in setting gas"<<endl;
      ngas++;
    }
  }
  if (nalpha[PROTON]>0||nbeta[PROTON]>0) mol->Nullify(PROTON);
  if (nalpha[SOLVENT]>0||nbeta[SOLVENT]>0) mol->Nullify(SOLVENT);
}

void System::Print(char* filename)
{
  ofstream f(filename);

  f << "   " << mol->Natom() << endl;
  f << "Geometry is given in angstroms "<<endl;
  for (int iatom=0;iatom<mol->Natom();iatom++)
  {
    Atom* a = mol->atom[iatom];
    f << a->label << "   " 
      << BohrToAngstrom(a->x) << "   " 
      << BohrToAngstrom(a->y) << "   " 
      << BohrToAngstrom(a->z) << "   " 
      << endl;
  }
  f << endl;

  f << endl;
  f << "Subsystems: "<<endl;
  f << endl;
  f.close();
  for (int ig=0;ig<ngas;ig++)
  {
    ofstream ff(filename,ios::app);
    ff << "Subsystem ID: "<<ig<<endl;
    ff.close();
    gas[ig]->Print(filename);
  }

};

void System::PrepareCharges(char* popan, bool response)
{
  int i,ig;

  if (charges) delete[] charges;
  charges = new double[mol->Natom()];

  for (i=0;i<mol->Natom();i++)
    if (response) charges[i] = 0.0;
    else charges[i] = mol->atom[i]->charge;

  if (strncmp(popan,"Hirshfeld",9)==0)
  {
    int iatom,ig,nco,thegas;

    for (ig=0;ig<ngas;ig++)
      if (gas[ig]->type==ELECTRON) thegas = ig;
    nco = gas[thegas]->nco;
    Matrix *P0 = new Matrix(nco,nco);
    qchem->EvaluatePromolecularDensity(P0);
    Matrix *S = new Matrix(nco,nco);
    DFT *dft = new DFT(qchem,(char*)"None-None");
    for (iatom=0;iatom<mol->Natom();iatom++)
    {
      dft->HirshfeldMatrix(P0,S,gas[thegas]->basis,iatom,iatom);
      for (ig=0;ig<ngas;ig++)
      {
        if (response) charges[iatom] += gas[ig]->P1->QTrace(S); // NOTE: sign removed for e
        else charges[iatom] += gas[ig]->P->QTrace(S)*gas[ig]->particle_charge;
      }
    };
    delete dft;
    delete P0;
    delete S;
  } 
  else
  {
    double *gas_charges;
    gas_charges = new double[mol->Natom()];

    for (ig=0;ig<ngas;ig++)
    {
      gas[ig]->EvaluateCharges(gas_charges,popan,response);
      for (i=0;i<mol->Natom();i++)
        charges[i] += gas_charges[i];
    }
    delete[] gas_charges;
  }
}


double System::GetAtomCharge(int id)
{
  double ret;

  ret = 0.0;

  if (id>=0&&id<mol->Natom())
    if (charges) ret = charges[id];

  return ret;
}

double System::Alpha(int type) { return nalpha[type]; } 
double System::Beta(int type) { return nbeta[type]; } 
void System::ChangeAlpha( double n, int type ) { nalpha[type] = n; } 
void System::ChangeBeta( double n, int type ) { nbeta[type] = n; } 


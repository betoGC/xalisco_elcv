/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <Units.h>
#include <Math.h>

// === Energy ===

// Conversion factor taken from ?
double HartreeToeV(double a) { return ((a)*27.21138466); };
double eVToHartree(double a) { return ((a)/27.21138466); };

// Conversion factor taken from the book
// "Physical Chemistry: A Molecular Approach", D. A. McQuarrie and J. D. Simon,
// University Science Books (Sausalito CA, 1997).
double HartreeToJMol(double a) { return ((a)*2625500.0); };
double JMolToHartree(double a) { return ((a)/2625500.0); };

// === Length ===

// Conversion factor taken from deMon2k 4.0.8
double AngstromToBohr(double a) { return ((a)*1.8897261349309467); }; 
double BohrToAngstrom(double a) { return ((a)/1.8897261349309467); };

// === Angles ===
double DegreeToRadian(double deg) { return X_PI*deg/180.0; }; 
double RadianToDegree(double rad) { return 180.0*rad/X_PI; };


/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Declaration of class SCFWin
//
// 2003-2015: Roberto Flores Moreno
// ******************************************************************

#ifndef X_WIN_SCF_H
#define X_WIN_SCF_H

#include <vector>

#include <QtGui>
//Qt5 port
#include <QListWidget>
#include <QVBoxLayout>
#include <QToolButton>
#include <QCheckBox>
using namespace std;

class Xalisco;
class QChem;
class CurvePlotter;

class WinSCF : public QWidget
{
  Q_OBJECT

  public:
    WinSCF( Xalisco*, QChem* );

    Xalisco *xalisco;
    QChem *qchem;

    void Setup(void);
    void Enabled( bool );

  public slots:

    void Converge(void);
    void Step(void);
    void Start(void);
    void Stop(void);
    void SetGraphical(void);
    void ChangeMixing(double);
    void ChangeConstrainType(const QString &);
    void ChangeConstrainCharge(double);
    void ChangeConstrainLastAtom(int);

  protected:

    bool graphical;
    double error;
    vector<double> energies;
    QTimer* timer;
    QTabWidget *tabWidget;
    QVBoxLayout *layout;
    QWidget* frame;
    QListWidget *SCFListBox;
    CurvePlotter* SCFPlotter;

    QToolButton *stepButton;
    QToolButton *convButton;
    QCheckBox* gbox;
 
};

#endif // WIN_SCF_H

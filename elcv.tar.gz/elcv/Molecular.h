/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Definition of Molecular
//
// 2015: Roberto Flores Moreno
// ******************************************************************

#ifndef X_MOLECULAR_H
#define X_MOLECULAR_H

#include <vector>

#include <Vector.h>

using namespace std;

class Atom;
class Random;

class Molecular
{
  public:
    Molecular(void);

    vector<Atom*> atom;

    void ReadXYZ(char*);
    void ReadZMatrix(char*);

    void WriteXYZ(char*);
    void WriteZMatrix(char*);

    void AddAtom(int,int,int,int,double,double,double);
    void DeleteLastAtom(void);
    int Natom(void);
    Atom* GetAtom(int);
    void C2Z(int); 
    void Z2C(int); 
    double GrowRIS(int,Random*);
    void Nullify(int);
    int PGBDrv(char*,int*); 
    int SGBDrv(char*,int*); 
    int NumberOfParticles(int);
    double NuclearRepulsionEnergy(void);

  protected:

    void center(void);
    int AppIGroup(int*);
    int AppOGroup(int*);
    int AppTGroup(int*);
    int AppSGroup(int,int*);
    int AppDGroup(char*,int,int*);
    int AppCGroup(char*,int,int*);
    void AppSigma(Vector,int);
    void AppCAxis(int,int,Vector,int); 
    void AppSAxis(int,int,Vector,int);
    void AppTrans(Vector,double,int);
    void ClonAtom(int,Vector);
    double Dihedral(int,int,int,int);
};

#endif // MOLECULAR_H

/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#ifndef X_MATRIX_H
#define X_MATRIX_H

#include <Matrix.h>

class Matrix
{
  public:
    Matrix(int,int);

    double *values;

    void operator += ( Matrix );
    double& operator () ( int, int );

    int NRow(void);
    int NCol(void);
    void Print(char*,char*,int,int);
    void Read(char*,char*,int,int);
    void Transpose(void);
    void Diagonalize(double*);
    void SVDPower(double*,double,double);
    void Symmetrize(void);
    void Fill(double);
    void SetZero(void);
    void SetValue( int, int , double );
    void ShiftValue( int, int , double );
    void GetRowValues( int, double* );
    void GetColValues( int, double* );
    void SetRowValues( int, double* );
    void SetColValues( int, double* );
    void Multiply(Matrix*,Matrix*,bool);
    void VectorMultiply(double*,double*);
    void Copy(Matrix*);
    void Add(Matrix*,int,int);
    void Scale(double);
    double Trace(void);
    double QTrace(Matrix*);

  protected:

    int dim_row;
    int dim_col;
};

#endif

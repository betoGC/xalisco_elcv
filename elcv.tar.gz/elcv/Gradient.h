/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#ifndef X_GRADIENT_H
#define X_GRADIENT_H

#include <vector>

#include <Vector.h>

using namespace std;

class QChem;
class System;
class GaussianGas;
class Integrator;
class Matrix;

class Gradient 
{
  public:
    Gradient(QChem*);

    vector<Vector> gradient;
    QChem *qchem;
    System *sys;
    Integrator *gi;
   
    void Evaluate(void);
    void Test(void);

  protected:

    void NuclearRepulsion(void);
    void Pack(int,int,Vector*,double**,double**,char*);
    void Save(Vector,int,int);
    void TwoCenterMatrixDerivatives(GaussianGas*,Matrix*,char*);
    void CoreMatrixDerivatives(GaussianGas*,Matrix*);

};

#endif

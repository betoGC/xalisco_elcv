/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Declaration of class Viewer
//
// 2015: Roberto Flores-Moreno
// ******************************************************************

#ifndef X_VIEWER_H
#define X_VIEWER_H

#include <vector>
#include <QWheelEvent>
#include <QtOpenGL/QtOpenGL>

#include <Vector.h>
//Qt5 porting
#include <QtPrintSupport/QPrinter>
#include <QtPrintSupport/QPrintDialog>

using namespace std;

class wheelEvent;

class Xalisco;
class Panel;
class Plotter;
class WinPlot;
class ImageRender;

class Viewer : public QGLWidget
{
  Q_OBJECT

  public:
    Viewer( Xalisco*, Panel* );

    Xalisco *xalisco;
    Panel *panel;
    Plotter* plotter;
    ImageRender *image_render;

    double trans[3];
    double scale;
    GLdouble rot[16];

    void Project( void );
    void PickSurface( void );

    void SaveSelection( int );
    void DrawSurfaces( void );
    void DrawStrings( void );
    void Rotate( double , double , double , double );
    void ResetRotation(void);
    void Write(char*,Vector,size_t);

    vector<vector<size_t> > monitored_bonds;
    vector<vector<size_t> > monitored_angles;
    vector<vector<size_t> > monitored_dihedrals;

  public slots:
 
    void Redraw( void );
    void ZoomIn( void );
    void ZoomOut( void );
    void ChangeBackgroundColor( void );
    void ChangeTags( const QString & );
    void ChangeTagColor( void );
    void ChangeArrows( const QString & );
    void ChangeArrowColor( void );
    void wheelEvent(QWheelEvent *event);

  protected:

    QString tag_type;
    QString arrow_type;
    QPrinter *printer;
    int mouse[2];
    float view_width;
    float view_height;
    float view_far;
    float view_near;
    //rfm vector<ImageLabel> user_label;

    void initializeGL( void );
    void resizeGL( int , int );
    void paintGL( void );

    int SelectedAtom( size_t );

    double tag_color[4];
    double arrow_color[4];
    double bg[4];
    vector<size_t> selected_atoms;

  protected slots:

    void mousePressEvent( QMouseEvent* );
    void mouseMoveEvent( QMouseEvent* );
    void mouseReleaseEvent( QMouseEvent* );
    void keyPressEvent( QKeyEvent* );

    void PickAtom( void );

};

#endif  // VIEWER_H

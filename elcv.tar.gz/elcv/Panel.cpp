/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: class Panel functions. 
//
// 2015: Roberto Flores-Moreno
// ******************************************************************

#include <stdarg.h>
#include <pthread.h>

#include <iostream>
#include <fstream>

#include <QtCore>
#include <QtWidgets>
#include <QMainWindow>

#include <Panel.h>   
#include <Xalisco.h>   
#include <Viewer.h>   
#include <ImageRender.h>   
#include <GeometryEditor.h>   
#include <WinQChem.h>   
#include <WinPlot.h>   
#include <System.h>   
#include <Molecular.h>   
#include <Atom.h>   
#include <Model.h>   
#include <ElementSelector.h>
#include <Element.h>
#include <WinEChem.h>   
#include <WinSpec.h>   
#include <WinRxns.h>   
#include <Chemistry.h>   

using namespace std;

static const char *READ_FORMATS[] = {"XYZ","ZMT","CHM",NULL};
static const char *WRITE_FORMATS[] = {"XYZ","ZMT","CHM",NULL};

Panel::Panel( Xalisco *ig, System* isys )
     : QWidget( 0 )
{
  xalisco = ig;
  sys = isys;

  tabWidget = new QTabWidget;

  viewer = new Viewer( xalisco , this );
  viewer->hide();
  geoeditor = new GeometryEditor( this );
  geoeditor->hide();
  model = new Model( this );
  winqchem = new WinQChem(xalisco,sys);
  winplot = new WinPlot( xalisco , viewer );
  winechem = new WinEChem(xalisco);


  statusbar = new QStatusBar( this );

 int i;


  i = 0;
  while ( READ_FORMATS[i] != NULL )
  {
    RFMTA.push_back( new QAction( tr( READ_FORMATS[i] ), this ) );
    RFMTA[i]->setStatusTip(tr("Open file in %1 format")
                           .arg(READ_FORMATS[i]));
    RFMTA[i]->setCheckable( true );
    connect( RFMTA[i], SIGNAL(triggered()), this, SLOT( ReadFile() ));
    i++;
  };

  i = 0;
  while ( WRITE_FORMATS[i] != NULL )
  {
    WFMTA.push_back( new QAction( tr( WRITE_FORMATS[i] ), this ) );
    WFMTA[i]->setStatusTip(tr("Write file in %1 format")
                           .arg(WRITE_FORMATS[i]));
    WFMTA[i]->setCheckable( true );
    connect( WFMTA[i], SIGNAL(triggered()), this, SLOT( WriteFile() ));
    i++;
  };

  imgAct = new QAction(tr("&Image"), this);
  imgAct->setStatusTip(tr("Write image file"));
  connect(imgAct, SIGNAL(triggered()), this, SLOT(WriteImage()));

  coloratomAct = new QAction(tr("Atom type"), this);
  coloratomAct->setStatusTip(tr("Change atom type color"));
  connect(coloratomAct, SIGNAL(triggered()),this,SLOT(ChangeAtomColor()));

  colorbgAct = new QAction(tr("Background"), this);
  colorbgAct->setStatusTip(tr("Change background color"));
  connect(colorbgAct, SIGNAL(triggered()), viewer,SLOT(ChangeBackgroundColor()));

  colortagAct = new QAction(tr("Tags"), this);
  colortagAct->setStatusTip(tr("Change tags color"));
  connect(colortagAct, SIGNAL(triggered()),viewer,SLOT(ChangeTagColor()));

  colorarrowAct = new QAction(tr("Arrows"), this);
  colorarrowAct->setStatusTip(tr("Change arrows color"));
  connect(colorarrowAct, SIGNAL(triggered()),viewer,SLOT(ChangeArrowColor()));

  colorsurfAct = new QAction(tr("Surface"), this);
  colorsurfAct->setStatusTip(tr("Change surface color"));
  connect(colorsurfAct, SIGNAL(triggered()), this,SLOT(ChangeSurfaceColor()));

  quitAct = new QAction(tr("&Quit"), this);
  quitAct->setShortcut(tr("Ctrl+Q"));
  quitAct->setStatusTip(tr("Finish the application"));
  connect(quitAct, SIGNAL(triggered()), xalisco, SLOT(closeAllWindows()));

  aboutAct = new QAction(tr("&About"), this);
  aboutAct->setStatusTip(tr("Show the application's About box"));
  connect(aboutAct, SIGNAL(triggered()), this, SLOT(About()));

  
  QMenuBar *mainMenu = new QMenuBar;

  fileMenu = new QMenu(tr("&File"),this);

  readMenu = new QMenu(tr("&Read"),this);
  for( size_t i = 0 ; i < RFMTA.size() ; i++ )
    readMenu->addAction( RFMTA[i] );
  fileMenu->addMenu(readMenu);

  writeMenu = new QMenu(tr("&Write"),this);
  for( size_t i = 0 ; i < WFMTA.size() ; i++ )
    writeMenu->addAction( WFMTA[i] );
  fileMenu->addMenu(writeMenu);

  fileMenu->addAction( imgAct );
  fileMenu->addSeparator();

  fileMenu->addAction( quitAct );

  colorMenu = new QMenu(tr("Color"),this);
  colorMenu->addAction(coloratomAct);
  colorMenu->addAction(colorbgAct);
  colorMenu->addAction(colortagAct) ;
  colorMenu->addAction(colorarrowAct) ;
  colorMenu->addAction(colorsurfAct) ;

  helpMenu = new QMenu(tr("&Help"),this);
  helpMenu->addAction(aboutAct);

  mainMenu->addMenu(fileMenu);
  mainMenu->addMenu(colorMenu);
  mainMenu->addMenu(helpMenu);

  QGridLayout *mainLayout = new QGridLayout;

  inButton = new QToolButton( this );
  inButton->setText( "Zoom In" );
  connect( inButton,SIGNAL(clicked()),viewer,SLOT(ZoomIn()));
  
  outButton = new QToolButton( this );
  outButton->setText( "Zoom Out" );
  connect( outButton,SIGNAL(clicked()),viewer,SLOT(ZoomOut()));

  giraButton = new QToolButton( this );
  giraButton->setText( "Start Rotation" );
  connect( giraButton,SIGNAL(clicked()),this,SLOT(SetSpin()));

  modelComboBox = new QComboBox;
  modelComboBox->addItem( "Model" );
  modelComboBox->addItem( QString("None"));
  modelComboBox->addItem( QString("Balls & Sticks"));
  modelComboBox->addItem( QString("Balls"));
  modelComboBox->addItem( QString("Sticks"));
  modelComboBox->addItem( QString("Wireframe"));
  modelComboBox->addItem( QString("Van der Waals"));
  modelComboBox->addItem( QString("Custom"));
  connect(modelComboBox, SIGNAL(activated(const QString &)),
          this, SLOT(ChangeModel(const QString &)));


  arrowComboBox = new QComboBox;
  arrowComboBox->addItem( "Arrows" );
  arrowComboBox->addItem( "None");
  arrowComboBox->addItem( "Dipole");
  arrowComboBox->addItem( "Forces");
  arrowComboBox->addItem( "NFF HOMO");
  arrowComboBox->addItem( "NFF LUMO");
  connect(arrowComboBox, SIGNAL(activated(const QString &)),
          viewer, SLOT(ChangeArrows(const QString &)));

  styleComboBox = new QComboBox;
  styleComboBox->addItems(QStyleFactory::keys());
  connect(styleComboBox, SIGNAL(activated(const QString &)),
          this, SLOT(MakeStyle(const QString &)));


  QWidget *visualizer = new QWidget(0);
  QVBoxLayout *visuallayout = new QVBoxLayout;

  visuallayout->addWidget( modelComboBox,1,Qt::AlignCenter);
  visuallayout->addWidget( inButton,1,Qt::AlignCenter);
  visuallayout->addWidget( outButton,1,Qt::AlignCenter);
  visuallayout->addWidget( giraButton,1,Qt::AlignCenter);
  visuallayout->addWidget( styleComboBox,1,Qt::AlignCenter);
  visuallayout->addWidget( arrowComboBox,1,Qt::AlignCenter);
  visuallayout->addWidget( statusbar,1,Qt::AlignCenter);

  styleComboBox->hide();

  visualizer->setLayout(visuallayout);

  mainLayout->setMenuBar(mainMenu);
  mainLayout->addWidget( viewer        ,      0 , 0 , 22 , 20);
  mainLayout->addWidget( tabWidget     ,      0 ,20 ,  0 ,  2);
  mainLayout->addWidget( statusbar     ,      22, 0 ,  1 , 20);

  setLayout( mainLayout );

  tabWidget->clear();
  tabWidget->addTab( winqchem , QString("Orbitals") );
  tabWidget->addTab( winechem , QString("Electrochemistry") );
  tabWidget->addTab( visualizer , QString("Control") );
  tabWidget->addTab( geoeditor , QString("Molecule") );
  tabWidget->addTab( winplot , QString("Plotter") );

  timer = new QTimer(this);

  setWindowTitle( "Xalisco 120 (Ahualulco)" );
  move( 0 , 0  );
  resize(1500 , 1000);
  viewer->show();
}


void Panel::Report( const char *fmt, ... )
{
  va_list args;   
  char    s[256];

  va_start( args , fmt );
  vsprintf(s , fmt , args );
  va_end( args );
 
  if (statusbar) statusbar->showMessage( QString( s ) );
}

void Panel::About()
{
  string str = "Xalisco 120, (C) 2015\n";
  str += "Authors: \n";
  str += "Roberto Flores-Moreno (MEX) roberto.floresmoreno.qt@gmail.com\n";
  str += "Adrian Venegas-Reynoso (MEX) adrianvenegasreynoso@gmail.com\n";
  str += "Contributors: \n";
  str += "Jose Alberto Guerrero Cruz (MEX)\n";
  str += "Jose de Jesus Villalobos Castro (MEX)\n";
  str += "Henry Nicole Gonzalez Remirez (MEX)\n";
  QMessageBox::about( this, "About Xalisco",str.c_str());
}

void Panel::MakeStyle( const QString &style )
{
  QApplication::setStyle(QStyleFactory::create(style));
}

void Panel::ReadFile()
{
  char fileformat[256];
  size_t i;

  for ( i = 0 ; i < RFMTA.size() ; i++ )
  {
    if ( RFMTA[i]->isChecked() ) 
    {
      RFMTA[i]->setChecked( false );
      sprintf(fileformat,"%s",((RFMTA[i]->text()).toLatin1()).data());
      break;
    };
  };

  QString filter("All Files (*.*)");
  filter +=      "\nOnly    (*.xal)";
  filter +=      "\nOnly    (*.xyz)";
  QString fn = QFileDialog::getOpenFileName(this,
                 QString("Read file"),
                 QDir::currentPath(),
                 filter);
  if ( ! ( fn.isEmpty() || fn.isNull() ) )
  {
    char filename[256];

    sprintf(filename,"%s",(fn.toLatin1()).data());
    Report( "Reading file %s ...", filename );
    string tit = "Xalisco";
    tit += ":";
    tit += filename;
    setWindowTitle( tit.c_str() );
    DoReadFile(filename,fileformat);
    Report( "Reading file %s ... DONE", filename );
  };
}

void Panel::DoReadFile(char* filename, char* fmt)
{
  if ( strcasecmp( fmt , "XYZ" ) == 0 ||
       strcasecmp( fmt , "ZMT" ) == 0 )
  {
    geoeditor->Read(filename,fmt);
  }
  else if ( strcasecmp( fmt , "CHM" ) == 0 )
  {
    winechem->winspec->Read(filename);
    winechem->winrxns->Read(filename);
  }
  if (xalisco) xalisco->panel->viewer->Redraw();
  model->ChangeKind("Balls & Sticks");
  viewer->Redraw();
}

void Panel::WriteFile()
{
  char sffmt[X_MAX_STR_SIZE];
  char fileformat[X_MAX_STR_SIZE];
  QString ffmt;
  size_t i;

  for ( i = 0 ; i < WFMTA.size() ; i++ )
  {
    if ( WFMTA[i]->isChecked() )
    {
      WFMTA[i]->setChecked( false );
      sprintf(sffmt,"%s",((WFMTA[i]->text()).toLatin1()).data());
      strcpy(fileformat,sffmt);
      // File extension comes only from first 3 characters
      sffmt[3] = '\0';
      ffmt = sffmt;
      break;
    };
  };
  QString initialPath = QDir::currentPath() + "/untitled.";
  initialPath = initialPath + ffmt.toLower();
  QString fn = QFileDialog::getSaveFileName( this,
               tr( "Write %1 file").arg(ffmt.toUpper()),
               initialPath, tr("All Files (*.%1)").arg(ffmt.toLower()) );
  if ( ! ( fn.isEmpty() || fn.isNull() ) )
  {
    char filename[X_MAX_STR_SIZE];

    sprintf(filename,"%s",(fn.toLatin1()).data());
    Report( "Writing file %s ...", filename );
    DoWriteFile(filename , fileformat );
    Report( "Writing file %s ... DONE", filename );
  };
}

void Panel::DoWriteFile(char* filename, char* fmt)
{
  if ( strcasecmp( fmt , "XYZ" ) == 0 )
  {
    geoeditor->mol->WriteXYZ(filename);
  }
  else if ( strcasecmp( fmt , "ZMT" ) == 0 )
  {
    geoeditor->mol->WriteZMatrix(filename);
  }
  else if ( strcasecmp( fmt , "CHM" ) == 0 )
  {
    winechem->chem->Write(filename);
  }
}

void Panel::WriteImage()
{ 
  viewer->image_render->show(); 
}

void Panel::ChangeAtomColor()
{
  xalisco->es->exec(); 
  int sel = xalisco->es->GetSelectedElement();
  QColor color; 
  color = QColorDialog::getColor( color , this );
  ELEMENT_COLOR[sel][0] = color.red()/255.0;
  ELEMENT_COLOR[sel][1] = color.green()/255.0;
  ELEMENT_COLOR[sel][2] = color.blue()/255.0;
  viewer->Redraw();
}

void Panel::ChangeSurfaceColor()
{
  xalisco->SetCursor( "Selection" );
  xalisco->status |= SFSURF;
  Report("Select a surface");
}


void Panel::SetSpin(void)
{
  if (giraButton->text()=="Start Rotation")
  {
    giraButton->setText("Stop Rotation");
    connect(timer,SIGNAL(timeout()),
            this,SLOT(AdvanceSpin()));
    AdvanceSpin();
  }
  else if (giraButton->text()=="Stop Rotation")
  {
    giraButton->setText("Start Rotation");
    disconnect(timer,SIGNAL(timeout()),
               this,SLOT(AdvanceSpin()));
  }
}

void Panel::AdvanceSpin(void)
{
  viewer->Rotate( 5.0, 0.0, 1.0, 0.0); 
  viewer->Redraw();
  timer->start(40);
}

void Panel::ChangeModel( const QString &newmodel )
{
  model->ChangeKind(newmodel);
}


/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <math.h>
#include <string.h>

#include <iostream>

#include <Becke.h>
#include <Lebedev.h>
#include <Molecular.h>
#include <Atom.h>
#include <Math.h>

using namespace std;

Becke::Becke()
{
}

void Becke::BuildAtomicGrid(int nradp, int nangp, double *gxref, double *gyref,
double *gzref, double *gwref)
{
  int irad,iang,igp;
  double solida;

  // Get radial points
  double r[nradp];
  double wr[nradp];
  RadialQuadratures(r,wr,nradp);

  // Generate angular distributions
  igp = 0;
  for (irad=0;irad<nradp;irad++)
  {
    solida = 4.0*X_PI*pow(r[irad],2.0);
    double x[nangp];
    double y[nangp];
    double z[nangp];
    double wa[nangp];
    ld_by_order(nangp,x,y,z,wa);
    for (iang=0;iang<nangp;iang++)
    {
      gxref[igp] = x[iang]*r[irad];
      gyref[igp] = y[iang]*r[irad];
      gzref[igp] = z[iang]*r[irad];
      gwref[igp] = wr[irad]*wa[iang]*solida;
      igp++;
    }
  }
}

// Radial quadrature
// Transformed Gauss-Chebyshev quadratures
void Becke::RadialQuadratures(double *r,double *w,int n)
{
  int i;

  TSKGC(r,w,n);

  for (i=0;i<n;i++)
  {
    w[i] = (w[i]/(1.0-r[i]))/log(2.0);
    r[i] = 1.0 - log(1.0-r[i])/log(2.0);
  }
}

// Transformed second kind Gauss-Chebyshev quadratures
// J. M. Perez-Jorda, E. San-Fabian, F. Moscardo,
// Comput. Phys. Commun. 70, 271 (1992).
//
// J. M. Perez-Jorda, A. Becke, E. San-Fabian,
// J. Chem. Phys. 100, 6520 (1994).
void Becke::TSKGC(double *x,double *w,int n)
{
  int i;
  double ct,st,st2,t;

  for (i=0;i<int((n+1)/2);i++)
  {
    t = X_PI*double(i+1)/double(n+1);
    ct = cos(t);
    st = sin(t);
    st2 = st*st;
    x[i] = double(2*i-n+1)/double(n+1)-2.0*(1.0+2.0*st2/3.0)*ct*st/X_PI;
    w[i] = 16.0*st2*st2/double(3*(n+1));
    x[n-i-1] = -x[i];
    w[n-i-1] = w[i];
  }
}

// Build and apply Becke weights
// Lit.: A.D. Becke, J. Chem. Phys. 88, 2547 (1988)
void Becke::Weigths(Molecular *mol, int id, double *gx,double *gy,double *gz,double *gw, int n)
{
  int i,iatom,jatom;
  double ra[3],rb[3];

  int natom = mol->Natom();
  double s,mu;
  double r[natom],p[natom];

  for (i=0;i<n;i++)
  {
    for (iatom=0;iatom<natom;iatom++)
    {
      ra[0] = mol->atom[iatom]->x - gx[i];
      ra[1] = mol->atom[iatom]->y - gy[i];
      ra[2] = mol->atom[iatom]->z - gz[i];
      r[iatom] = sqrt(ra[0]*ra[0]+ra[1]*ra[1]+ra[2]*ra[2]);
      p[iatom] = 1.0;
    }
    for (iatom=1;iatom<natom;iatom++)
    {
      ra[0] = mol->atom[iatom]->x;
      ra[1] = mol->atom[iatom]->y;
      ra[2] = mol->atom[iatom]->z;
      for (jatom=0;jatom<iatom;jatom++)
      {
        rb[0] = mol->atom[jatom]->x - ra[0];
        rb[1] = mol->atom[jatom]->y - ra[1];
        rb[2] = mol->atom[jatom]->z - ra[2];
        mu = sqrt(rb[0]*rb[0]+rb[1]*rb[1]+rb[2]*rb[2]);
        mu = (r[iatom]-r[jatom])/mu;
        mu = Function(Function(Function(mu)));
        p[iatom] = (1.0 - mu)*p[iatom];
        p[jatom] = (1.0 + mu)*p[jatom];
      }
    }
    s = 0.0;
    for (iatom=0;iatom<natom;iatom++)
      s += p[iatom];
    gw[i] = gw[i]*p[id]/s;
  }
}

// Becke iteration function
double Becke::Function(double mu)
{
  return 0.5*mu*(3.0 - mu*mu);
}

 



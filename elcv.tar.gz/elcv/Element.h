/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Declaration of class Element
//
// 2003-2012: Roberto Flores-Moreno
// ******************************************************************

#ifndef X_ELEMENT_H
#define X_ELEMENT_H

#include <Parameter.h>

extern char*  ELEMENT_SYMBOL[X_MAX_ATOMIC_NUMBER+1];
extern double ELEMENT_COV_R[X_MAX_ATOMIC_NUMBER+1];
extern double ELEMENT_VDW_R[X_MAX_ATOMIC_NUMBER+1];
extern char*  ELEMENT_NAME[X_MAX_ATOMIC_NUMBER+1];
extern double ELEMENT_COLOR[X_MAX_ATOMIC_NUMBER+1][3];

#endif

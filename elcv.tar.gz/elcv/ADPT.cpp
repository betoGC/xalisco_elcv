/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <iostream>

#include <ADPT.h>
#include <ADFT.h>
#include <QChem.h>
#include <SCF.h>
#include <System.h>
#include <GaussianGas.h>
#include <GaussianSet.h>
#include <GaussianShell.h>
#include <Matrix.h>
#include <Math.h>
#include <File.h>
#include <Time.h>

using namespace std;

ADPT::ADPT(QChem *iqchem)
{
  qchem = iqchem;
  sys = qchem->sys;
  if (!qchem->adft)
  {
    cout << "No ADFT found, ADPT should not be called"<<endl;
    return;
  }
}

void ADPT::LinearResponse(double *b, double *x1)
{
  Time timer = Time();
  timer.Start();

  int big,dbasa,dbasb,igas,jgas,lla,llb;

  big=0;
  for (igas=0;igas<sys->ngas;igas++)
    big += sys->gas[igas]->auxnco;

  Matrix R(big,big);

  lla = 0;
  for (igas=0;igas<sys->ngas;igas++)
  {
    dbasa = sys->gas[igas]->auxnco;
    // G/2 diagonal blocks
    Matrix G(dbasa,dbasa);
    sys->gas[igas]->BuildFittingMatrix(&G);
    G.Scale( 0.5 );
    R.Add( &G, lla, lla );
    llb = 0;
    for (jgas=0;jgas<sys->ngas;jgas++)
    {
      dbasb = sys->gas[jgas]->auxnco;
      Matrix A(dbasa,dbasb);
      // Add coupling to response matrix
      BuildPolarizationMatrix(A,igas,jgas);
      A.Scale( -1.0 );
      R.Add( &A, lla, llb  );
      // Build kernel
      Matrix F(dbasa,dbasb);
      qchem->adft->KernelMatrix(&F,igas,jgas);
      // Apply G^-1
      Matrix tmp(dbasa,dbasb);
      F.Multiply(sys->gas[igas]->G,&tmp,false);
      tmp.Multiply(sys->gas[igas]->G,&F,false);
      // Multiply to coupling and load to response matrix
      F.Multiply(&A,&tmp,false);
      R.Add( &tmp, lla, llb  );
      llb += sys->gas[jgas]->auxnco;
    }
      
    lla += sys->gas[igas]->auxnco;
  }
  InvertResponseMatrix(R,big);
  
  R.VectorMultiply(b,x1);
  cout << "ADPT linear response "<<timer.Seconds()<<" seconds"<<endl;
}

// Polarization matrix is in general rectangular 
// It contains information only of first kind orbitals
// but is represented in two auxiliary sets
void ADPT::BuildPolarizationMatrix(Matrix A,int id1,int id2)
{
  Time timer = Time();
  timer.Start();
  int a,i,k,l;

  A.SetZero();

  Matrix left(sys->gas[id1]->auxnco,sys->gas[id1]->nco);
  Matrix right(sys->gas[id2]->auxnco,sys->gas[id1]->nco);

  for (i=0;i<=sys->gas[id1]->HOMO;i++)
  {
    sys->gas[id1]->EvaluateMOERI3(sys->gas[id1],i,&left);
    sys->gas[id1]->EvaluateMOERI3(sys->gas[id2],i,&right);

    for (k=0;k<sys->gas[id1]->auxnco;k++)
      for (l=0;l<sys->gas[id2]->auxnco;l++)
        for (a=sys->gas[id1]->HOMO+1;a<sys->gas[id1]->nmo;a++)
          A(k,l) += left(k,a)*right(l,a)/
               (sys->gas[id1]->energies[i]-sys->gas[id1]->energies[a]);
  }
  cout << "ADPT polarization "<<timer.Seconds()<<" seconds"<<endl;
}



void ADPT::InvertResponseMatrix(Matrix r, int n)
{
  Time timer = Time();
  timer.Start();

  Matrix raux(n,n);
  Matrix tmp(n,n);

  raux.Copy( &r );
  raux.Transpose();
  raux.Multiply(&r,&tmp,false);

  double values[n];
  tmp.SVDPower(values,double(-1.0),double(1.0e-8));
  tmp.Multiply(&r,&raux,true);
  r.Copy( &raux );
  cout << "ADPT inversion "<<timer.Seconds()<<" seconds"<<endl;
}

void ADPT::x1ToP1()
{
  Time timer = Time();
  timer.Start();
  int ll2,dbasa,dbasb,i,ig,jg;
  double *z1local;

  for (ig=0;ig<sys->ngas;ig++)
  {
    dbasa = sys->gas[ig]->auxnco;
    z1local = new double[dbasa];
    for (i=0;i<dbasa;i++)
      sys->gas[ig]->z1[i] = 0.0;

    ll2 = 0;
    for (jg=0;jg<sys->ngas;jg++)
    {
      dbasb = sys->gas[jg]->auxnco;
      // Coulomb part
      sys->gas[ig]->TwoParticleMatrixDF(sys->gas[ig]->P1,sys->gas[jg],
                                        sys->gas[jg]->x1,1.0);

      // Build kernel
      Matrix F(dbasa,dbasb);
      qchem->adft->KernelMatrix(&F,ig,jg);
      F.VectorMultiply(sys->gas[jg]->x1,z1local);

      for (i=0;i<dbasa;i++)
        sys->gas[ig]->z1[i] += z1local[i];

      ll2 += dbasb;
    }

    // Apply G^-1
    sys->gas[ig]->G->VectorMultiply(sys->gas[ig]->z1,z1local);
    sys->gas[ig]->G->VectorMultiply(z1local,sys->gas[ig]->z1);

    // XC contribution
    sys->gas[ig]->TwoParticleMatrixDF(sys->gas[ig]->P1,sys->gas[ig],
                                      sys->gas[ig]->z1,1.0);

    delete[] z1local;

    // K1 => P1
    sys->gas[ig]->McWeeny(sys->gas[ig]->P1);
  }

  cout << "ADPT x1ToP1 "<<timer.Seconds()<<" seconds"<<endl;
}

//////////////////////////////////
// Electric perturbation
void ADPT::Polarizability(Matrix alpha)
{
  int ig;

  alpha.SetZero();
  for (int indx=2;indx>=0;indx--) 
  {
    ResponseToElectricField(indx);
    for (ig=0;ig<sys->ngas;ig++)
    {
      Matrix D(sys->gas[ig]->nco,sys->gas[ig]->nco);
      for (int indx2=0;indx2<3;indx2++)
      {
        D.SetZero();
        if (indx2==0) sys->gas[ig]->OneParticleMatrix(&D,(char*)"dipole x");
        else if (indx2==1)sys->gas[ig]->OneParticleMatrix(&D,(char*)"dipole y");
        else sys->gas[ig]->OneParticleMatrix(&D,(char*)"dipole z");
        alpha(indx,indx2) -= sys->gas[ig]->P1->QTrace(&D);
      }
    }
  }
}

void ADPT::ResponseToElectricField(int indx)
{
  int ll,dbasa,daux,i,ig;
  double *bvec,*xvec;

  daux = 0;
  for (ig=0;ig<sys->ngas;ig++)
    daux += sys->gas[ig]->auxnco;

  bvec = new double[daux];
  xvec = new double[daux];

  ll = 0;
  for (ig=0;ig<sys->ngas;ig++)
  {
    Matrix mat(sys->gas[ig]->nco,sys->gas[ig]->nco);
    mat.SetZero();
    if (indx==0) sys->gas[ig]->OneParticleMatrix(&mat,(char*)"dipole x");
    else if (indx==1) sys->gas[ig]->OneParticleMatrix(&mat,(char*)"dipole y");
    else sys->gas[ig]->OneParticleMatrix(&mat,(char*)"dipole z");
    sys->gas[ig]->McWeeny(&mat);
    mat.Scale( 0.5 ); // Since McWeeny did not removed factor of 2
    sys->gas[ig]->FittingVector(&mat,&bvec[ll]);
    ll += sys->gas[ig]->auxnco;
  }

  // Obtain x1
  LinearResponse(bvec,xvec);
  delete[] bvec;

  ll = 0;
  for (ig=0;ig<sys->ngas;ig++)
  {
    dbasa = sys->gas[ig]->auxnco;

    // Dipole integrals
    sys->gas[ig]->P1->SetZero();

    if (indx==0) 
      sys->gas[ig]->OneParticleMatrix(sys->gas[ig]->P1,(char*)"dipole x");
    else if (indx==1) 
      sys->gas[ig]->OneParticleMatrix(sys->gas[ig]->P1,(char*)"dipole y");
    else 
      sys->gas[ig]->OneParticleMatrix(sys->gas[ig]->P1,(char*)"dipole z");

    for (i=0;i<dbasa;i++)
      sys->gas[ig]->x1[i] = xvec[ll+i];

    ll += dbasa;
  }

  delete[] xvec;

  x1ToP1();
}

/////////////////////////
// FUKUI
void ADPT::ResponseToIonization(int set_number, int orbital_number)
{
  int llmo,ulmo;
  int ll,dbasa,daux,i,ig;
  double refen;
  double *bvec,*xvec;

  daux = 0;
  for (ig=0;ig<sys->ngas;ig++)
    daux += sys->gas[ig]->auxnco;

  bvec = new double[daux];
  xvec = new double[daux];


  ll = 0;
  for (ig=0;ig<sys->ngas;ig++)
  {
    if (set_number==ig)
    {
      refen = sys->gas[ig]->energies[orbital_number];
      llmo = orbital_number;
      while(llmo>0&&X_ABS(sys->gas[ig]->energies[llmo-1]-refen)<0.001)
        llmo--;
      ulmo = orbital_number;
      while(ulmo<sys->gas[ig]->nmo-1&&X_ABS(sys->gas[ig]->energies[ulmo+1]-refen)<0.001)
        ulmo++;
      sys->gas[ig]->P1->SetZero();
      sys->gas[ig]->BuildFrontierFukuiMatrix(sys->gas[ig]->P1,llmo,ulmo);
      sys->gas[ig]->P1->Scale( 0.5/double(ulmo+1-llmo) ); 
      sys->gas[ig]->FittingVector(sys->gas[ig]->P1,&bvec[ll]);
    } 
    else 
    {
      dbasa = sys->gas[ig]->auxnco;
      for (i=0;i<dbasa;i++)
        bvec[ll+i] = 0.0;
    }
    ll += sys->gas[ig]->auxnco;
  }
  // Obtain x1
  LinearResponse(bvec,xvec);
  delete[] bvec;

  ll = 0;
  for (ig=0;ig<sys->ngas;ig++)
  {
    sys->gas[ig]->P1->SetZero();
    dbasa = sys->gas[ig]->auxnco;
    for (i=0;i<dbasa;i++)
      sys->gas[ig]->x1[i] = xvec[ll+i];
    ll += dbasa;
  }
  delete[] xvec;
  x1ToP1();
  sys->gas[set_number]->P1->Scale( double(ulmo+1-llmo) ); 
  sys->gas[set_number]->BuildFrontierFukuiMatrix(sys->gas[set_number]->P1,llmo,ulmo);
  sys->gas[set_number]->P1->Scale( 1.0/double(ulmo+1-llmo) ); 
}


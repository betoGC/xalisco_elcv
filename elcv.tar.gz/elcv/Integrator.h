/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: class Integrator functions. 
//
// 2008-2015: Roberto Flores-Moreno
// ******************************************************************

#ifndef X_INTEGRATOR_H
#define X_INTEGRATOR_H

#define PSDAOPointer(l) ((l)*(l)*(l)-(l))/6 + (l)*(l) + 2*(l) + 1;

#include <Parameter.h>

// +2 for kinetic energy integrals and avoid shifting full program
extern int gaop[X_MAX_L_I+3][X_MAX_L_I+3][X_MAX_L_I+3];
extern int raop[X_MAX_L_I+3][X_MAX_L_I+3][X_MAX_L_I+3];

class GaussianShell;
class GaussianSet;

extern GaussianShell *pot;
extern double ftab[2*X_MAX_L_I+6+1][X_MAX_TAB_GAM+1];
extern void GammaCoulomb(int,double,double,double*);
extern void GammaSolvent(int,double,double,double*);

class Integrator
{
  public:
    Integrator(void);

    void Overlap(double*,double*,GaussianShell*,GaussianShell*,double**,
         int,bool);
    void Kinetic(double*,double*,GaussianShell*,GaussianShell*,double**,
         int,bool);
    void Dipole(double*,double*,GaussianShell*,GaussianShell*,double**,int);
    void Core(double*,double*,double*,GaussianShell*,GaussianShell*,
              double**,int,int,bool);
    void CoreAlt(double*,double*,double*,GaussianShell*,GaussianShell*,
              double**,int,int,bool);
    void Pseudo(double*,double*,GaussianShell*,GaussianShell*,GaussianSet*,
                double**,int,int);
    void Interaction(double*,double*,double*,double*,GaussianShell*,GaussianShell*,
              GaussianShell*,GaussianShell*,
              double blk[X_MAX_NCO][X_MAX_NCO][X_MAX_NCO][X_MAX_NCO],
              double,bool*,int,int,int);
    void Interaction3(double*,double*,double*,GaussianShell*,GaussianShell*, 
              GaussianShell*,double blk[X_MAX_NCO][X_MAX_NCO][X_MAX_NCO],
              bool,int,int);
    void Interaction2(double*,double*,GaussianShell*,GaussianShell*,double**,int);
    void SetInteraction( void (*)(int,double,double,double*) );
    void SetInteractionPotential(GaussianShell*);

  protected:

    void HRR(int,int,double*,double**);
    void NormalizeTwoIndex(GaussianShell*,GaussianShell*,double**,double**,bool);
    void (*Gamma)(int,double,double,double*);
};


#endif


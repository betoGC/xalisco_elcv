/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Definition of Atom
//
// 2015: Roberto Flores Moreno
// ******************************************************************

#ifndef X_ATOM_H
#define X_ATOM_H

#include <Center.h>

class Atom : public Center
{
  public:

    Atom(char*,double,double,double);
    Atom(int,double,double,double);

    bool basis_center;
    int atomic_number;
    int ref_bond;
    int ref_angle;
    int ref_dihedral;
    double charge;
    double bond;
    double angle;
    double dihedral;

    double* GetColor(void);
    double GetCovalentRadius(void);
    double GetVDWRadius(void);
    void SetSymbol(char*);
    void SetCharge(double);
    void SetAtomicNumber(int);

  protected:

    int SymbolToAtomicNumber( char* );
};

#endif // ATOM_H

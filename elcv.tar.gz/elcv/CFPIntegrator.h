/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#ifndef X_CFP_INTEGRATOR_H
#define X_CFP_INTEGRATOR_H

#define MAXGP_CFP 80000

#include <vector>

#include <Integrator.h>
#include <Vector.h>

using namespace std;

class GaussianGas;
class GaussianSet;
class GaussianShell;
class Becke;
class Bessel;
class Harmonic;
class Matrix;

class CFPIntegrator : Integrator
{
  public:
    CFPIntegrator(GaussianGas*);

    void EvaluateMatrix(Matrix*);
    void Monomial(int,Vector,double*);
    void SetPotential(void(*)());

  protected:

    int ngp;                          // Number of radial poins in quadrature
    int ngpa;                         // Number of active radial poins 
    int ngpmax;
    int ncycmax;
    int current_potential;
    double dca;
    double dcb;
    double tol;
    double *powa;
    double *powb;
    double minexp;
    double *cfpr,*cfpw;
    double x[MAXGP_CFP];
    double wx[MAXGP_CFP];
    Vector rac;
    Vector rbc;
    Becke *becke;
    Bessel *bessel;
    Harmonic *harmonic;
    GaussianGas *gas;

    void Set(char*);
    void Block(GaussianShell*,GaussianShell*,double*,double**,int,int);
    void InitializeMapping(double,double,double*,double*);
    void Map(double,double,double,double,double*,double*);
    void OneCenter(int,int,double*,double**,double**,double**);
    void ThreeCenter(int,int,double**,double**);
    bool Radial(int,double,double*,double**,double**,double**);
    void OverPrimitives(int,double,double,double,double**);
    double Potential(double);
    bool HasPotential(void);
};

#endif

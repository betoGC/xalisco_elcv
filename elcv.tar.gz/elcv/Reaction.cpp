/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <string.h>
#include <math.h>

#include <iostream>
#include <iomanip>

#include <Reaction.h>
#include <Xalisco.h>
#include <Species.h>
#include <Chemistry.h>
#include <Constants.h>
#include <Math.h>

using namespace std;

Reaction::Reaction(Chemistry *ichem)
{
  chem = ichem;
  nspec = 0;
}

void Reaction::Clear()
{
  nspec = 0;
}

bool Reaction::AddSpecies(char* name, double coef)
{
  coefficient[nspec] = coef;
  if (Reaction::SetSpeciesByName(nspec,name))
  {
    nspec++;
    return true;
  }
  else return false;
}

int Reaction::NumberOfSpecies()
{
  return nspec;
}

bool Reaction::SetSpeciesByName(int id, char* name)
{
  size_t i;

  for (i=0;i<chem->specie.size();i++)
  {
    if ( strcasecmp( name , chem->specie[i]->Name() ) == 0 )
    {  
      specie_ptr[id] = i;
      return true;
    }
  }
  return false;
}

void Reaction::SetSpeciesCoefficient(int i, double c)
{
  coefficient[i] = c;
}

void Reaction::SetDeltaG(double dG)
{
  deltaG = dG;
}

void Reaction::SetLambda(double lamb)
{
  lambda = lamb;
}

void Reaction::SetCoupling(double hrp)
{
  hrpCoupling = hrp;
}

char* Reaction::SpeciesName(int i)
{
  return chem->specie[specie_ptr[i]]->Name();
}

double Reaction::SpeciesCoefficient(int i)
{
  if (i>=nspec)
  {
    cout << "You are asking for non existing concentration" <<endl;
    return 0.0;
  }
  return coefficient[i];
}

double Reaction::DeltaG()
{
  return deltaG;
}

double Reaction::Lambda()
{
  return lambda;
}

double Reaction::Coupling()
{
  return hrpCoupling;
}

bool Reaction::IsHeterogeneous()
{
  bool het;
  int i;

  het = false;
  for (i=0;i<nspec;i++)
    if (chem->specie[specie_ptr[i]]->IsElectron()) het = true;
    
  return het;
}

double Reaction::RateConstant(double temperature, double pot, bool has_electrode)
{
  double n = 0.0;
  double std_pot,over_pot;//,Kin=7.5e9;
  double den,dg,dgl,eat,expnum;

  if (IsHeterogeneous())
  {
    if (has_electrode)
    {
      // How many electrons are transfered?
      for (int i=0;i<nspec;i++)
        if (chem->specie[specie_ptr[i]]->IsElectron())
          n = coefficient[i];

      // Evaluate standard potential for reduction
      std_pot = deltaG/(n*X_FARADAY);
      // Overpotential with respect to reduction potential
      over_pot = pot - std_pot;
    } 
    else
    {
      return 0.0;
    }
  } else 
  {
     over_pot = 0.0;
  }

  if (IsHeterogeneous())
  {
    if (has_electrode)
    {
      if (chem->kinMflag=="Marcus")
      {
        // Note: deltaG, lambda and hrpCoupling in SI units
        dg = deltaG;
        dgl = dg+lambda;
        expnum = dgl*dgl;
        // Shift reaction energy
        double potter = -n*X_FARADAY*over_pot;
        //rfm dg += potter;
        expnum += potter*dgl*2.0 + potter*potter;
        eat = expnum/(4.0*lambda*X_RGAS);
        den = (X_PLANCK*X_AVOGADRO/(2.0*X_PI))*
              sqrt(4.0*X_PI*lambda*X_RGAS*temperature);
        return 2.0*X_PI*hrpCoupling*hrpCoupling*exp(-eat/temperature)/den; 
      } 
      else if (chem->kinMflag=="Butler-Volmer")
      {
        double alpha=lambda;
        double kstd=hrpCoupling;
        double f=X_FARADAY/(X_RGAS*temperature);
        double kf,kb;
        kf = kstd*exp(-alpha*f*over_pot);
        kb = kstd*exp((1-alpha)*f*over_pot);
        if (n<0.0) return kf;
        else return kb;
      }
      else{
        cout << "Reaction::RateConstant unable to determine constant"<<endl;
        return 0.0;
      }
    }
  }
  else  // Bueno para los protones
  {
    dg = deltaG;
    dgl = dg+lambda;
    expnum = dgl*dgl;
    eat = expnum/(4.0*lambda*X_RGAS);
    den = (X_PLANCK*X_AVOGADRO/(2.0*X_PI))*
    sqrt(4.0*X_PI*lambda*X_RGAS*temperature);
    return 2.0*X_PI*hrpCoupling*hrpCoupling*exp(-eat/temperature)/den; 
  }
}

// Advance reaction
// Roberto Flores-Moreno (Oct 2014)
void Reaction::Advance(double temperature, double voltage,double dt,bool
has_electrode)
{
  int i;
  double c,dc,ma,s,nu,local_dt;

  ma = MassAction(temperature,voltage,has_electrode);
  if (ma==0.0) return;

  local_dt = dt;
  for (i=0;i<nspec;i++)
  {
    if (!chem->specie[specie_ptr[i]]->IsElectron())
    {
      nu = coefficient[i];
      if (nu<0.0)
      {
        c = chem->specie[specie_ptr[i]]->Concentration();
        local_dt = X_MIN(local_dt,c/(-ma*nu));
      }
    }
  }

  s = ma*local_dt;
  //dc = 0.0;
  for (i=0;i<nspec;i++)
  {
    //chem->specie[specie_ptr[i]]->SetConcentrationShift( 0.0 );
    nu = coefficient[i];
    dc = nu*s;
    chem->specie[specie_ptr[i]]->ChangeConcentrationShift( dc );
  }
}

// Determine mass action values
// Roberto Flores-Moreno (Oct 2014)
double Reaction::MassAction(double temperature, double voltage, bool has_electrode)
{
  int i;
  double mass_action;

  mass_action = 0.0;
  if (nspec<2) 
  {
    cout << "ERROR in Reaction::MassAction: Number of reactants lower than 2 "<<endl;
    return 0.0;
  }
  mass_action = 1.0;
  for (i=0;i<nspec;i++)
  {
    // Reactants have negative coefficient
    double coef = coefficient[i];
    if (coef<0.0&&(!chem->specie[specie_ptr[i]]->IsElectron()))
    {
      double c = chem->specie[specie_ptr[i]]->Concentration();
      mass_action *= pow(c,-coef);
    }
  }
  mass_action *= RateConstant(temperature,voltage,has_electrode);
  mass_action = X_MAX(0.0,mass_action);
  return mass_action;
}

void Reaction::Write(ofstream *f)
{
  int i;

  *f << "Gibbs free energy:    "
     << right << fixed << setw(20) << setprecision(10) << deltaG << endl;
  *f << "Reorganization energy:"
     << right << fixed << setw(20) << setprecision(10) << lambda << endl;
  *f << "Coupling:             "
     << right << fixed << setw(20) << setprecision(10) << hrpCoupling << endl;
  *f << "Number of reactants: "<<nspec<<endl;
  for (i=0;i<nspec;i++)
  {
    *f << " " << left << setw(20) << chem->specie[specie_ptr[i]]->Name() << " "
       << right << fixed << setw(20) << setprecision(10) << coefficient[i]<< endl;
  }
}


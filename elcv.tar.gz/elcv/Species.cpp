/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <string.h>

#include <iomanip>

#include <Species.h>

Species::Species(char* iname)
{
  SetName(iname);
  SetConcentration(0.0);
  SetDiffusionCoefficient(1.0e-5);
}

char* Species::Name()
{
  return &name[0];
}

void Species::SetName(char *iname)
{
  strcpy(name,iname);
}

double Species::Concentration()
{
  return concentration;
}

void Species::SetConcentration(double ic)
{
  concentration = ic;
}
void Species::SetConcentrationShift(double ic)
{
  concentration_shift = ic;
}

double Species::DiffusionCoefficient()
{
  return diffusion_coefficient;
}

void Species::SetDiffusionCoefficient(double d)
{
  diffusion_coefficient = d;
}

// Notice that negative concentrations are allowed
void Species::ShiftConcentration(double s)
{
  concentration += s;
}
void Species::ChangeConcentrationShift(double s)
{
  concentration_shift += s;
}

bool Species::IsElectron()
{
  if ( strncmp(name,"electron",8) == 0 ) 
    return true;
  else
    return false;
}

void Species::Write(ofstream *f)
{
  *f <<left  <<setw(20) <<name <<"  " 
     <<right <<fixed <<setw(20) <<setprecision(10) <<concentration
     <<right <<fixed <<setw(20) <<setprecision(10) <<diffusion_coefficient
     <<endl;
}


/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: CV Window object
//
// 2015: Roberto Flores-Moreno
// ******************************************************************

#include <iostream>
#include <iomanip>
#include <fstream>

#include <QtWidgets>

#include <WinCV.h>   
#include <Xalisco.h>
#include <Chemistry.h>
#include <CurvePlotter.h>
#include <Math.h>
#include <Constants.h>
#include <Fluid.h>
#include <FiniteVolume.h>
#include <Species.h>
#include <Reaction.h>

using namespace std;

WinCV::WinCV( Xalisco *ix, Chemistry *ichem)
      : QWidget( 0 )
{
  xalisco = ix;
  chem = ichem;

  timer = new QTimer(this);

  setWindowTitle( "CV" );

  QToolButton *stepButton =  new QToolButton( this );  
  stepButton->setText( "Step" );
  connect( stepButton,SIGNAL(clicked()),this,SLOT(Step()));

  QGridLayout *mainLayout = new QGridLayout;

  QToolButton *setupButton =  new QToolButton( this );
  setupButton->setText( "Setup" ); 
  connect(setupButton,SIGNAL(clicked()), this,SLOT(Setup())); 

  QToolButton *startButton =  new QToolButton( this );
  startButton->setText( "Start" ); 
  connect(startButton,SIGNAL(clicked()), this,SLOT(Start())); 

  QToolButton *stopButton =  new QToolButton( this );
  stopButton->setText( "Stop" ); 
  connect(stopButton,SIGNAL(clicked()), this,SLOT(Stop())); 

  QToolButton *plotButton =  new QToolButton( this );
  plotButton->setText( "Plot" ); 
  connect(plotButton,SIGNAL(clicked()), this,SLOT(Plot())); 

  kinMComboBox = new QComboBox;
  kinMComboBox->addItem( QString("Marcus") );
  kinMComboBox->addItem( QString("Butler-Volmer") );
  QLabel* kinMlab = new QLabel(tr("Kinetic Model:"));
  chem->kinMflag = kinMComboBox->currentText();
  kinMlab->setBuddy(kinMComboBox);
  connect(kinMComboBox, SIGNAL(activated(const QString &)),
          this, SLOT(ChangeKinModel(const QString &)));
          //this, SLOT(show()));

  vini = 0.65;
  viniSpin = new QDoubleSpinBox( this );
  viniSpin->setRange( -10.0 , 10.0 );
  viniSpin->setSingleStep( 0.0001 );
  viniSpin->setDecimals( 4 );
  viniSpin->setValue( vini );
  QLabel* vinilab = new QLabel(tr("Initial V:"));
  vinilab->setBuddy(viniSpin);
  connect( viniSpin , SIGNAL(valueChanged( double )) ,
           this , SLOT( ChangeInitialPotential( double ) ) );

  vturn = 0.75;
  vturnSpin = new QDoubleSpinBox( this );
  vturnSpin->setRange( -10.0 , 10.0 );
  vturnSpin->setSingleStep( 0.0001 );
  vturnSpin->setDecimals( 4 );
  vturnSpin->setValue( vturn );
  QLabel* vturnlab = new QLabel(tr("Turning V:"));
  vturnlab->setBuddy(vturnSpin);
  connect( vturnSpin , SIGNAL(valueChanged( double )) ,
           this , SLOT( ChangeTurningPotential( double ) ) );

  scan_rate = 10.0;
  vrateSpin = new QDoubleSpinBox( this );
  vrateSpin->setRange( 0.0 , 1000.0 );
  vrateSpin->setSingleStep( 0.001 );
  vrateSpin->setDecimals( 6 );
  vrateSpin->setValue( scan_rate );
  QLabel* vratelab = new QLabel(tr("Scan rate (V/s):"));
  vratelab->setBuddy(vrateSpin);
  connect( vrateSpin , SIGNAL(valueChanged( double )) ,
           this , SLOT( ChangeScanRate( double ) ) );

  frame = new QWidget( 0 );

  CVPlotter = new CurvePlotter( this );
  CVPlotter->resize( 200 , 200 ); 

  mainLayout->addWidget( vinilab         , 1 , 0 , 1, 1 );
  mainLayout->addWidget( viniSpin        , 1 , 1 , 1, 1 );
  mainLayout->addWidget( vturnlab        , 1 , 2 , 1, 1 );
  mainLayout->addWidget( vturnSpin       , 1 , 3 , 1, 1 );
  mainLayout->addWidget( vratelab        , 1 , 4 , 1, 1 );
  mainLayout->addWidget( vrateSpin       , 1 , 5 , 1, 1 );
  mainLayout->addWidget( stepButton      , 3 , 0 , 1, 1 );
  mainLayout->addWidget( setupButton     , 3 , 1 , 1, 1 );
  mainLayout->addWidget( startButton     , 3 , 2 , 1, 1 );
  mainLayout->addWidget( stopButton      , 3 , 3 , 1, 1 );
  mainLayout->addWidget( plotButton      , 3 , 4 , 1, 1 );
  mainLayout->addWidget( kinMlab         , 3 , 5 , 1, 1 );
  mainLayout->addWidget( kinMComboBox    , 3 , 6 , 1, 1 );
  mainLayout->addWidget( CVPlotter       , 4 , 0 , 6, 6 );
  setLayout( mainLayout );

  layout = new QVBoxLayout;
  frame->setLayout( layout );

}

void WinCV::Step()
{
  int i,npoint,npoint1,nspec;
  double area,charge_collected,t,temperature,thickness,v;
  double *xval,*yval,*xval1,**yval1;

  i = time.size() - 1;
  if (i>=0) 
  {
    t = time[i];
    t += time_step;
    v = potential[i];
    if (((t<turn_time)&&(vturn>vini))||((t>turn_time)&&(vturn<vini)))
      v += scan_rate*time_step;
    else
      v -= scan_rate*time_step;
  }
  else 
  {
    t = 0.0;
    v = vini;
  }

  time.push_back( t );
  potential.push_back( v );


  temperature = 298.15;
  // Reaction rates
  area = fluid->area;
  thickness = fluid->length/2.0;
  charge_collected = 0.0;
  fluid->Evolve(X_ABS(time_step),temperature,v,&charge_collected);
  // Concentration (Molar) to charge (Coulombs) conversion
  charge_collected *= area*thickness*X_FARADAY;
  current.push_back( charge_collected/X_ABS(time_step) );
  
  npoint = time.size();
  xval = new double[npoint];
  yval = new double[npoint];
  for (i=0;i<npoint;i++)
  {
    xval[i] = potential[i];
    yval[i] = current[i];
  }
  cout << potential[npoint-1] << "  " << current[npoint-1]<<endl;
  int n = npoint/20;
  CVPlotter->SetData( &xval[n] , &yval[n] ,  npoint-n );

  npoint1 = fluid->volume.size();
  nspec = fluid->volume[0]->chem->NumberOfSpecies();
  xval1 = new double[npoint1];
  yval1 = new double*[nspec];
  for(i = 0; i < nspec; ++i)
    yval1[i] = new double[npoint1];
  
  for (i=0;i<npoint1;i++)
  {
    xval1[i] = i*fluid->length;
  }

  int j;
  for (i=0;i<nspec;i++)
  {
   for (j=0;j<npoint1;j++)
   {
    yval1[i][j] = fluid->volume[j]->concentration[i];
   }
  }
  //CVPlotter->SetData( xval , yval ,  npoint );

  Plot(&xval[n],&yval[n],xval1,yval1,npoint-n,npoint1,nspec);
  delete[] xval;
  delete[] yval;
  delete[] xval1;
  for(i=0;i<nspec;i++){
    delete[] yval1[i];
  }
  delete[] yval1;

NEXT:
  if (npoint<nmax) timer->start(40);
  else Stop();
//BV:
 //current.push_back(n*X_FARADAY*area*(kf*fluid->volume[0]->concentration[0]-kb*fluid->volume[0]->concentration[1]));
 //for (i=0;i<npoint;i++)
 // {
 //   xval[i] = potential[i];
 //   yval[i] = current[i];
 // }
}

void WinCV::Setup()
{
  fluid = new Fluid(chem);

/*
  for (int i=0;i<800;i++)
    ox[i] = chem->specie[1]->Concentration();
*/

  time.clear(); 

  potential.clear(); 

  // Let us try to get 100 sampling points
  //time_step = (1.0e-1)*fluid->length*fluid->length/(1.0e-5);  // FIXME
  time_step = 1.0e-2*fluid->length*fluid->length/(1.0e-5);  // FIXME
  turn_time = (X_ABS(vturn-vini)/X_ABS(scan_rate));
  nmax = int((2.0*turn_time)/time_step);

  current.clear(); 
}

void WinCV::Start()
{
  connect(timer,SIGNAL(timeout()),this,SLOT(Step()));
  Step();
}

void WinCV::Stop()
{
  disconnect(timer,SIGNAL(timeout()), this,SLOT(Step()));
}

void WinCV::ChangeInitialPotential( double v )
{
  vini = v;
}

void WinCV::ChangeTurningPotential( double v )
{
  vturn = v;
}

void WinCV::ChangeScanRate( double s )
{
  scan_rate = X_ABS(s);
}

void WinCV::ChangeKinModel( QString kinflag )
{
 if((chem->kinMflag==""))
   chem->kinMflag = QString("Marcus");
 
 chem->kinMflag = kinflag;
}

void WinCV::Plot(double* x, double* y, double* x1, double** y1, int npoint, int npoint1, int nspec)
{
  int i,j;
  ofstream voltammetry;
  ofstream conc;
  voltammetry.open ("voltammetry.data");
  for (i=0;i<npoint;i++)
  {
    voltammetry << x[i] << "	" << y[i] << endl;
  }
  voltammetry.close();

  conc.open ("conc.data");
  //conc << "nspec tiene: " << nspec << endl;
  //conc << "npoint1 tiene: " << npoint1 << endl;
  for (i=0;i<nspec;i++)
  {
   conc  << "Especie " << i << endl;
   for (j=0;j<npoint1;j++)
   {
     conc  << x1[j] << "	" << y1[i][j] << "	" << endl;
     if(y1[i][j] < 0) 
     {
        conc << "Se encontraron concentraciones negativas!" << endl;
    //    Stop();
     }
   }
     conc << " " << endl;
  }
  conc.close();
}

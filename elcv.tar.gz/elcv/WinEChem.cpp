/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: class WinEChem functions. 
//
// 2015: Roberto Flores-Moreno
// ******************************************************************

#include <fstream>
#include <iomanip>

#include <WinEChem.h>   
#include <Chemistry.h>   
#include <WinSpec.h>
#include <WinRxns.h>
#include <WinCV.h>

using namespace std;

WinEChem::WinEChem(Xalisco* ix)
      : QWidget( 0 )
{
  xalisco = ix;
  chem = new Chemistry();
  winspec = new WinSpec( xalisco , chem );
  winrxns = new WinRxns( xalisco , chem );

  QGridLayout *mainLayout = new QGridLayout;

  tabchem = new QTabWidget;
  tabmeth = new QTabWidget;

  mainLayout->addWidget( tabchem   , 1 , 0 , 1,  4 );
  mainLayout->addWidget( tabmeth   , 5 , 0 , 1 , 4);

  tabchem->clear();
  tabchem->addTab( winspec , QString("Species") );
  tabchem->addTab( winrxns , QString("Reactions") );

  tabmeth->clear();
  wincv = new WinCV( xalisco , chem );
  tabmeth->addTab( wincv , QString("CV") );

  setLayout( mainLayout );

  setWindowTitle( "Electrochemistry" );
}


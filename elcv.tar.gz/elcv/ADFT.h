/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#ifndef X_ADFT_H 
#define X_ADFT_H

#include <DFT.h>
#include <Matrix.h>

class QChem;
class System;
class Functional;

class ADFT : DFT
{
  public:
    ADFT(QChem*,char*);

    QChem *qchem;

    void PotentialAndEnergy(System*);
    void KernelMatrix(Matrix*,int,int);
};

#endif

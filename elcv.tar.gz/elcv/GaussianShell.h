/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Definition of GaussianShell
//
// 2015: Roberto Flores Moreno
// ******************************************************************

#ifndef X_GAUSSIAN_SHELL_H
#define X_GAUSSIAN_SHELL_H

#include <vector>

#include <Xalisco.h>
#include <Vector.h>
#include <Matrix.h>

#define PRIMARY_BASIS_SHELL      0     // Primary basis (electronic, protonic, ... any)
#define AUXILIARY_BASIS_SHELL    1     // Auxiliary basis set (electronic, ... )
#define CENTRAL_FORCE_SHELL      2     // Effective/Model/Solvent/... potentials
#define SEMILOCAL_ECP_SHELL      3     // Effective core potentials

using namespace std;

class Integrator;

class GaussianShell 
{
  public:

    GaussianShell(void);

    int n;
    int l;
    int nco;
    int ll;   // Lower limit of its CAOs in basis
    int ul;   // Upper limit of its CAOs in basis
    int type;
    vector<double> z;
    vector<double> d;
    vector<double> ncsto;

    void Print(char*);
    void Normalize(void);
    void EvaluateRadius(void);
    void NormalizeInteraction(Integrator*);
    double Radius(void);
    double RadialPotential(double);
    void EvaluateGTO(double*,double*,double*,double*,int,int);
    void EvaluateGTODerivative(double*,double*,double*,double*,double*,double*,int, int);
    void EvaluateGTOHessian(double*,double*,double*,double*,double*,double*,
         double*,double*,double*,int, int);

  protected:

    bool is_normalized;
    double radius;
};

#endif // GAUSSIAN_SHELL_H

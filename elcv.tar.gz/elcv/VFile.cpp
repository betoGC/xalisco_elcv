/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <stdio.h>
#include <string.h>

#include <VFile.h>

VFile::VFile(char* ifilename, int idim)
{
  strcpy(filename,ifilename);
  dim = idim;
}

void VFile::Write(double* v, int n)
{
  long pos = dim*n*sizeof(double);

  FILE *file = fopen(filename, "ab+");
  fseek(file,pos,SEEK_SET);
  fwrite(v,sizeof(double),dim,file);
  fclose(file);
};

void VFile::Read(double* v, int n)
{
  long pos = dim*n*sizeof(double);

  FILE *file = fopen(filename, "ab+");
  fseek(file,pos,SEEK_SET);
  fread(v,sizeof(double),dim,file);
  fclose(file);
};

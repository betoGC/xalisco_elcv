/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ***********************************************************
// Purpose: Spherical harmonics and related 
//
// 2015: Roberto Flores Moreno
// ***********************************************************
#include <iostream>

#include <Harmonic.h>
#include <Math.h>
#include <Integrator.h>

using namespace std;

Harmonic::Harmonic()
{
}

// Cartesian to spherical transformation indices
// Lit.: H.B. Schlegel, M.J. Frisch, IJQC. 54, 83 (1995)
void Harmonic::CartesianToSphericalCoefficients(int l, double **ctostm)
{
  double s,s1,s2;
  int expo,i,ic,j,k;
  int lx,ly,lz,m,ma;

  int nco = ((l+1)*(l+2))/2;
  for (m=-l;m<=l;m++)
    for (ic=0;ic<nco;ic++)
      ctostm[l+m][ic] = 0.0;

  // Formula 15                              
  for (lx=l;lx>=0;lx--)
  {
    for (ly=l-lx;ly>=0;ly--)
    {
      lz = l - lx - ly;
      ic = raop[lx][ly][lz];
      for (m=-l;m<=l;m++)
      {
        ma = X_ABS(m);
        j = (lx + ly - ma);
        if ((j>=0)&&(X_MOD(j,2)==0)) 
        {
          j = j/2;
          s1 = 0.0;
          for (i=0;i<=(l-ma)/2;i++)
          {
            s2 = 0.0;
            for (k=0;k<=j;k++)
            {
              if (((m<0)&&(X_MOD(X_ABS(ma-lx),2)==1))||
                  ((m>0)&&(X_MOD(X_ABS(ma-lx),2)==0))) 
              {
                expo = (ma - lx + 2*k)/2;
                s = pow(-1.0,expo)*sqrt(2.0);
              }
              else if ((m==0)&&(X_MOD(lx,2)==0)) 
              {
                expo = k - lx/2;
                s = pow(-1.0,expo);
              }
              else s = 0.0;
              s2 += Noverk(j,k)*Noverk(ma,(lx-2*k))*s;
            }
            s1 += Noverk(l,i)*Noverk(i,j)*pow(-1.0,double(i))*
                  Factorial(2*l-2*i)/Factorial(l-ma-2*i)*s2;
          }
          ctostm[l+m][ic] = sqrt((Factorial(2*lx)*Factorial(2*ly)*
            Factorial(2*lz)*Factorial(l)*Factorial(l-ma))/(Factorial(lx)*
            Factorial(ly)*Factorial(lz)*Factorial(2*l)*Factorial(l+ma)))*
            s1/(pow(2.0,double(l))*Factorial(l));
        }
        else ctostm[l+m][ic] = 0.0;
      }
    }
  }
}

// Spherical to cartesian transformation indices
// Lit.: H.B. Schlegel, M.J. Frisch, IJQC. 54, 83 (1995)
void Harmonic::SphericalToCartesian(int l, double **stoctm)
{
  int ic1,ic2,lx,lx1,lx2,ly,ly1,ly2,lz,lz1,lz2,m,nco,nsph;
  double s,s1,s2;
  double **ctostm;

  nco = ((l+1)*(l+2))/2;
  nsph = 2*l + 1;
  ctostm = new double*[nsph];
  for (m=-l;m<=l;m++)
    ctostm[l+m] = new double[nco];

  CartesianToSphericalCoefficients(l,ctostm);

  for (m=-l;m<=l;m++)
    for (ic1=0;ic1<nco;ic1++)
      stoctm[l+m][ic1] = 0.0;

  // Formulas 18 and 19
  for (lx1=l;lx1>=0;lx1--)
  {
    for (ly1=l-lx1;ly1>=0;ly1--)
    {
      lz1 = l - lx1 - ly1;
      ic1 = raop[lx1][ly1][lz1];
      s1 = sqrt((Factorial(lx1)*Factorial(ly1)*Factorial(lz1))/
                (Factorial(2*lx1)*Factorial(2*ly1)*Factorial(2*lz1)));
      for (lx2=l;lx2>=0;lx2--)
      {
        for (ly2=l-lx2;ly2>=0;ly2--)
        {
          lz2 = l - lx2 - ly2;
          ic2 = raop[lx2][ly2][lz2];
          lx = lx1 + lx2;
          ly = ly1 + ly2;
          lz = lz1 + lz2;
          if ((X_MOD(lx,2)==0)&&(X_MOD(ly,2)==0)&&(X_MOD(lz,2)==0))
          {
            s2 = sqrt((Factorial(lx2)*Factorial(ly2)*Factorial(lz2))/
                 (Factorial(2*lx2)*Factorial(2*ly2)*Factorial(2*lz2)));
            s = Factorial(lx)*Factorial(ly)*Factorial(lz)*s1*s2/
                (Factorial(lx/2)*Factorial(ly/2)*Factorial(lz/2));
            for (m=-l;m<=l;m++)
              stoctm[l+m][ic1] += s*ctostm[l+m][ic2];
          }
        }
      }
    }
  }

  for (m=-l;m<=l;m++)
    delete[] ctostm[l+m];
  delete[] ctostm;
}

// Coefficients for expanding cartesian monomial into spherical harmonics
void Harmonic::SphericalToPolynomial(int lx1, int ly1, int lz1, double **stoptm)
{
  int ic2,l,l2,m,m2,lx,lx2,ly,ly2,lz,lz2;
  double s,s1,s2,xyz;

  l = lx1 + ly1 + lz1;
  for (l2=0;l2<=l;l2++)
  {
    int nco = ((l2+1)*(l2+2))/2;
    int nsph = 2*l2 + 1;
    double **ctostm;
    ctostm = new double*[nsph];
    for (m=-l2;m<=l2;m++)
      ctostm[l2+m] = new double[nco];
    CartesianToSphericalCoefficients(l2,ctostm);

    s1 = 4.0*X_PI*DoubleFactorial(2*l2+1);
    for (m2=-l2;m2<=l2;m2++)
    {
      xyz = 0.0;
      for (lx2=0;lx2<=l2;lx2++)
      {
        for (ly2=0;ly2<=l2-lx2;ly2++)
        {
          lz2 = l2 - lx2 - ly2;
          ic2 = raop[lx2][ly2][lz2];
          lx = lx1 + lx2;
          ly = ly1 + ly2;
          lz = lz1 + lz2;
          if ((X_MOD(lx,2)==0)&&(X_MOD(ly,2)==0)&&(X_MOD(lz,2)==0)) 
          {
            s2 = DoubleFactorial(lx-1)*DoubleFactorial(ly-1)*
                 DoubleFactorial(lz-1)/DoubleFactorial(l+l2+1);
            s = s1/(DoubleFactorial(2*lx2-1)*DoubleFactorial(2*ly2-1)*
                DoubleFactorial(2*lz2-1));
            xyz +=  ctostm[l2+m2][ic2]*sqrt(s)*s2;
          }
        }
      }
      stoptm[l2][l2+m2] = xyz;
    }
    for (m=-l2;m<=l2;m++)
      delete[] ctostm[l2+m];
    delete[] ctostm;
  }
}


//     Purpose: Calculation of angular ECP integrals.
//              < S(LA,MA) | S(LB,MB) | x^i y^j z^k >
//
//     History: - Creation (04.12.03, RFM)
double Harmonic::SSXYZ(int la,int ma,int lb,int mb,int i,int j,int k)
{
  int al,am,ax,ay,az,bl,bm,l,lc,m;
  double res,norm;

  // Angularity of the polynom 
  lc = i + j + k;

  // If polynom is not present use orthonormality 
  if (lc==0) 
  {
    if ((la==lb)&&(ma==mb)) res = 1.0;
    else res = 0.0; 
  }  
  else
  {
    // Relabel to use the smallest sum  (bl is largest)
    if (la>=lb)
    {
      bl = la;
      bm = ma;
      al = lb;
      am = mb;
    }
    else
    {
      bl = lb;
      bm = mb;
      al = la;
      am = ma;
    }

    // Sum coefficient products if required 
    l = al + lc;
    res = 0.0;
    if (l>=bl)
    {
      double **ctostm;
      double **stoptm;

      int nco = ((al+1)*(al+2))/2;
      int nsph= 2*al + 1;
      ctostm = new double*[nsph];
      for (m=-al;m<=al;m++)
        ctostm[al+m] = new double[nco];

      CartesianToSphericalCoefficients(al,ctostm);

      nsph= 2*l + 1;
      stoptm = new double*[l+1];
      for (m=0;m<=l;m++)
        stoptm[m] = new double[nsph];

      for (ax=0;ax<=al;ax++)
      {
        for (ay=0;ay<=al-ax;ay++)
        {
          az = al - ax - ay;
          // ctostm needs to be renormalized for our purpose 
          norm = sqrt(DoubleFactorial(2*al+1)/(4.0*X_PI*DoubleFactorial(2*ax-1)*
                 DoubleFactorial(2*ay-1)*DoubleFactorial(2*az-1)));
          SphericalToPolynomial(ax+i,ay+j,az+k,stoptm);
          res += norm*ctostm[al+am][raop[ax][ay][az]]*stoptm[bl][bl+bm];
        }
      }
      for (m=0;m<=l;m++)
        delete[] stoptm[m];
      delete[] stoptm;

      for (m=-al;m<=al;m++)
        delete[] ctostm[al+m];
      delete[] ctostm;
    } else res = 0.0;
  }
  return res;
}

//     Purpose: Calculate real spherical harmonics.
//
//     History: - Creation (28.02.03, RFM)
//              - Translated to C (15.07.15, RFM)
//
//     Lit.: W.H. Press, S.A. Teukolsky, W.T. Vetterling, B.P. Flannery,
//           Numerical Recipes, 2nd Edition, Cambridge University Press
void Harmonic::RealSphericalHarmonics(int lmax,double theta, double phi, double *rsh)
{
//     C(M)  : Cos[m*PHI].
//     LMAX  : Maximum l for the Z(lm).
//     PHI   : Phi angle.
//     RSH   : Normalized Real Spherical Harmonics.
//     S(M)  : Sin[m*PHI].
//     THETA : Theta angle.

  int l,lm,m;
  double norm,normzero,x;
  double *s,*c;

  s = new double[lmax+1];
  c = new double[lmax+1];

  // Calculate argument for Legendre polynomials 
  x = cos(theta);

  if (X_ABS(x)==1.0) 
  {
    rsh[SHP(0,0)] = 1.0;
    for (l=1;l<=lmax;l++)
    {
      rsh[SHP(l,0)] = x*rsh[SHP(l-1,0)];
      for (m=1;m<=l;m++)
        rsh[SHP(l,m)] = 0.0;
    }
  }
  // Evaluate over recurrence relations 
  else
  {
    if (lmax>0) s[1] = sqrt((1.0-x)*(1.0+x));
    for (l=2;l<=lmax;l++)
      s[l] = s[l-1]*s[1];
    for (l=0;l<=lmax;l++)
    {
      m=l;
      if (m==0) rsh[SHP(l,m)] = 1.0;
      else
      {
        rsh[SHP(l,m)] = s[m]*DoubleFactorial(2*m-1);
        m = l - 1;
        lm = l + m;
        rsh[SHP(l,m)] = x*(2*m+1)*rsh[SHP(l-1,m)];
        if (l>1)
          for (m=0;m<=l-2;m++)
          {
            lm = l + m;
            rsh[SHP(l,m)] = (x*(2*l-1)*rsh[SHP(l-1,m)]-(lm-1)*rsh[SHP(l-2,m)])/(l-m);
          }
      }
    }
  }

  // Normalization
  for (l=0;l<=lmax;l++)
  {
    normzero = sqrt(double(2*l+1)/(2.0*X_PI));
    rsh[SHP(l,0)] *= normzero;
    for (m=1;m<=l;m++)
    {
      lm = l + m;
      norm = sqrt(Factorial(l-m)/Factorial(lm))*normzero;
      rsh[SHP(l,m)] *= norm;
    }
  }

  // Calculate trigonometric functions
  if (lmax>0)
  {
    if (phi==0.0)
    {
      for (m=0;m<=lmax;m++)
      {
        s[m] = 0.0;
        c[m] = 1.0;
      }
    }
    else
    {
      s[1] = sin(phi);
      c[1] = cos(phi);
      for (m=2;m<=lmax;m++)
      {
        s[m] = s[1]*c[m-1]+c[1]*s[m-1];
        c[m] = c[1]*c[m-1]-s[1]*s[m-1];
      }
    }
  }

  // Build normalized Real Spherical Harmonics 
  for (l=0;l<=lmax;l++)
  {
    rsh[SHP(l,0)] /= sqrt(2.0);
    for (m=1;m<=l;m++)
    {
      rsh[SHP(l,-m)] = rsh[SHP(l,m)]*s[m];
      rsh[SHP(l,m)] *= c[m];
    }
  }

  delete[] c;
  delete[] s;
}


/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: class JobManager functions. 
//
// 2016: Roberto Flores-Moreno
// ******************************************************************

#include <string.h>

#include <iostream>
#include <fstream>
#include <iomanip>

#include <Parameter.h>   
#include <JobManager.h>   
#include <System.h>   
#include <GaussianGas.h>   
#include <Molecular.h>   
#include <Atom.h>   
#include <QChem.h>   
#include <SCF.h>   
#include <Units.h>   

using namespace std;

JobManager::JobManager(System* isys,char* iinput_file)
{
  sys = isys;
  strcpy(input_file,iinput_file);
  sprintf(output_file,"%s.xout",input_file);

  qchem = new QChem(sys);
  Load();
  qchem->ChangeMethod("Hartree-Fock",ELECTRON);
  qchem->ChangeMethod("Hartree-Fock",PROTON);
  qchem->ChangeGuess("Core",ELECTRON);
  qchem->ChangeGuess("Core",PROTON);
}

void JobManager::Load()
{
  char str[X_MAX_STR_SIZE];
  int type;

  ifstream f(input_file);
while (true)
{
  f >> str; 
  if ( strncmp(str,"GEOMETRY",8) == 0 ) 
  {
    f >> str; 
    if ( strncmp(str,"XYZ",3) == 0 ) 
    {
      f >> str; 
      sys->mol->ReadXYZ(str);
    }
    else if ( strncmp(str,"ZMATRIX",7) == 0 ) 
    {
      f >> str; 
      sys->mol->ReadZMatrix(str);
    }
  }
  else if ( strncmp(str,"BASIS",5) == 0 ) 
  {
    f >> str;
    type = TypeWordToNumber(str);
    f >> qchem->basname[type]; 
  }
  else if ( strncmp(str,"GAS",3) == 0 ) 
  {
    f >> str;
    type = TypeWordToNumber(str);
    f >> str;
    if ( strncmp(str,"ALPHA",5) == 0 ) f >> sys->nalpha[type];
    else f >> sys->nbeta[type];
  }
  else break;
}
  f.close();
}

void JobManager::Run()
{
  if (sys->mol->Natom()<=0) return;

  ofstream f(output_file);
  f << " Xalisco queued execution START" << endl;
  f << " GEOMETRY in cartesian coordinates (Angstroms): " << endl;
  for (int i=0;i<(signed)sys->mol->Natom();i++)
  {
    f << "  " << sys->mol->atom[i]->label << "  " 
      << BohrToAngstrom(sys->mol->atom[i]->x) << "   "
      << BohrToAngstrom(sys->mol->atom[i]->y) << "   "
      << BohrToAngstrom(sys->mol->atom[i]->z) << endl;
  }
  qchem->Setup();
  f << " Number of atoms = " << sys->mol->Natom() <<  endl;
  f << " Number of gases = " << sys->ngas << endl;
  for (int i=0;i<sys->ngas;i++)
  {
    f << "   Gas position in list = " << i << endl;
    f << "     Type = " << TypeNumberToWord(sys->gas[i]->type) << endl;
    f << "     Number of particles = " << sys->gas[i]->npart << endl;
  }
  
  qchem->scf->Setup();
  int ncyc = 0;
  while (!qchem->scf->Converged())
  {
    qchem->scf->Step();
    f << " SCF energy = "
         <<fixed<<setw(15)<<setprecision(6)<<sys->energy<<" Error = "
         <<fixed<<setw(15)<<setprecision(8)<<qchem->scf->Error()<<endl;
    ncyc++;
    if (ncyc>1000) break;
  } 

  f << " Xalisco queued execution END" << endl;
  f.close();
  if (!qchem->scf->Converged())
    cout << " SCF did not converge! " << endl;
}


int JobManager::TypeWordToNumber(char* word)
{
  if ( strncmp(word,"ELECTRON",8) == 0 ) return ELECTRON;
  else if ( strncmp(word,"PROTON",6) == 0 ) return PROTON;
  else if ( strncmp(word,"SOLVENT",7) == 0 ) return SOLVENT;
  else return -1;
}

char* JobManager::TypeNumberToWord(int n)
{
  if ( n == ELECTRON ) return (char*)"ELECTRON";
  else if ( n == PROTON ) return (char*)"PROTON";
  else if ( n == SOLVENT ) return (char*)"SOLVENT";
  else return (char*) "UNKNOWN";
}


/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Declaration of class Panel
//
// 2015: Roberto Flores-Moreno
// ******************************************************************

#ifndef X_PANEL_H
#define X_PANEL_H

#include <vector>

#include <qgl.h>
#include <qmainwindow.h>

using namespace std;

class QSpinBox;
class QComboBox;
class QToolButton;
class QDoubleSpinBox;
class QResizeEvent;
class QCheckBox;
class QTabWidget;

class Xalisco; 
class Viewer;
class System;
class Model;
class GeometryEditor;
class Plotter;
class WinPlot;
class WinQChem;
class WinEChem;

class Panel : public QWidget
{
  Q_OBJECT

  public:

    Panel( Xalisco*, System* );

    void Report( const char*, ... );

    Xalisco *xalisco;
    Viewer *viewer;
    GeometryEditor *geoeditor;
    WinQChem *winqchem;
    WinEChem *winechem;
    System *sys;
    Model* model;
    QMenuBar* menu;
    WinPlot *winplot;

  public slots:
 
    void ChangeModel( const QString & );
    void About( void );
    void MakeStyle( const QString & );
    void ReadFile( void );
    void DoReadFile(char*,char*);
    void WriteFile( void );
    void DoWriteFile(char*,char*);

  protected:

    void CreateActions();
    void CreateMenus();

    QStatusBar *statusbar;

    QMenuBar *mainMenu;

    QMenu *fileMenu;
    QMenu *colorMenu;
    QMenu *readMenu;
    QMenu *writeMenu;
    QMenu *helpMenu;

    vector<QAction*> RFMTA;
    vector<QAction*> WFMTA;
    QAction *quitAct;
    QAction *aboutAct;
    QAction *imgAct;
    QAction *coloratomAct;
    QAction *colorbgAct;
    QAction *colortagAct;
    QAction *colorarrowAct;
    QAction *colorsurfAct;
    QAction *exitAction;

    QToolButton *tstButton;
    QToolButton *inButton;
    QToolButton *outButton;
    QToolButton *giraButton;
    QToolButton *numAtomButton;

    QComboBox *modelComboBox;
    QComboBox *styleComboBox;
    QComboBox *arrowComboBox;
   
    QTimer* timer;
    QSpinBox *lineS;

    QTabWidget *tabWidget;

  protected slots:

    void ChangeAtomColor(void);
    void ChangeSurfaceColor(void);
    void WriteImage(void);
    void SetSpin(void);
    void AdvanceSpin(void);

};

#endif // PANEL_H


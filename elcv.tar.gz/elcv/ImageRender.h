/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Declaration of class ImageRender
//
// 2015: Roberto Flores-Moreno
// ******************************************************************

#ifndef X_IMAGE_RENDER_H
#define X_IMAGE_RENDER_H

#include <QWidget>

class QComboBox;
class QLineEdit;
class Viewer;

class ImageRender : public QWidget
{
  Q_OBJECT

  public:

    ImageRender( Viewer* );
   ~ImageRender( void );

    QLineEdit *label;

  public slots:

    void ChangeFormat( const QString & );
    void Write( void );

  protected:

    bool GetFileName( char* );

    Viewer* viewer;
    char filename[1024];
    QComboBox *formatCombo;
    QLineEdit *axised[3];

};

#endif  // IMAGE_RENDER_H

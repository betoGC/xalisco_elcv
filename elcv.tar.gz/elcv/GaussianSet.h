/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Definition of GaussianSet
//
// 2015: Roberto Flores Moreno
// ******************************************************************

#ifndef X_GAUSSIAN_SET_H
#define X_GAUSSIAN_SET_H

#include <vector>
#include <string>

#include <Center.h>

using namespace std;

class GaussianShell;
class Integrator;

class GaussianSet : public Center
{
  public:

    GaussianSet(double,double,double);

    int nco;
    int ll;
    int ul;
    vector<GaussianShell*> shell; 

    void LoadFromFile(char*,char*,bool);
    void GenerateAuxiliar(GaussianSet*,Integrator*);
    void Print(char*);
    int LMax(void);
    bool belongs_to_hydrogen;
    bool is_neighbor;
};

#endif // GAUSSIAN_SET_H

/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Declaration of class WinCV
//
// 2015: Roberto Flores Moreno
// ******************************************************************

#ifndef X_WIN_CV_H
#define X_WIN_CV_H

#include <vector>

#include <QtGui>
//Qt5 port
#include <QtWidgets/QToolBox>
#include <QVBoxLayout>
#include <QDoubleSpinBox>
#include <QComboBox>
#include <QListWidget>

using namespace std;

class Xalisco;
class CurvePlotter;
class Chemistry;
class Fluid;

class WinCV : public QWidget
{
  Q_OBJECT

  public:
    WinCV( Xalisco* , Chemistry* );

    Xalisco *xalisco;
    Chemistry *chem;
    Fluid *fluid;
    double ox[1000];
    double rd[1000];
    double ox_dos[1000];
    double rd_dos[1000];

    void Enabled( bool );

  public slots:

    void Step(void);
    void Setup(void);
    void Start(void);
    void Stop(void);
    //void Plot(double*,double*);
    void Plot(double*,double*,double*,double**,int,int,int);
    void ChangeInitialPotential(double);
    void ChangeTurningPotential(double);
    void ChangeScanRate(double);
    void ChangeKinModel( QString );

  protected:

    vector<double> time;
    vector<double> potential;
    vector<double> current;

    int nmax;
    double vini;
    double vturn;
    double scan_rate;
    double time_step;
    double turn_time;

    QTimer* timer;
    QVBoxLayout *layout;
    QWidget* frame;
    QListWidget *CVListBox;
    CurvePlotter* CVPlotter;

    QDoubleSpinBox *viniSpin;
    QDoubleSpinBox *vturnSpin;
    QDoubleSpinBox *vrateSpin;
    QComboBox *kinMComboBox;
 
};

#endif // WIN_CV_H

/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <string.h>

#include <iostream>

#include <Functional.h>
#include <Dirac.h>
#include <VWN.h>

using namespace std;

Functional::Functional(char* x, char* c)
{
  strcpy(exchange,x);
  strcpy(correlation,c);
};

// electronic exchange
double Functional::ExchangeEnergy(double rho, int id)
{
  if ( strncmp(exchange,"dirac",5) == 0 ) 
  {
    if (id<2) return dirac_energy(rho);
    else return 0.0;  // There are not functionals for non-electrons
  }
  else if ( strncmp(exchange,"tst",3) == 0 ) 
  {  
    return -2.0*rho;
  }
  else if ( strncmp(exchange,"none",4) == 0 ) return 0.0;
  else cout << "Unknown exchange energy functional: " <<exchange<<endl;
}

double Functional::ExchangePotential(double rho, int id)
{
  if ( strncmp(exchange,"dirac",5) == 0 ) 
  {
    if (id<2) return dirac_potential(rho);
    else return 0.0;  // There are not functionals for non-electrons
  }
  else if ( strncmp(exchange,"none",4) == 0 ) return 0.0;
  else if ( strncmp(exchange,"tst",3) == 0 ) 
  {  
    return -1.0;
  }
  else cout << "Unknown exchange potential functional: "<<exchange<<endl;
}

double Functional::ExchangeKernel(double rho, int id)
{
  if ( strncmp(exchange,"dirac",5) == 0 ) 
  {
    if (id<2) return dirac_kernel(rho);
    else return 0.0;  // There are not functionals for non-electrons
  }
  else if ( strncmp(exchange,"none",4) == 0 ) return 0.0;
  else if ( strncmp(exchange,"tst",3) == 0 ) return 0.0;
  else cout << "Unknown exchange kernel functional: "<<exchange<<endl;
}

// electronic correlation
double Functional::CorrelationEnergy(double* rho)
{
  if ( strncmp(correlation,"vwn",3) == 0 ) return VWN_energy(rho);
  else if ( strncmp(correlation,"none",4) == 0 ) return 0.0;
  else cout << "Unknown correlation energy functional: "<<correlation<<endl;
}

double Functional::CorrelationPotential(double* rho, int id)
{
  if ( strncmp(correlation,"vwn",3) == 0 ) return VWN_potential(rho,id);
  else if ( strncmp(correlation,"none",4) == 0 ) return 0.0;
  else cout << "Unknown correlation potential functional:"<<correlation<<endl;
}

double Functional::CorrelationKernel(double* rho, int id1, int id2)
{
  if ( strncmp(correlation,"vwn",3) == 0 ) return VWN_kernel(rho,id1,id2);
  else if ( strncmp(correlation,"none",4) == 0 ) return 0.0;
  else cout << "Unknown correlation kernel functional:"<<correlation<<endl;
}

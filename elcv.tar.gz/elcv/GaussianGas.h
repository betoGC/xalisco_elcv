/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Definition of GaussianGas
//
// 2015: Roberto Flores Moreno
// ******************************************************************

#ifndef X_GAUSSIAN_GAS_H
#define X_GAUSSIAN_GAS_H

#include <vector>

#include <Parameter.h>
#include <Matrix.h>

using namespace std;

class GaussianSet;
class Molecular;
class System;
class Integrator;
class ECPIntegrator;

class GaussianGas 
{
  public:

    GaussianGas(System*,int,int,int);

    int type;
    int npart;
    int HOMO;
    int copy_source;
    double particle_mass;
    double particle_charge;
    double energy;
    double *energies;  // Orbital energies
    double *oo;        // Orbital occupation
    int nco;
    int auxnco;
    int npo;
    int nmo;                              // Number of molecular orbitals
    vector<GaussianSet*> basis;           // Gaussian basis set
    vector<GaussianSet*> auxis;           // Auxiliary basis set
    vector<GaussianSet*> pps;             // Pseudopotentials (ECP,MCP,SolP)
    System *sys;

    Matrix *X, *C, *H, *F, *P, *W;
    Matrix *G;
    double *x;  // Interaction fitting coefficients
    double *z;  // Exchange-correlation coefficients

    Matrix *P1; // Linear response matrix
    double *x1; // Response of interaction fitting coefficients
    double *z1; // Response of exchange-correlation coefficients

    void FromMolecular(Molecular*,char*);
    void LoadPrimaryBasis(Molecular*,char*);
    void LoadPotentials(Molecular*,char*);
    void GenerateAuxiliaryBasis(void);
    void SetupSCF(char*,char*,int,bool);
    void Print(char*);
    void OneParticleMatrix(Matrix*,char*);
    void TwoParticleMatrix(Matrix*,GaussianGas*,bool);
    void TwoParticleMatrixDF(Matrix*,GaussianGas*,double*,double);
    void NewMOs(bool);
    void OrthogonalizationMatrix(void);
    void EvaluateERI4Batch(GaussianGas*,int,int,Matrix);
    void EvaluateERI4BatchRI(GaussianGas*,int,int,Matrix);
    void EvaluateCharges(double*,char*,bool);
    void SCFDensityMatrix(double);
    void BuildDensityMatrix(void);
    void BuildPulayMatrix(Matrix*);
    void BuildPartialDensityMatrix(Matrix*,int,int);
    void BuildFrontierFukuiMatrix(Matrix*,int,int);
    void BuildCoreMatrix(void);
    void GetDensityMatrix(Matrix*);
    void FittingVector(Matrix*,double*);
    void BuildFittingMatrix(Matrix*);
    void FittingMatrix(void);
    void FittingCoefficients(void);
    void EvaluateMOERI3(GaussianGas*,int,Matrix*);
    void ChargeConstrainMatrix(Matrix*);
    void McWeeny(Matrix*);
    int LMax(vector<GaussianSet*>);
    double GetOrbitalEnergy(int);
    double Entropy(void);

  protected:

    bool direct;
    bool conventional_ready[NTYPES];
    double *eribuf[NTYPES];

    int id;
    Integrator *gi;
    ECPIntegrator *ecp;

    void AddInteraction(int,int,int,int,int,int,int,int,
           double [X_MAX_NCO][X_MAX_NCO][X_MAX_NCO][X_MAX_NCO],
           Matrix*,Matrix*);
    void AddExchange(int,int,int,int,int,int,int,int,
           double [X_MAX_NCO][X_MAX_NCO][X_MAX_NCO][X_MAX_NCO],
           Matrix*,Matrix*);
    void GetOccupations(void);
    void Constrain(int,int*,int*,bool*,double*,double*,double*);
};

#endif // GAUSSIAN_GAS_H

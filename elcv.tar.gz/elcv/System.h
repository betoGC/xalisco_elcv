/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Definition of System
//
// 2015: Roberto Flores Moreno
// ******************************************************************

#ifndef X_SYSTEM_H
#define X_SYSTEM_H

#include <Parameter.h>
#include <Matrix.h>

class Molecular;
class GaussianGas;
class QChem;

class System 
{
  public:

    System(void);

    QChem *qchem;
    Molecular* mol;
    int ngas;
    double *charges;
    double exc;
    double energy;
    double temperature;
    double chemical_potential;
    GaussianGas* gas[X_MAX_N_GAS];

    // Constrained SCF variables

    void Setup(QChem*,char[NTYPES][X_MAX_STR_SIZE]);
    void Print(char*);
    void PrepareCharges(char*,bool);

    double Alpha(int);
    double Beta(int);
    void ChangeAlpha(double,int);
    void ChangeBeta(double,int);
    void EvaluatePromolecularDensity(Matrix*);

    double GetAtomCharge(int);

    int nalpha[NTYPES];
    int nbeta[NTYPES];

};

#endif // X_SYSTEM_H

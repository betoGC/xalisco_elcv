/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#ifndef X_LEBEDEV_H
#define X_LEBEDEV_H
// This header links to Lebedev library which was incorporated
// under terms of  GNU LGPL license
int available_table ( int rule );
int gen_oh ( int code, double a, double b, double v, double *x, 
  double *y, double *z, double *w );
void ld_by_order ( int order, double *x, double *y, double *z, double *w );
void ld0006 ( double *x, double *y, double *z, double *w );
void ld0014 ( double *x, double *y, double *z, double *w );
void ld0026 ( double *x, double *y, double *z, double *w );
void ld0038 ( double *x, double *y, double *z, double *w );
void ld0050 ( double *x, double *y, double *z, double *w );
void ld0074 ( double *x, double *y, double *z, double *w );
void ld0086 ( double *x, double *y, double *z, double *w );
void ld0110 ( double *x, double *y, double *z, double *w );
void ld0146 ( double *x, double *y, double *z, double *w );
void ld0170 ( double *x, double *y, double *z, double *w );
void ld0194 ( double *x, double *y, double *z, double *w );
void ld0230 ( double *x, double *y, double *z, double *w );
void ld0266 ( double *x, double *y, double *z, double *w );
void ld0302 ( double *x, double *y, double *z, double *w );
void ld0350 ( double *x, double *y, double *z, double *w );
void ld0434 ( double *x, double *y, double *z, double *w );
void ld0590 ( double *x, double *y, double *z, double *w );
void ld0770 ( double *x, double *y, double *z, double *w );
void ld0974 ( double *x, double *y, double *z, double *w );
void ld1202 ( double *x, double *y, double *z, double *w );
void ld1454 ( double *x, double *y, double *z, double *w );
void ld1730 ( double *x, double *y, double *z, double *w );
void ld2030 ( double *x, double *y, double *z, double *w );
void ld2354 ( double *x, double *y, double *z, double *w );
void ld2702 ( double *x, double *y, double *z, double *w );
void ld3074 ( double *x, double *y, double *z, double *w );
void ld3470 ( double *x, double *y, double *z, double *w );
void ld3890 ( double *x, double *y, double *z, double *w );
void ld4334 ( double *x, double *y, double *z, double *w );
void ld4802 ( double *x, double *y, double *z, double *w );
void ld5294 ( double *x, double *y, double *z, double *w );
void ld5810 ( double *x, double *y, double *z, double *w );
int order_table ( int rule );
int precision_table ( int rule );
void xyz_to_tp ( double x, double y, double z, double *t, double *p );

#endif

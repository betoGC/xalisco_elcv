/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include<string.h>

#include <iostream>

#include <GW.h>
#include <QChem.h>
#include <SCF.h>
#include <System.h>
#include <GaussianGas.h>
#include <ADFT.h>
#include <Units.h>
#include <Math.h>

using namespace std;

GW::GW(System *isys)
{
  sys = isys;
};

// Purpose: Driver routine for GW calculation.
double GW::IonizationEnergy(int gasid, int p, int order,bool use_ri)
{
// p: Number of orbital on which quasiparticle equations is considered
// gasid: Gas to whom p belongs
  double omega,omegakt;
  double selfe[2];

   omegakt = sys->gas[gasid]->GetOrbitalEnergy(p);
   if ( order > 1 )
   {
     // Newthon-Raphson
     double corr,pomega,ps;
     double tol = 0.001/HartreeToeV(1.0);

     omega = omegakt;
     ps = 1.0;
     for (int it=0;it<10;it++)
     {
       pomega = omega;
       cout << "eV = "<<HartreeToeV(omega) << "   "<<ps<<endl;
       SelfEnergy(omega,order,p,gasid,selfe,use_ri);
       omega = omegakt + selfe[0];
       //break; // NO Self-Consistency
       ps = 1.0/(1.0-selfe[1]);
       omega = ps*(omegakt+selfe[0]-selfe[1]*pomega);
       corr = omega - pomega;
       if (X_ABS(corr)<tol)
       {
         corr = omega - omegakt - selfe[0];
         if (X_ABS(corr)>tol)
           continue;
         break;
       }
    }
  } else omega = omegakt;

  return omega;
}

void GW::SelfEnergy(double omega, int order,int p, int gasid, 
double *selfe, bool use_ri)
{
  int ig;

  selfe[0] = 0.0;
  selfe[1] = 0.0;
  if (order<=0) return;

  selfe[0] += GW1(p,sys->gas[gasid]);
  if (order==1) return;

  for (ig=0;ig<sys->ngas;ig++)
    GW2(p,omega,sys->gas[gasid],sys->gas[ig],selfe,use_ri);
  if (order==2) return;

  cout << "GW::SelfEnergy unknown order"<<endl;
}

// PRIMER TÉRMINO DE GW2 
double GW::GW1(int p,GaussianGas *g)
{
  if (!sys->qchem->adft) return 0.0;

  int i,j;
  double intval,selfe;

  Matrix eri(g->nco,g->nco);

  g->EvaluateERI4Batch(g,p,p,eri);

  selfe = 0.0;
  // Add Hartree-Fock exchange
  for (i=0;i<=g->HOMO;i++)
  {
    intval = -eri(i,i);
    selfe += intval;
  }

  // Remove Vxc effect
  eri.SetZero();
  if (sys->qchem->adft) g->TwoParticleMatrixDF(&eri,g,g->z,1.0);
  double vpp = 0.0;
  for (i=0;i<g->nco;i++)
    for (j=0;j<g->nco;j++)
      vpp += (*g->C)(i,p)*(*g->C)(j,p)*eri(i,j);
  selfe -= vpp;

  return selfe;
}

void GW::GW2(int p,double omega,GaussianGas *g, GaussianGas *other,double *selfe, bool use_ri)
{
  // Evaluates diagonal elements of self-energy.
  int a,b,i,j;
  double den,term,intval;

  Matrix eri(g->nco,other->nco);

  // 2ph, abab:baba (Coulomb)
  for (i=0;i<=other->HOMO;i++)
  {
    if (use_ri) g->EvaluateERI4BatchRI(other,p,i,eri);
    else g->EvaluateERI4Batch(other,p,i,eri);
    for (a=g->HOMO+1;a<g->nmo;a++)
    {
      for (b=other->HOMO+1;b<other->nmo;b++)
      {
        den = omega + other->energies[i] 
            - g->energies[a] - other->energies[b];
        if (X_ABS(den)>X_TOL_NUM) // Avoid zero in denominator
        {
          intval = eri(a,b);
          if (g==other)
          {
            term = (intval*intval-intval*eri(b,a))/den;
          }
          else term = intval*intval/den;
          selfe[0] += term;
          selfe[1] -= term/den;
        }
      }
    }
  }

  // 2hp, abab:baba (Coulomb) 
  for (a=other->HOMO+1;a<other->nmo;a++)
  {
    if (use_ri) g->EvaluateERI4BatchRI(other,p,a,eri);
    else g->EvaluateERI4Batch(other,p,a,eri);
    for (i=0;i<=g->HOMO;i++)
    {
      for (j=0;j<=other->HOMO;j++)
      {
        den = omega + other->energies[a] 
            - g->energies[i] - other->energies[j];
        if (X_ABS(den)>X_TOL_NUM) // Avoid zero in denominator
        {
          intval = eri(i,j);
          if (g==other)
          {
            term = (intval*intval-intval*eri(j,i))/den;
          }
          else term = intval*intval/den;
          selfe[0] += term;
          selfe[1] -= term/den;
        }
      }
    }
  }
  // FIXME: NO ESTOY SEGURO DE ESTO
  cout << "Charge 1 = "<< g->particle_charge << endl;
  cout << "Charge 2 = "<< other->particle_charge << endl;
  cout << "Selfe = "<< selfe[0] << endl;
}



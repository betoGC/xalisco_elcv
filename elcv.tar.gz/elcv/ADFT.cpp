/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <math.h>
#include <string.h>

#include <iostream>

#include <ADFT.h>
#include <Lebedev.h>
#include <QChem.h>
#include <System.h>
#include <Molecular.h>
#include <Atom.h>
#include <Math.h>
#include <Functional.h>
#include <GaussianGas.h>
#include <GaussianSet.h>
#include <Evaluator.h>

using namespace std;

ADFT::ADFT(QChem *iqchem,char *method)
    : DFT(iqchem,method)
{
  qchem = iqchem;
}

void ADFT::PotentialAndEnergy(System *sys)
{
  int iatom,ibas,igas,igp,irad,is_electron,ll,ul;
  double rhomax,sa;
  double ex,ec,vx,vc,v;
  double rho[2];

  // Initialize
  sys->exc = 0.0;
  for (igas=0;igas<sys->ngas;igas++)
    for (ibas=0;ibas<sys->gas[igas]->auxnco;ibas++)
      sys->gas[igas]->z[ibas] = 0.0;

  if (!functional) return;

  is_electron = -1;
  for (igas=0;igas<sys->ngas;igas++)
    if (sys->gas[igas]->type==ELECTRON) 
    {
      is_electron = igas;
      break;
    }
  if (is_electron<0) return;   // No XC functionals for non-electrons

  rho[1] = 0.0;
  for (iatom=0;iatom<sys->mol->Natom();iatom++)
  {
    PrepareGrid(iatom);
    // loop on grid shells
    for (irad=0;irad<nradp;irad++)
    {
      ll = irad*nangp;
      ul = (irad+1)*nangp;
      Neighbors(iatom,irad,sys->gas[is_electron]->auxis,"find");
    for (igp=ll;igp<ul;igp++)
    {
      rhomax = 0.0;
      for (igas=0;igas<sys->ngas;igas++)
      {
        if (sys->gas[igas]->type==ELECTRON)
        {
          int dbasa = sys->gas[igas]->auxnco;
          double abasa[dbasa];
          GetBasis(sys->gas[igas]->auxis,gx[igp],gy[igp],gz[igp],abasa);
          sa = 0.0;
          for (ibas=0;ibas<dbasa;ibas++)
            sa += abasa[ibas]*sys->gas[igas]->x[ibas];
          if (sa<minrho) sa = 0.0;
          rho[igas] = sa;
          rhomax = X_MAX(rhomax,X_ABS(sa));
        }
      }
      // Correlation needs full set of densities
      if (rhomax>minrho) 
      {
        ec = functional->CorrelationEnergy(rho);
        sys->exc += gw[igp]*ec;

        for (igas=0;igas<sys->ngas;igas++)
        {
          if (sys->gas[igas]->type==ELECTRON)
          {
            ex = functional->ExchangeEnergy(rho[igas],igas);
            sys->exc += 0.5*gw[igp]*ex;
            vx = functional->ExchangePotential(rho[igas],igas);
            vc = functional->CorrelationPotential(rho,igas);
            v = gw[igp]*(vx+vc);
            int dbasa = sys->gas[igas]->auxnco;
            double abasa[dbasa];
            GetBasis(sys->gas[igas]->auxis,gx[igp],gy[igp],gz[igp],abasa);
            for (ibas=0;ibas<dbasa;ibas++)
              sys->gas[igas]->z[ibas] += abasa[ibas]*v;
          }
        }
      }
    }
    }  // irad
  }
  Neighbors(0,0,sys->gas[is_electron]->auxis,"clear");

  // Apply G^-1
  for (igas=0;igas<sys->ngas;igas++)
  {
    if (sys->gas[igas]->type==ELECTRON)
    {
      double tmp[sys->gas[igas]->auxnco];
      sys->gas[igas]->G->VectorMultiply(sys->gas[igas]->z,tmp);
      sys->gas[igas]->G->VectorMultiply(tmp,sys->gas[igas]->z);
    }
  }
}

void ADFT::KernelMatrix(Matrix *F, int id1, int id2)
{
  int dbas,iatom,ibas,igas,igp,jbas;
  double fx,fc,f,rhomax,sa;
  double rho[2];

  int dbasa = sys->gas[id1]->auxnco;
  int dbasb = sys->gas[id2]->auxnco;
  double abasa[dbasa];
  double abasb[dbasb];

  // Initialize
  F->SetZero();
  if (!functional) return;

  for (iatom=0;iatom<sys->mol->Natom();iatom++)
  {
    PrepareGrid(iatom);
    for (igp=0;igp<ngp;igp++)
    {
      rhomax = 0.0;
      for (igas=0;igas<sys->ngas;igas++)
      {
        dbas = sys->gas[igas]->auxnco;
        double abas[dbas];
        GetBasis(sys->gas[igas]->auxis,gx[igp],gy[igp],gz[igp],abas);
        sa = 0.0;
        for (ibas=0;ibas<dbas;ibas++)
          sa += abas[ibas]*sys->gas[igas]->x[ibas];
        if (sa<minrho) sa = 0.0;
        rho[igas] = sa;
        rhomax = X_MAX(rhomax,X_ABS(sa));
        if (igas==id1)
          for (ibas=0;ibas<dbas;ibas++)
            abasa[ibas] = abas[ibas];
        if (igas==id2)
          for (ibas=0;ibas<dbas;ibas++)
            abasb[ibas] = abas[ibas];
      }
      if (rhomax>minrho) 
      {
        if (id2==id1) fx = functional->ExchangeKernel(rho[id1],id1);
        else fx = 0.0;
        fc = functional->CorrelationKernel(rho,id1,id2);
        f = gw[igp]*(fx+fc);
        if (X_ABS(f)>X_TOL_NUM)
        {
          for (ibas=0;ibas<dbasa;ibas++)
            if (id2==id1)
              for (jbas=ibas;jbas<dbasb;jbas++)
                F->ShiftValue(ibas,jbas,f*abasa[ibas]*abasb[jbas]);
            else
              for (jbas=0;jbas<dbasb;jbas++)
                F->ShiftValue(ibas,jbas,f*abasa[ibas]*abasb[jbas]);
        }
      }
    }
  }
  if (id2==id1) F->Symmetrize();
}



/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// VWN Correlation functional
// S. Vosko, L. Wilk, M. Nusair, Can. J. Phys. 58, 1200 (1980)
#include <Parameter.h>
#include <VWN.h>
#include <Math.h>

static const double VWNA1 = 0.0621814;
static const double VWNA2 = 0.0310907;
static const double VWNA3 =-0.0337737;
static const double VWNB1 = 3.7274400;
static const double VWNB2 = 7.0604200;
static const double VWNB3 = 1.1310710;
static const double VWNC1 =12.9352000; 
static const double VWNC2 =18.0578000;
static const double VWNC3 =13.0045000;
static const double VWNX01=-0.1049800;
static const double VWNX02=-0.3250000;
static const double VWNX03=-0.0047584;
static double VWNS = 2.0*(pow(2.0,1.0/3.0) - 1.0);
static double VWNF2Z = 4.0/(9.0*(pow(2.0,1.0/3.0) - 1.0));

double srs(double rhot)
{
  return sqrt(pow(0.75/(X_PI*rhot),1.0/3.0));
}

double VWN_Pade(double x,double a,double b,double c,double x0)
{
  double den,q,x0s,xs;

  q = sqrt(4.0*c-b*b);
  xs = x*x;
  x0s = x0*x0;
  den = x - x0;
  den = den*den;
  return a*(log(xs/den) - ((x0s + c)*log((xs+b*x+c)/den) +    
              2.0*b*(x0s-c)*atan(q/(2.0*x+b))/q)/(x0s+b*x0+c));
}

// VWN_PadeDerivative1(x) = -(x/6) p'(x) 
double VWN_PadeDerivative1(double x,double a,double b,double c,double x0)
{
  double xs;

  xs = x*x;
  return (1.0/3.0)*a*((1.0+b/(x-x0))*(xs/(xs+b*x+c))-1.0);
}

// VWN_PadeDerivative2(x) = (x/6)^2 p''(x)
double VWN_PadeDerivative2(double x,double a,double b,double c,double x0)
{
  double xs,dx,px;

  xs = x*x;
  dx = x-x0;
  px = xs+b*x+c;
  return -2.0*a*(1.0/xs-1.0/px*(b*x/(dx*dx)-(1.0+b/dx)*((c-xs)/px)))*xs/36.0;
}


// Evaluates VWN correlation energy functional
double VWN_energy(double *rho)
{
  double ec;
  double rhot,s,ep,ef,ez,sp,zs,zs4;

  rhot = rho[0] + rho[1];
  if (rhot>1.0e-10) 
  {
    s = srs(rhot);
    ep = VWN_Pade(s,VWNA1,VWNB1,VWNC1,VWNX01);
    zs = (rho[0] - rho[1])/rhot;
    ec = ep;
  }
  else
  {
    zs = 0.0;
    ec = 0.0;
  }
  if (X_ABS(zs)>X_TOL_NUM)
  {
    sp = (pow(1.0+zs,4.0/3.0)+pow(1.0-zs,4.0/3.0) - 2.0)/VWNS;
    ef = VWN_Pade(s,VWNA2,VWNB2,VWNC2,VWNX02);
    ez = VWN_Pade(s,VWNA3,VWNB3,VWNC3,VWNX03);
    zs4 = pow(zs,4.0);
    ec += sp*((ef-ep)*zs4 + ez*(1.0-zs4)/VWNF2Z);
  }
  ec *= 0.5*rhot;

  return ec;
}

// Evaluates VWN correlation potential
double VWN_potential(double *rho,int id)
{
  double vc;
  double def,defpz,dep,dez,dsp,ef,efpz,ep,ez,rhot;
  double s,sp,vcfp,vcpol,zs,zs3;

  rhot = rho[0] + rho[1];
  if (rhot>1.0e-10)
  {
    s = srs(rhot);
    ep = VWN_Pade(s,VWNA1,VWNB1,VWNC1,VWNX01);
    dep = VWN_PadeDerivative1(s,VWNA1,VWNB1,VWNC1,VWNX01);
    vc = ep + dep;
    zs = (rho[0] - rho[1])/rhot;
  }
  else
  {
    vc = 0.0;
    zs = 0.0;
  }
  if (X_ABS(zs)>X_TOL_NUM)
  {
    sp = (pow(1.0+zs,4.0/3.0)+pow(1.0-zs,4.0/3.0) - 2.0)/VWNS;
    dsp = (4.0/3.0)*(pow(1.0+zs,1.0/3.0)-pow(1.0-zs,1.0/3.0))/VWNS;
    zs3 = pow(zs,3.0);
    ef = VWN_Pade(s,VWNA2,VWNB2,VWNC2,VWNX02);
    ez = VWN_Pade(s,VWNA3,VWNB3,VWNC3,VWNX03)/VWNF2Z;
    efpz = zs3*(ef - ep - ez);
    def = VWN_PadeDerivative1(s,VWNA2,VWNB2,VWNC2,VWNX02);
    dez = VWN_Pade(s,VWNA3,VWNB3,VWNC3,VWNX03)/VWNF2Z;
    defpz = zs3*(def - dep - dez);
    vcfp = sp*(zs*(efpz + defpz) + ez + dez);
    vcpol = dsp*(zs*efpz + ez) + 4.0*sp*efpz;
    if (id==0) vc += vcfp + (1.0 - zs)*vcpol;
    else if (id==1) vc += vcfp - (1.0 + zs)*vcpol;
  }
  vc *= 0.5;

  return vc;
}

// Evaluates VWN correlation kernel
double VWN_kernel(double *rho,int id1, int id2)
{
  double kernel;
  double r13;
  double czs,zs,zs3,s,rhot;
  double ep,ef,efpz,ez,sp;
  double dep,def,defpz,dez,dsp;
  double d2ep,d2ef,d2efpz,d2ez,d2sp;

  r13 = 1.0/3.0;
  rhot = rho[0] + rho[1];
  if (rhot>1.0e-10) 
  {
    zs = (rho[0] - rho[1])/rhot;
    s = srs(rhot);

    d2sp = 0.0;
    if (X_ABS(1.0+zs)>X_TOL_NUM) d2sp += pow(1.0 + zs,-2.0/3.0);
    if (X_ABS(1.0-zs)>X_TOL_NUM) d2sp += pow(1.0 - zs,-2.0/3.0);
    d2sp *= (4.0/9.0)/VWNS;

    ez = VWN_Pade(s,VWNA3,VWNB3,VWNC3,VWNX03)/VWNF2Z;
    dep = VWN_PadeDerivative1(s,VWNA1,VWNB1,VWNC1,VWNX01);
    d2ep = VWN_PadeDerivative2(s,VWNA1,VWNB1,VWNC1,VWNX01);

    if (id1==id2) kernel = d2ep + (5.0/6.0)*dep + d2sp*ez;
    else kernel = d2ep + (5.0/6.0)*dep - d2sp*ez;
  }
  else
  {
    zs = 0.0;
    kernel = 0.0;
  }

  if (X_ABS(zs)>X_TOL_NUM)
  {
    sp = (pow(1.0+zs,4.0/3.0)+pow(1.0-zs,4.0/3.0) - 2.0)/VWNS;
    dsp = (4.0/3.0)*(pow(1.0+zs,1.0/3.0)-pow(1.0-zs,1.0/3.0))/VWNS;
    ep = VWN_Pade(s,VWNA1,VWNB1,VWNC1,VWNX01);
    ef = VWN_Pade(s,VWNA2,VWNB2,VWNC2,VWNX02);
    def = VWN_PadeDerivative1(s,VWNA2,VWNB2,VWNC2,VWNX02);
    dez = VWN_PadeDerivative1(s,VWNA3,VWNB3,VWNC3,VWNX03)/VWNF2Z;
    d2ef = VWN_PadeDerivative2(s,VWNA2,VWNB2,VWNC2,VWNX02);
    d2ez = VWN_PadeDerivative2(s,VWNA3,VWNB3,VWNC3,VWNX03)/VWNF2Z;
    zs3 = pow(zs,3.0);
    czs = 1.0 - zs;
    efpz = zs3*(ef - ep - ez);
    defpz = zs3*(def - dep - dez);
    d2efpz = zs3*(d2ef - d2ep - d2ez);
    if ((id1==0&&id2==0)||(id1==1&&id2==1)||id1+id2==1)
    {
      kernel += sp*(12.0*efpz/zs*czs*czs - defpz*(zs*(7.0+0.5*r13)-8.0) + 
            (5.0/6.0)*dez+zs*d2efpz+d2ez) + 2.0*dsp*czs*(zs*defpz + dez + 4.0* 
            czs*efpz)+ d2sp*((ez + zs*efpz)*czs*czs-ez);
    }
    if (id1==1&&id2==1)
    {
      kernel += 16.0*sp*(3.0*efpz - defpz) + 
            4.0*dsp*(zs*(8.0*efpz-defpz) - dez) + 4.0*d2sp*zs*(ez+zs*efpz);
    }
    else if (id1+id2==1)
    {
      kernel = d2ep + (5.0/6.0)*dep + d2sp*ez;
      kernel += - 8.0*sp*(3.0*czs*efpz/zs + defpz) - 2.0*dsp*
            (8.0*efpz*czs + zs*defpz + dez) - 2.0*d2sp*czs*(ez + zs*efpz);
    }
  }
  kernel *= 0.5/rhot;

  return kernel;
}



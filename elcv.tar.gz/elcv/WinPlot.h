/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: PlotManager class.
//
// 2015: Roberto Flores-Moreno
// ******************************************************************

#ifndef X_WIN_PLOT_H
#define X_WIN_PLOT_H

#include <vector>

#include <QWidget>

#include <Vector.h>

using namespace std;

class QListWidget;
class QTabWidget;
class QVBoxLayout;
class QDoubleSpinBox;
class QCheckBox;
class QRadioButton;

class Xalisco;
class Viewer;
class Vector;
class Plotter;

class WinPlot : public QWidget
{
  Q_OBJECT

  public:
    WinPlot( Xalisco* , Viewer* );

    Xalisco *xalisco;
    Viewer *viewer;
    Plotter *plotter;

    vector<double> temp;

  public slots:

    void Adjust(void);
    void ChangeIso( double );
    void ChangeLineWidth( int );
    void ChangePointSize( int );
    void ChangeBox( double );
    void ChangeMesh( double );
    void ChangeFlags( void );  
    void ChangeSetNumber( int );
    void ChangeOrbitalNumber( int );
    void SetupPlot(void);
    void BuildPlot(void);

  protected:

    void NewList( char** , int , char* ); 
    void SetupBox( QVBoxLayout* );

    int hold;
    int hide_surfaces;
    int drawref;
    int approximate_normals;
    int average_normals;

    int shiny;
    int line_width;
    int set_number;
    int orbital_number;
    int point_size;
    int lastplaneaxis;
    double isovalue;

    QDoubleSpinBox *cminS;
    QDoubleSpinBox *cmaxS;
    QDoubleSpinBox *cstepS;
    QDoubleSpinBox *isoS;
    QDoubleSpinBox *meshS;

    QDoubleSpinBox* axis[4][3];
    QCheckBox* flagbox[4][3];
    QTabWidget *tabWidget;
    vector<QWidget*> tabs;
    vector<QListWidget*> listados;
    vector<double> grdval;
    vector<double> grdvaldegen;
    vector<Vector> grdvec;
    vector<Vector> grdvecdegen;

};

#endif  // WIN_PLOT_H

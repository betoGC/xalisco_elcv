/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Definition of GaussianGas
//
// 2015: Roberto Flores Moreno
// ******************************************************************

#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <iostream>
#include <fstream>
#include <string>

#include <GaussianGas.h>
#include <GaussianSet.h>
#include <GaussianShell.h>
#include <Molecular.h>
#include <Atom.h>
#include <Element.h>
#include <Matrix.h>
#include <System.h>
#include <QChem.h>
#include <SCF.h>
#include <Becke.h>
#include <Integrator.h>
#include <ECPIntegrator.h>
#include <DFT.h>
#include <Constants.h>
#include <Units.h>
#include <Math.h>

using namespace std;

GaussianGas::GaussianGas(System* isys,int iid, int itype,int inpart)
{
  type = itype;
  npart = inpart;
  HOMO = npart-1;
  sys = isys;
  id = iid;
  basis.clear();
  auxis.clear();
  pps.clear();
  gi = new Integrator();
  energies = 0;
  oo = 0;
  x = 0;
  z = 0;
  for (int itype=0;itype<NTYPES;itype++)
    eribuf[itype] = 0;
};

// Buil gas of particles locating basis on the atoms
void GaussianGas::FromMolecular(Molecular* mol,char* basname)
{
  LoadPrimaryBasis(mol,basname);
  nmo = nco;
  GenerateAuxiliaryBasis();
  LoadPotentials(mol,basname);
  
  if (type==ELECTRON)
  {
    particle_mass = 1.0;
    particle_charge = -1.0;
  }
  else if (type==PROTON)
  {
    particle_mass = 1836.2;
    particle_charge = 1.0;
  }
  else if (type==SOLVENT)
  {
    particle_mass = 22.9898*1836.2;  // FIXME SODIUM only now
    particle_charge = 0.0; 
  }

  // Initialize central force integrator
  ecp = new ECPIntegrator(this);
};

void GaussianGas::Print(char* filename)
{
  ofstream f(filename,ios::app);
  if (type==ELECTRON) f << "Particle type = ELECTRON"<<endl;
  else if (type==PROTON) f << "Particle type = PROTON"<<endl;
  else if (type==SOLVENT) f << "Particle type = SOLVENT"<<endl;
  f << endl << "PRIMARY BASIS "<<endl;
  f.close();
  for (int ib=0;ib<(signed)basis.size();ib++)
    basis[ib]->Print(filename);

  ofstream ff(filename,ios::app);
  ff << endl<< "AUXILIARY BASIS "<<endl;
  ff.close();
  for (int ib=0;ib<(signed)basis.size();ib++)
    auxis[ib]->Print(filename);
 
  ofstream fff(filename,ios::app);
  fff << endl << "POTENTIAL "<<endl;
  fff.close();
  for (int ib=0;ib<(signed)pps.size();ib++)
    pps[ib]->Print(filename);
 
  if (C)
  {
    C->Print(filename,(char*)"Molecular orbital coefficients",20,14);
  }
};

void GaussianGas::OneParticleMatrix(Matrix *mat, char* option)
{
  int dao,i,ib,is,j,jb,js,k,lla,llb,lmax;
  double ra[3],rb[3],rc[3];
  double **intblk, **intblk2;
  GaussianShell *sa,*sb;

  lmax = LMax(basis);
  dao = ((lmax+1)*(lmax+2))/2;


  intblk = new double*[dao];
  for (i=0;i<dao;i++)
    intblk[i] = new double[dao];
  if ( strncmp(option,"core",4) == 0 ) 
  {
    intblk2 = new double*[dao];
    for (i=0;i<dao;i++)
      intblk2[i] = new double[dao];
  };

  for (ib=0;ib<(signed)basis.size();ib++)
  {
    ra[0] = basis[ib]->x; 
    ra[1] = basis[ib]->y; 
    ra[2] = basis[ib]->z; 
    for (jb=0;jb<(signed)basis.size();jb++)
    {
      rb[0] = basis[jb]->x; 
      rb[1] = basis[jb]->y; 
      rb[2] = basis[jb]->z; 
      for (is=0;is<(signed)basis[ib]->shell.size();is++)
      {
        sa = basis[ib]->shell[is];
        lla = basis[ib]->ll+sa->ll;
        for (js=0;js<(signed)basis[jb]->shell.size();js++)
        {
          sb = basis[jb]->shell[js];
          llb = basis[jb]->ll+sb->ll;

          if ((jb>ib)||((jb==ib)&&(js>=is))) 
          {

          if ( strncmp(option,"kinet",5) == 0 )
          {
            gi->Kinetic(ra,rb,sa,sb,intblk,0,true);
            // Apply mass 
            for (i=0;i<sa->nco;i++)
              for (j=0;j<sb->nco;j++)
                intblk[i][j] /= particle_mass;
          }
          else if ( strncmp(option,"core",4) == 0 )
          {
            for (i=0;i<sa->nco;i++)
              for (j=0;j<sb->nco;j++)
                intblk[i][j] = 0.0;
            // Coulomb potential due to point charges
            for (k=0;k<sys->mol->Natom();k++)
            {
              if (sys->mol->atom[k]->charge>0.0)
              {
                rc[0] = sys->mol->atom[k]->x; 
                rc[1] = sys->mol->atom[k]->y; 
                rc[2] = sys->mol->atom[k]->z; 
                gi->Core(ra,rb,rc,sa,sb,intblk2,0,0,true);
                for (i=0;i<sa->nco;i++)
                  for (j=0;j<sb->nco;j++)
                    intblk[i][j] += intblk2[i][j]*
                    sys->mol->atom[k]->charge*particle_charge;
              }
            }
          }
          else if ( strncmp(option,"dipole",6) == 0 )
          {
            if ( strncmp(option,"dipole x",8) == 0 )
              gi->Dipole(ra,rb,sa,sb,intblk,0);
            else if ( strncmp(option,"dipole y",8) == 0 )
              gi->Dipole(ra,rb,sa,sb,intblk,1);
            else gi->Dipole(ra,rb,sa,sb,intblk,2);
           
          }
          else 
          {
            gi->Overlap(ra,rb,sa,sb,intblk,0,true);
          }
          for (i=0;i<sa->nco;i++)
            for (j=0;j<sb->nco;j++)
              mat->ShiftValue(lla+i,llb+j,intblk[i][j]);
          }
        }
      }
    }
  }

  for (i=0;i<dao;i++)
    delete[] intblk[i];
  delete[] intblk;
  if ( strncmp(option,"core",4) == 0 ) 
  {
    for (i=0;i<dao;i++)
      delete[] intblk2[i];
    delete[] intblk2;
  }

  mat->Symmetrize();
}

// Build canonical orthogonalization (X) matrix
// Note: calculated it corresponds to the transpose of X
void GaussianGas::OrthogonalizationMatrix()
{
  int i,j;

  // Build overlap matrix
  X->SetZero();
  OneParticleMatrix(X,(char*)"overlap");
  X->Print((char*)"overlap.xal",(char*)"Overlap matrix",15,5);

  // Allocate auxiliary fields
  double values[nco];
  X->Diagonalize(values); 

  
  double vec[nco];

  for (i=0;i<nmo;i++)
  {
    if (values[i]<1.0e-14)
    {
      values[i] = 0.0;
      for (j=0;j<nmo;j++)
        X->SetValue(j,i,0.0);
    }
    else
    {
      X->GetColValues(i,vec);
      for (j=0;j<nmo;j++)
        X->SetValue(j,i,vec[j]/sqrt(values[i]));
    }
  }
  X->Print((char*)"X.xal",(char*)"Orthogonalization matrix",15,5);
}


void GaussianGas::TwoParticleMatrix(Matrix* H,GaussianGas* other, bool exchange)
{
  int eriindx,i,ib,ibo,is,iso,j,jb,jbo,js,jso,k,l,lla,llao,llb,llbo;
  bool skip[2];
  double ra[3],rao[3],rb[3],rbo[3];
  double blk[X_MAX_NCO][X_MAX_NCO][X_MAX_NCO][X_MAX_NCO];
  GaussianShell *sa,*sao,*sb,*sbo;

  Matrix *PO = new Matrix(other->nco,other->nco);
  other->GetDensityMatrix(PO);

  if (type==SOLVENT||other->type==SOLVENT)
  {
    if (type==other->type)
    {
      // FIXME: Potential belong to pairs not individual sets
      gi->SetInteractionPotential(pps[0]->shell[0]);
      gi->SetInteraction(&GammaSolvent);
    }
    else 
    {
      cout << "Solvent mixed not allowed yet"<<endl;
      exit(EXIT_FAILURE);
    }
  } 
  else 
  {
    gi->SetInteraction(&GammaCoulomb);

    // Effect of charges: repulsion or atraction
    PO->Scale( particle_charge*other->particle_charge );
  }

  eriindx=0;
  // Interaction/exchange contributions
  for (ib=0;ib<(signed)basis.size();ib++)
  {
    ra[0] = basis[ib]->x; 
    ra[1] = basis[ib]->y; 
    ra[2] = basis[ib]->z; 
    for (jb=0;jb<(signed)basis.size();jb++)
    {
      rb[0] = basis[jb]->x; 
      rb[1] = basis[jb]->y; 
      rb[2] = basis[jb]->z; 
      for (is=0;is<(signed)basis[ib]->shell.size();is++)
      {
        sa = basis[ib]->shell[is];
        lla = basis[ib]->ll+sa->ll;
        for (js=0;js<(signed)basis[jb]->shell.size();js++)
        {
          sb = basis[jb]->shell[js];
          llb = basis[jb]->ll+sb->ll;

          for (ibo=0;ibo<(signed)other->basis.size();ibo++)
          {
            rao[0] = other->basis[ibo]->x; 
            rao[1] = other->basis[ibo]->y; 
            rao[2] = other->basis[ibo]->z; 
            for (jbo=0;jbo<(signed)other->basis.size();jbo++)
            {
              rbo[0] = other->basis[jbo]->x; 
              rbo[1] = other->basis[jbo]->y; 
              rbo[2] = other->basis[jbo]->z; 
              for (iso=0;iso<(signed)other->basis[ibo]->shell.size();iso++)
              {
                sao = other->basis[ibo]->shell[iso];
                llao = other->basis[ibo]->ll+sao->ll;
                for (jso=0;jso<(signed)other->basis[jbo]->shell.size();jso++)
                {
                  sbo = other->basis[jbo]->shell[jso];
                  llbo = other->basis[jbo]->ll+sbo->ll;

                  if (direct||!conventional_ready[other->type]) 
                    gi->Interaction(ra,rb,rao,rbo,sa,sb,sao,sbo,blk,X_TOL_NUM,skip,0,0,0);
                  if (!direct)
                  {
                    for (i=0;i<sa->nco;i++)
                      for (j=0;j<sb->nco;j++)
                        for (k=0;k<sao->nco;k++)
                          for (l=0;l<sbo->nco;l++)
                          {
                            if (!conventional_ready[other->type])
                              eribuf[other->type][eriindx] = blk[i][j][k][l];
                            else
                              blk[i][j][k][l] = eribuf[other->type][eriindx];
                            eriindx++;
                          }
                  }
                  AddInteraction(lla,llb,llao,llbo,sa->nco,sb->nco,sao->nco,
                             sbo->nco,blk,PO,H);
                  if (exchange)
                    AddExchange(lla,llb,llao,llbo,sa->nco,sb->nco,sao->nco,
                             sbo->nco,blk,PO,H);
                }
              }
            }
          }
        }
      }
    }
  }
  delete PO;

  if (!conventional_ready[other->type]) conventional_ready[other->type] = true;
}

// Add up four center integrals to Fock matrix (Interaction)
void GaussianGas::AddInteraction(int ll1,int ll2,int ll3,int ll4,
                             int n1,int n2,int n3,int n4,
double b[X_MAX_NCO][X_MAX_NCO][X_MAX_NCO][X_MAX_NCO], Matrix *PO, Matrix *H)
{
  int i,j,k,l;
  double p;

  for (k=0;k<n3;k++)
    for (l=0;l<n4;l++)
    {
      p = (*PO)(ll3+k,ll4+l);
      for (i=0;i<n1;i++)
        for (j=0;j<n2;j++)
           H->ShiftValue(ll1+i,ll2+j,b[i][j][k][l]*p);
    }
}
void GaussianGas::AddExchange(int ll1,int ll2,int ll3,int ll4,
                              int n1,int n2,int n3,int n4,
double b[X_MAX_NCO][X_MAX_NCO][X_MAX_NCO][X_MAX_NCO], Matrix *PO, Matrix* H)
{
  int i,j,k,l;
  double p;

  for (k=0;k<n3;k++)
    for (l=0;l<n4;l++)
      for (i=0;i<n1;i++)
        for (j=0;j<n2;j++)
        {
           if (type==SOLVENT) p = (*PO)(ll3+k,ll2+j); // FIXME: Solo solv. boson
           else p = -(*PO)(ll3+k,ll2+j);
           H->ShiftValue(ll1+i,ll4+l,b[i][j][k][l]*p);
        }
}

// Build AO density matrix (P)
void GaussianGas::BuildDensityMatrix()
{
  P->SetZero();
  BuildPartialDensityMatrix(P,0,HOMO);
}

void GaussianGas::BuildPartialDensityMatrix(Matrix *Q,int ll, int ul)
{
  int i,mu,nu;
  double moc[nco];

  for (i=ll;i<=ul;i++)
  {
    C->GetColValues( i , moc );
    for (mu=0;mu<nco;mu++)
      for (nu=0;nu<nco;nu++)
        Q->ShiftValue(mu,nu,oo[i]*moc[mu]*moc[nu]);
  }
}

void GaussianGas::BuildFrontierFukuiMatrix(Matrix *Q,int ll, int ul)
{
  int i,mu,nu;
  double moc[nco];

  for (i=ll;i<=ul;i++)
  {
    C->GetColValues( i , moc );
    for (mu=0;mu<nco;mu++)
      for (nu=0;nu<nco;nu++)
        Q->ShiftValue(mu,nu,moc[mu]*moc[nu]);
  }
}

void GaussianGas::SCFDensityMatrix(double s)
{
  int i,mu,nu;
  double moc[nco];

  P->Scale( 1.0 - s );

  for (i=0;i<=HOMO;i++)
  {
    C->GetColValues( i , moc );
    for (mu=0;mu<nco;mu++)
      for (nu=mu;nu<nco;nu++)
        P->ShiftValue(mu,nu,moc[mu]*moc[nu]*s);
  }

  // Symmetrize
  P->Symmetrize();
}

double GaussianGas::GetOrbitalEnergy(int id)
{
  if (energies&&id<nco) return energies[id];
  else return 99999.0;
}

// Batch of four center ERIs in MO representation
void GaussianGas::EvaluateERI4Batch(GaussianGas *other,int p,int q, Matrix eri)
{
  int i,ib,ibo,is,iso,j,jb,jbo,js,jso,k,l,lla,llao,llb,llbo;
  bool skip[2];
  double ss;
  double ra[3],rao[3],rb[3],rbo[3];
  double blk[X_MAX_NCO][X_MAX_NCO][X_MAX_NCO][X_MAX_NCO];
  double cblk[X_MAX_NCO][X_MAX_NCO][X_MAX_NCO];
  GaussianShell *sa,*sao,*sb,*sbo;

  double wp[nco];
  double wq[other->nco];
  C->GetColValues(p,wp);
  other->C->GetColValues(q,wq);

  for (k=0;k<nco;k++)
    for (j=0;j<other->nco;j++)
      eri(k,j) = 0.0;

  for (ibo=0;ibo<(signed)other->basis.size();ibo++)
  {
    rao[0] = other->basis[ibo]->x; 
    rao[1] = other->basis[ibo]->y; 
    rao[2] = other->basis[ibo]->z; 
    for (jbo=0;jbo<(signed)other->basis.size();jbo++)
    {
      rbo[0] = other->basis[jbo]->x; 
      rbo[1] = other->basis[jbo]->y; 
      rbo[2] = other->basis[jbo]->z; 
      for (iso=0;iso<(signed)other->basis[ibo]->shell.size();iso++)
      {
        sao = other->basis[ibo]->shell[iso];
        llao = other->basis[ibo]->ll+sao->ll;
        for (jso=0;jso<(signed)other->basis[jbo]->shell.size();jso++)
        {
          sbo = other->basis[jbo]->shell[jso];
          llbo = other->basis[jbo]->ll+sbo->ll;

          for (ib=0;ib<(signed)basis.size();ib++)
          {
            ra[0] = basis[ib]->x; 
            ra[1] = basis[ib]->y; 
            ra[2] = basis[ib]->z; 
            for (is=0;is<(signed)basis[ib]->shell.size();is++)
            {
              sa = basis[ib]->shell[is];
              lla = basis[ib]->ll+sa->ll;

              // ( p mu | nu sigma )
              for (i=0;i<sao->nco;i++)
                for (j=0;j<sbo->nco;j++)
                  for (k=0;k<sa->nco;k++)
                    cblk[i][j][k] = 0.0;


              for (jb=0;jb<(signed)basis.size();jb++)
              {
                rb[0] = basis[jb]->x; 
                rb[1] = basis[jb]->y; 
                rb[2] = basis[jb]->z; 
                for (js=0;js<(signed)basis[jb]->shell.size();js++)
                {
                  sb = basis[jb]->shell[js];
                  llb = basis[jb]->ll+sb->ll;

                  gi->Interaction(rao,rbo,ra,rb,sao,sbo,sa,sb,blk,
                              X_TOL_NUM,skip,0,0,0);
                  for (i=0;i<sao->nco;i++)
                    for (j=0;j<sbo->nco;j++)
                      for (k=0;k<sa->nco;k++)
                      {
                        ss = 0.0;
                        for (l=0;l<sb->nco;l++)
                          ss += wp[llb+l]*blk[i][j][k][l];
                          
                        cblk[i][j][k] += ss;
                      }
                }
              }
              // ( p mu | nu t )
              for (k=0;k<sa->nco;k++)
                for (j=0;j<sbo->nco;j++)
                {
                  ss = 0.0;
                  for (i=0;i<sao->nco;i++)
                    ss += wq[llao+i]*cblk[i][j][k];
                  eri(lla+k,llbo+j) += ss;
                }
            }
          }
        }
      }
    }
  }
  // ( p q | s t ) = < p s | q t >
  Matrix tmp(nco,other->nco);
  eri.Multiply(other->C,&tmp,true);
  C->Transpose();
  tmp.Multiply(C,&eri,false);
  C->Transpose();
}

void GaussianGas::EvaluateCharges(double *charges, char* popan, bool response)
{
  int i,ib,is,j,lla;
  double s;
  GaussianShell *sa;
  Matrix *S = new Matrix(nco,nco);

  // Mulliken population analysis
  OneParticleMatrix(S,(char*)"overlap");

  for (ib=0;ib<(signed)basis.size();ib++)
  {
    charges[ib] = 0.0; 
    for (is=0;is<(signed)basis[ib]->shell.size();is++)
    {
      sa = basis[ib]->shell[is];
      lla = basis[ib]->ll+sa->ll;
      for (i=0;i<sa->nco;i++)
      {
        s = 0.0;
        for (j=0;j<nco;j++)
        {
          if (response) s += (*P1)(lla+i,j)*(*S)(lla+i,j);
          else s += (*P)(lla+i,j)*(*S)(lla+i,j);
        }
        charges[ib] += s*particle_charge; 
      }
    }
  }
  delete S;
}


void GaussianGas::FittingVector(Matrix *W, double* cvec)
{
  int eriindx,i,ib,is,j,jb,js,k,kb,ks,lla,llb,llc;
  bool skip;
  double p;
  double ra[3],rb[3],rc[3];
  double blk[X_MAX_NCO][X_MAX_NCO][X_MAX_NCO];
  GaussianShell *sa,*sb,*sc;

  eriindx = 0;
  for (k=0;k<auxnco;k++)
    cvec[k] = 0.0;

  // Interaction/exchange contributions
  for (ib=0;ib<(signed)basis.size();ib++)
  {
    ra[0] = basis[ib]->x; 
    ra[1] = basis[ib]->y; 
    ra[2] = basis[ib]->z; 
    for (is=0;is<(signed)basis[ib]->shell.size();is++)
    {
      sa = basis[ib]->shell[is];
      lla = basis[ib]->ll+sa->ll;
      for (jb=0;jb<(signed)basis.size();jb++)
      {
        rb[0] = basis[jb]->x; 
        rb[1] = basis[jb]->y; 
        rb[2] = basis[jb]->z; 
        for (js=0;js<(signed)basis[jb]->shell.size();js++)
        {
          sb = basis[jb]->shell[js];
          llb = basis[jb]->ll+sb->ll;
          for (kb=0;kb<(signed)auxis.size();kb++)
          {
            rc[0] = auxis[kb]->x; 
            rc[1] = auxis[kb]->y; 
            rc[2] = auxis[kb]->z; 
            for (ks=0;ks<(signed)auxis[kb]->shell.size();ks++)
            {
              sc = auxis[kb]->shell[ks];
              llc = auxis[kb]->ll+sc->ll;

              if (direct||!conventional_ready[type]) 
                gi->Interaction3(ra,rb,rc,sa,sb,sc,blk,skip,0,0);

              if (!direct)
              {
                for (i=0;i<sa->nco;i++)
                  for (j=0;j<sb->nco;j++)
                    for (k=0;k<sc->nco;k++)
                    {
                      if (!conventional_ready[type])
                        eribuf[type][eriindx] = blk[i][j][k];
                      else
                        blk[i][j][k] = eribuf[type][eriindx];
                      eriindx++;
                    }
              }

              for (i=0;i<sa->nco;i++)
                for (j=0;j<sb->nco;j++)
                {
                  p = (*W)(lla+i,llb+j);
                  for (k=0;k<sc->nco;k++)
                    cvec[llc+k] += blk[i][j][k]*p;
                }
            }
          }
        }
      }
    }
  }
  if (!conventional_ready[type]) conventional_ready[type] = true;
}

void GaussianGas::BuildFittingMatrix(Matrix *GMat)
{
  int i,ib,is,j,jb,js,lla,llb;
  double ra[3],rb[3];
  double **blk;
  GaussianShell *sa,*sb;

  int lmax = LMax(auxis);
  int dblk = ((lmax+1)*(lmax+2))/2;
  blk = new double*[dblk];
  for (i=0;i<dblk;i++)
    blk[i] = new double[dblk];

  GMat->SetZero();

  // Build G matrix
  for (ib=0;ib<(signed)auxis.size();ib++)
  {
    ra[0] = auxis[ib]->x; 
    ra[1] = auxis[ib]->y; 
    ra[2] = auxis[ib]->z; 
    for (is=0;is<(signed)auxis[ib]->shell.size();is++)
    {
      sa = auxis[ib]->shell[is];
      lla = auxis[ib]->ll+sa->ll;
      for (jb=0;jb<(signed)auxis.size();jb++)
      {
        rb[0] = auxis[jb]->x; 
        rb[1] = auxis[jb]->y; 
        rb[2] = auxis[jb]->z; 
        for (js=0;js<(signed)auxis[jb]->shell.size();js++)
        {
          sb = auxis[jb]->shell[js];
          llb = auxis[jb]->ll+sb->ll;

          gi->Interaction2(ra,rb,sa,sb,blk,0);
          for (i=0;i<sa->nco;i++)
            for (j=0;j<sb->nco;j++)
              GMat->SetValue(lla+i,llb+j,blk[i][j]);
        }
      }
    }
  }
  
  for (i=0;i<dblk;i++)
    delete[] blk[i];
  delete[] blk;
}

void GaussianGas::FittingMatrix()
{
  BuildFittingMatrix(G);

  // G^-1/2
  double values[auxnco];
  G->SVDPower(values,double(-0.5),double(1.0e-7));
}

void GaussianGas::FittingCoefficients(void)
{
  double tmp[auxnco];

  FittingVector(P,x);
  G->VectorMultiply(x,tmp);
  G->VectorMultiply(tmp,x);
}

void GaussianGas::TwoParticleMatrixDF(Matrix* H,GaussianGas* other, double *w,double sf)
{
  int eriindx,i,ib,ibo,is,iso,j,jb,js,k,lla,llao,llb;
  bool skip;
  double factor;
  double ra[3],rb[3],rao[3];
  double cblk[X_MAX_NCO][X_MAX_NCO];
  double blk[X_MAX_NCO][X_MAX_NCO][X_MAX_NCO];
  GaussianShell *sa,*sb,*sao;

  eriindx=0;
  for (ib=0;ib<(signed)basis.size();ib++)
  {
    ra[0] = basis[ib]->x; 
    ra[1] = basis[ib]->y; 
    ra[2] = basis[ib]->z; 
    for (is=0;is<(signed)basis[ib]->shell.size();is++)
    {
      sa = basis[ib]->shell[is];
      lla = basis[ib]->ll+sa->ll;
      for (jb=0;jb<(signed)basis.size();jb++)
      {
        rb[0] = basis[jb]->x; 
        rb[1] = basis[jb]->y; 
        rb[2] = basis[jb]->z; 
        for (js=0;js<(signed)basis[jb]->shell.size();js++)
        {
          sb = basis[jb]->shell[js];
          llb = basis[jb]->ll+sb->ll;
          for (i=0;i<sa->nco;i++)
            for (j=0;j<sb->nco;j++)
              cblk[i][j] = 0.0;

          for (ibo=0;ibo<(signed)other->auxis.size();ibo++)
          {
            rao[0] = other->auxis[ibo]->x; 
            rao[1] = other->auxis[ibo]->y; 
            rao[2] = other->auxis[ibo]->z; 
            for (iso=0;iso<(signed)other->auxis[ibo]->shell.size();iso++)
            {
              sao = other->auxis[ibo]->shell[iso];
              llao = other->auxis[ibo]->ll+sao->ll;

              if (direct||!conventional_ready[other->type]) 
                gi->Interaction3(ra,rb,rao,sa,sb,sao,blk,skip,0,0);

              if (!direct)
              {
                for (i=0;i<sa->nco;i++)
                  for (j=0;j<sb->nco;j++)
                    for (k=0;k<sao->nco;k++)
                    {
                      if (!conventional_ready[other->type])
                        eribuf[other->type][eriindx] = blk[i][j][k];
                      else
                        blk[i][j][k] = eribuf[other->type][eriindx];
                      eriindx++;
                    }
              }

              for (i=0;i<sa->nco;i++)
                for (j=0;j<sb->nco;j++)
                  for (k=0;k<sao->nco;k++)
                  {
                    factor = w[llao+k]*sf;
                    cblk[i][j] += factor*blk[i][j][k];
                  }
            }
          }
          for (i=0;i<sa->nco;i++)
            for (j=0;j<sb->nco;j++)
              H->ShiftValue( lla+i,llb+j,cblk[i][j] );
        }
      }
    }
  }
  if (!conventional_ready[other->type]) conventional_ready[other->type] = true;
}

void GaussianGas::SetupSCF(char *method, char* guess,int id, bool idirect)
{
  // Integral occupations by default
  if (oo) delete[] oo; 
  oo = new double[nco];
  GetOccupations();

  C = new Matrix(nco,nco);

  // Guess density (guess=core)
  if ( strncmp(guess,"Core",4) == 0 ) 
  {
    if (type==PROTON)
    {
      int i,ib;
      // Put one at each basis center
      for (ib=0;ib<=HOMO;ib++)
      {
        i = basis[ib]->ll + basis[ib]->shell[0]->ll;
        C->ShiftValue(i,ib,1.0);
      }
    }
  }
  else if ( strncmp(guess,"File",4) == 0 ) 
    C->Read("Backup.xal","=== Molecular orbital coefficients ===",id,nmo);

  P = new Matrix(nco,nco);
  BuildDensityMatrix();

  F = new Matrix(nco,nco);

  if (energies) delete[] energies;
  energies = new double[nco];

  // Build core matrix
  H = new Matrix(nco,nco);

  // Build orthogonalization matrix
  // Orthogonalization must be called after creation of C
  X = new Matrix(nco,nco);

  // Build inverted G matrix
  G = new Matrix(auxnco,auxnco);
  FittingMatrix();
  if (x) delete[] x; x = new double[auxnco];
  if (z) delete[] z; z = new double[auxnco];

  // Response fields
  P1 = new Matrix(nco,nco);
  x1 = new double[auxnco];
  z1 = new double[auxnco];

  W = new Matrix(nco,nco);

  OrthogonalizationMatrix();
  BuildCoreMatrix();

  // For conventional SCF
  direct = idirect;
  if (!direct) 
  {
    int ig,nword,type;
    
    for (ig=0;ig<sys->ngas;ig++)
    {
      type=sys->gas[ig]->type;
      if (eribuf[type]) free(eribuf[type]);
      if ( strncmp(method,"Hartree-Fock",12) == 0 )
        nword = nco*nco*sys->gas[ig]->nco*sys->gas[ig]->nco;
      else
        nword = nco*nco*sys->gas[ig]->auxnco;
      eribuf[type] = (double*)malloc(nword*sizeof(double));
      conventional_ready[type] = false;
    }
  }
  if ( strncmp(guess,"Core",4) != 0 ) FittingCoefficients();
};



void GaussianGas::GetDensityMatrix(Matrix *PO)
{
  PO->Copy(P);
}


int GaussianGas::LMax(vector<GaussianSet*> basis)
{
  int ib,is,l,lmax;

  lmax = 0;
  for (ib=0;ib<(signed)basis.size();ib++)
  {
    for (is=0;is<(signed)basis[ib]->shell.size();is++)
    {
      l = basis[ib]->shell[is]->l;
      if (l>lmax) lmax = l;
    }
  }
  return lmax;
}

void GaussianGas::BuildCoreMatrix()
{
  H->SetZero();

  // Effective core potentials
  if (ecp) ecp->BuildMatrix(H);
  H->Print((char*)"ECP.xal",(char*)"ECP matrix",15,5);

  // Kinetic energy contribution
  OneParticleMatrix(H,(char*)"kinetic");

  // Nuclear atraction contribution
  OneParticleMatrix(H,(char*)"core");
}

// Load primary basis
void GaussianGas::LoadPrimaryBasis(Molecular* mol,char* basname)
{
  Atom* a;

  int cp=0;
  for (int iatom=0;iatom<mol->Natom();iatom++)
  {
    a = mol->atom[iatom];
    if (type==ELECTRON||type==SOLVENT||((type==PROTON)&&a->atomic_number==1))
    {
      GaussianSet *gset;

      if (strncmp(ELEMENT_NAME[a->atomic_number],"DUMMY",5)!=0)
      {
        gset = new GaussianSet( a->x, a->y, a->z );
        gset->LoadFromFile(basname,ELEMENT_NAME[a->atomic_number],false);
        basis.push_back( gset );
        cp = basis.size() - 1;
        if (cp==0) basis[cp]->ll = 0;
        else basis[cp]->ll = basis[cp-1]->ul + 1;
        basis[cp]->ul = basis[cp]->ll + basis[cp]->nco - 1;
      }
    }
  }
  cp = basis.size() - 1;
  if (cp>=0) nco = basis[cp]->ul + 1;
  else nco = 0;

  nmo = nco;
};

void GaussianGas::GenerateAuxiliaryBasis()
{
  GaussianSet *gseta;

  int cp=0;
  for (int ib=0;ib<(signed)basis.size();ib++)
  {
    gseta = new GaussianSet( basis[ib]->x, basis[ib]->y, basis[ib]->z );
    gseta->GenerateAuxiliar(basis[ib],gi);
    auxis.push_back( gseta );
    cp = auxis.size() - 1;
    if (cp==0) auxis[cp]->ll = 0;
    else auxis[cp]->ll = auxis[cp-1]->ul + 1;
    auxis[cp]->ul = auxis[cp]->ll + auxis[cp]->nco - 1;
  }
  cp = auxis.size() - 1;
  if (cp>=0) auxnco = auxis[cp]->ul + 1;
  else auxnco = 0;
}

void GaussianGas::LoadPotentials(Molecular* mol,char* basname)
{
  int i,nval;
  Atom* a;
  GaussianSet *pset;

  int cp=0;
  for (int iatom=0;iatom<mol->Natom();iatom++)
  {
    a = mol->atom[iatom];

    // Determine number of valence electrons
    if ((type==ELECTRON)&&
        ((strncmp(basname,"ECP",3) == 0 )||
         (strncmp(basname,"QECP",4) == 0 )||
         (strncmp(basname,"RECP",4) == 0 )))
    {
      char str[X_MAX_STR_SIZE];
      strcpy(str,basname);
      for (i=0;i<(signed)strlen(str);i++)
        if (str[i]=='|') str[i] = '\0';
      if (strncmp(basname,"ECP",3) == 0 ) nval = atoi(&str[3]);
      else nval = atoi(&str[4]);
      a->SetCharge(double(nval));
    }

    // Load potential
    if (((type==ELECTRON)&&
         ((strncmp(basname,"ECP",3) == 0 )||
          (strncmp(basname,"QECP",4) == 0 )||
          (strncmp(basname,"RECP",4) == 0 )))||
        type==SOLVENT)
    {
      if (strncmp(ELEMENT_NAME[a->atomic_number],"DUMMY",5)!=0)
      {
        pset = new GaussianSet( a->x, a->y, a->z );
        pset->LoadFromFile(basname,ELEMENT_NAME[a->atomic_number],true);
        pps.push_back( pset );
        cp = pps.size() - 1;
        if (cp==0) pps[cp]->ll = 0;
        else pps[cp]->ll = pps[cp-1]->ul + 1;
        pps[cp]->ul = pps[cp]->ll + pps[cp]->nco - 1;
      }
    }
  }
  cp = pps.size() - 1;
  if (cp>=0) npo = pps[cp]->ul + 1;
  else npo = 0;
}

void GaussianGas::EvaluateMOERI3(GaussianGas *other, int p, Matrix* eri)
{
  int i,ib,is,j,jb,js,k,kb,ks,lla,llb,llc,q;
  bool skip;
  double ra[3],rb[3],rc[3];
  double tblk[X_MAX_NCO][X_MAX_NCO];
  double blk[X_MAX_NCO][X_MAX_NCO][X_MAX_NCO];
  GaussianShell *sa,*sb,*sc;

  eri->SetZero();

  for (kb=0;kb<(signed)other->auxis.size();kb++)
  {
    rc[0] = other->auxis[kb]->x; 
    rc[1] = other->auxis[kb]->y; 
    rc[2] = other->auxis[kb]->z; 
    for (ks=0;ks<(signed)other->auxis[kb]->shell.size();ks++)
    {
      sc = other->auxis[kb]->shell[ks];
      llc = other->auxis[kb]->ll+sc->ll;
      // Build AO-ERIs
      for (ib=0;ib<(signed)basis.size();ib++)
      {
        ra[0] = basis[ib]->x; 
        ra[1] = basis[ib]->y; 
        ra[2] = basis[ib]->z; 
        for (is=0;is<(signed)basis[ib]->shell.size();is++)
        {
          sa = basis[ib]->shell[is];
          lla = basis[ib]->ll+sa->ll;
          for (i=0;i<sa->nco;i++)
            for (k=0;k<sc->nco;k++)
              tblk[i][k] = 0.0;
          for (jb=0;jb<(signed)basis.size();jb++)
          {
            rb[0] = basis[jb]->x; 
            rb[1] = basis[jb]->y; 
            rb[2] = basis[jb]->z; 
            for (js=0;js<(signed)basis[jb]->shell.size();js++)
            {
              sb = basis[jb]->shell[js];
              llb = basis[jb]->ll+sb->ll;

              gi->Interaction3(ra,rb,rc,sa,sb,sc,blk,skip,0,0);
              for (i=0;i<sa->nco;i++)
                for (k=0;k<sc->nco;k++)
                  for (j=0;j<sb->nco;j++)
                    tblk[i][k] += blk[i][j][k]*(*C)(llb+j,p);
            }
          }
          for (q=0;q<nmo;q++)
            for (i=0;i<sa->nco;i++)
              for (k=0;k<sc->nco;k++)
                eri->ShiftValue(llc+k,q,tblk[i][k]*(*C)(lla+i,q));
        }
      }
    }
  }
}

void GaussianGas::EvaluateERI4BatchRI(GaussianGas *other,int p,int q, Matrix eri)
{
  Matrix left(auxnco,nco);
  EvaluateMOERI3(this,p,&left);
  Matrix auxleft(auxnco,nco);
  left.Multiply(G,&auxleft,false);
  auxleft.Multiply(G,&left,false);
  left.Transpose();

  Matrix right(auxnco,other->nco);
  other->EvaluateMOERI3(this,q,&right);

  left.Multiply(&right,&eri,true);
}

void GaussianGas::GetOccupations()
{
  int i;

  if (sys->temperature==0.0)
  {
    for (i=0;i<nmo;i++)
      if (i<=HOMO) oo[i] = 1.0; 
      else oo[i] = 0.0; 

    if (sys->qchem->scf->atomic&&type==ELECTRON)
    {
      // XYZ for P
      // ABCDE for D
      // 1234567 for F
      char *ao = "SSXYZSXYZSABCDEXYZSABCDEXYZS1234567ABCDEXYZS1234567ABCDEXYZS";
      if (ao[HOMO]=='X')
      {
        for (i=0;i<3;i++)
          oo[HOMO+i] = 1.0/3.0;
        HOMO += 2;
      }
      else if (ao[HOMO]=='Y')
      {
        for (i=-1;i<2;i++)
          oo[HOMO+i] = 2.0/3.0;
        HOMO += 1;
      }
      else if (ao[HOMO]=='A')
      {
        for (i=0;i<5;i++)
          oo[HOMO+i] = 1.0/5.0;
        HOMO += 4;
      }
      else if (ao[HOMO]=='B')
      {
        for (i=-1;i<4;i++)
          oo[HOMO+i] = 2.0/5.0;
        HOMO += 3;
      }
      else if (ao[HOMO]=='C')
      {
        for (i=-2;i<3;i++)
          oo[HOMO+i] = 3.0/5.0;
        HOMO += 2;
      }
      else if (ao[HOMO]=='D')
      {
        for (i=-3;i<2;i++)
          oo[HOMO+i] = 4.0/5.0;
        HOMO += 1;
      }
      else if (ao[HOMO]=='1')
      {
        for (i=0;i<7;i++)
          oo[HOMO+i] = 1.0/7.0;
        HOMO += 6;
      }
      else if (ao[HOMO]=='2')
      {
        for (i=-1;i<6;i++)
          oo[HOMO+i] = 2.0/7.0;
        HOMO += 5;
      }
      else if (ao[HOMO]=='3')
      {
        for (i=-2;i<5;i++)
          oo[HOMO+i] = 3.0/7.0;
        HOMO += 4;
      }
      else if (ao[HOMO]=='4')
      {
        for (i=-3;i<4;i++)
          oo[HOMO+i] = 4.0/7.0;
        HOMO += 3;
      }
      else if (ao[HOMO]=='5')
      {
        for (i=-4;i<3;i++)
          oo[HOMO+i] = 5.0/7.0;
        HOMO += 2;
      }
      else if (ao[HOMO]=='6')
      {
        for (i=-5;i<2;i++)
          oo[HOMO+i] = 6.0/7.0;
        HOMO += 1;
      }
    }
  }
  else
  {
    double beta,expo;

    for (i=0;i<nmo;i++)
    {
      expo = energies[i] - sys->chemical_potential;
      beta = 1.0/JMolToHartree(X_RGAS)*sys->temperature;
      oo[i] = 1.0/(1.0+exp(beta*expo)); 
    }
    for (i=nmo-1;i>=0;i--)
    {
      if (oo[i]>1.0e-3) 
      {
        HOMO = i;
        break;
      }
    }
  }
}

double GaussianGas::Entropy()
{
  int i;
  double S;

  S = 0.0;
  for (i=nmo-1;i>=0;i--)
  {
    S += oo[i]*log(oo[i])+(1.0-oo[i])*log(1.0-oo[i]);
  }
  S *= - X_BOLTZMANN;

  return S;
}

void GaussianGas::McWeeny(Matrix* K1)
{
  int a,i,mu,nu;
  double s;

  Matrix mom(HOMO+1,nmo-(HOMO+1));

  // Transform to MOs
  for (i=0;i<=HOMO;i++)
  {
    for (a=HOMO+1;a<nmo;a++)
    {
      s = 0.0;
      for (mu=0;mu<nco;mu++)
        for (nu=0;nu<nco;nu++)
          s += (*K1)(mu,nu)*(*C)(mu,i)*(*C)(nu,a);
      mom(i,a-(HOMO+1)) = s;
    }
  }

  // Scale with eigenvalues
  for (i=0;i<=HOMO;i++)
    for (a=HOMO+1;a<nmo;a++)
      mom(i,a-(HOMO+1)) /= (energies[i]-energies[a]);

  // Back transformation
  for (mu=0;mu<nco;mu++)
  {
    for (nu=0;nu<nco;nu++)
    {
      s = 0.0;
      for (i=0;i<=HOMO;i++)
        for (a=HOMO+1;a<nmo;a++)
          s += mom(i,a-(HOMO+1))*(*C)(mu,i)*(*C)(nu,a);
      (*K1)(mu,nu) = 2.0*s;
    }
  }
}

void GaussianGas::BuildPulayMatrix(Matrix *Q)
{
  int i,mu,nu;
  double moc[nco];

  Q->SetZero();

  for (i=0;i<=HOMO;i++)
  {
    C->GetColValues( i , moc );
    for (mu=0;mu<nco;mu++)
      for (nu=0;nu<nco;nu++)
        Q->ShiftValue(mu,nu,-oo[i]*energies[i]*moc[mu]*moc[nu]);
  }
}

void GaussianGas::NewMOs(bool project)
{
  if (project) 
  {
    P1->SetZero();
    OneParticleMatrix(P1,(char*)"overlap");
    P1->Multiply(C,W,true);
  }

  F->Multiply(X,C,true);
  X->Transpose();
  C->Multiply(X,F,false);
  X->Transpose();

  F->Diagonalize(energies); 
  F->Multiply(X,C,false);

  if (project) 
  {
    int i,imax,j;
    double val1,val2;
    double *vec1,*vec2;

    vec1 = new double[nco];
    vec2 = new double[nco];

    C->Transpose();
    W->Multiply(C,F,false);
    C->Transpose();
    for (i=0;i<=HOMO;i++)
    {
      // Find largest overlap
      F->GetColValues(i,vec1);
      imax=i;
      for (j=i+1;j<nmo;j++)
        if (X_ABS(vec1[j])>X_ABS(vec1[imax])) imax = j;
      // Exchange position of orbitals
      if (imax!=i)
      {
        C->GetColValues(i,vec1);
        C->GetColValues(imax,vec2);
        val1 = energies[i];
        val2 = energies[imax];
        C->SetColValues(i,vec2);
        C->SetColValues(imax,vec1);
        energies[i] = val2;
        energies[imax] = val1;
      }
    }
    delete[] vec1;
    delete[] vec2;
  }
}


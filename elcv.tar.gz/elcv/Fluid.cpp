/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <iostream>
#include <iomanip>

#include <Fluid.h>
#include <FiniteVolume.h>
#include <Math.h>

using namespace std;

//Carga todos los valores de condiciones iniciales.
Fluid::Fluid(Chemistry *chem)
{
  int i,nx;
  double xstep;
  double xyz[3];

  length = 0.001;           // cm
  area = 1.0; //rfm length*length;   // cm^2

  // Build finite volumes
  //nx = 300;
  nx = 100; //Enough value for mass profile asymptotic behavior
  xstep = length;      // cm
  volume.clear();
  xyz[0] = 0.0;
  xyz[1] = 0.0;
  xyz[2] = 0.0;
  for (i=0;i<nx;i++)
  {
    if (i==0) 
      xyz[0] += 0.5*xstep;
    else
      xyz[0] += xstep;
    volume.push_back( new FiniteVolume( xyz, length*area, chem ) );
    if (i>0)
    {
      volume[i]->AddNeighbor( volume[i-1] , area );
      volume[i-1]->AddNeighbor( volume[i] , area );
    }
  }
}


void Fluid::Evolve(double dt, double temperature, double voltage, double *charge_collected)
{
  int nvol = volume.size();
  if (nvol<1) return;

  int i,k;
  double t,local_dt;

  
  t = 0.0;
  local_dt = 1.0e-5*length*length/1.0e-5;
  while (t<dt)
  {
    if (t+local_dt>dt) local_dt = dt - t + X_TOL_NUM;

    volume[0]->EvolveChemistry(local_dt,temperature,voltage,charge_collected,true);
    for(k=1;k<nvol;k++)
      volume[k]->EvolveChemistry(local_dt,temperature,voltage,charge_collected,false);
    t += local_dt;
  }

  // Transport equations
  // Only the first one collects charge
  // The last is not allowed to evolve to enforce border conditions (bulk)
  for (i=0;i<nvol-1;i++)
    volume[i]->EvolveTransport(dt);

  for (i=0;i<nvol-1;i++)
    volume[i]->Save();


}

/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Vector (3D) management
//
// 2003-2015: Roberto Flores-Moreno
// ******************************************************************

#ifndef X_VECTOR_H
#define X_VECTOR_H

class Vector
{
public:
  Vector( double xx = 0.0 ,
          double yy = 0.0 ,
          double zz = 0.0 );
  Vector( double* );

  double x;
  double y;
  double z; 

  Vector operator + ( const Vector & );
  Vector operator - ( const Vector & );
  Vector operator * ( double );
  Vector operator * ( int );
  Vector operator / ( double );
  Vector operator % ( double m[3][3] );
  Vector operator ^ ( double );
  Vector operator < ( const Vector & );
  Vector operator > ( const Vector & );

  void operator += ( const Vector & );
  void operator -= ( const Vector & );
  void operator >= ( const Vector & );
  void operator <= ( const Vector & );
  void operator *= ( double );
  void operator *= ( int );
  void operator /= ( double );
  void operator %= ( double m[3][3] );
  void operator ^= ( double );

  double& operator [] ( short n );
  //rfm virtual double operator [] ( short n );

  bool Colineal(const Vector &);
  double Dot( const Vector & );
  double Norm(void);
  void SphericalCoordinates(double*,double*,double*);
  void Rotate( const Vector & , double );
  Vector Orthogonal(void);

};

#endif


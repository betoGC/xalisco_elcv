/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: class WinIon functions. 
//
// 2015: Roberto Flores-Moreno
// ******************************************************************

#include <fstream>
#include <iomanip>

#include <WinIon.h>   
#include <Xalisco.h>
#include <System.h>
#include <GaussianGas.h>
#include <Units.h>
#include <Propagator.h>
#include <GW.h>

using namespace std;

WinIon::WinIon(Xalisco* ix)
      : QWidget( 0 )
{
  xalisco = ix;

  QGridLayout *mainLayout = new QGridLayout;

  methodBox = new QComboBox;
  methodBox->addItem(QString("Diagonal PT"));
  methodBox->addItem(QString("GWA"));
  strcpy(method,(methodBox->currentText().toLatin1()).data());
  QLabel* methodlab = new QLabel(tr("Method: "));
  methodlab->setBuddy(methodBox);
  connect(methodBox, SIGNAL(activated(const QString &)),
          this, SLOT(ChangeMethod(const QString &)));

  gas_number = 0;
  QSpinBox *gasS = new QSpinBox( this );
  gasS->setRange( 0 , 100 );
  gasS->setSingleStep( 1 );
  gasS->setValue( gas_number );
  QLabel* gaslab = new QLabel(tr("Particle type: "));
  gaslab->setBuddy(gasS);
  connect( gasS , SIGNAL(valueChanged( int )) , this , SLOT( ChangeGas( int ) ) );

  orbital_number = 0;
  QSpinBox *orbS = new QSpinBox( this );
  orbS->setRange( 0 , 1000 );
  orbS->setSingleStep( 1 );
  orbS->setValue( orbital_number );
  QLabel* orblab = new QLabel(tr("Orbital number: "));
  orblab->setBuddy(orbS);
  connect( orbS , SIGNAL(valueChanged( int )) , this , SLOT( ChangeOrbital( int ) ) );

  order = 0;
  QSpinBox *orderS = new QSpinBox( this );
  orderS->setRange( 0 , 2 );
  orderS->setSingleStep( 1 );
  orderS->setValue( order );
  QLabel* orderlab = new QLabel(tr("Order: "));
  orderlab->setBuddy(orderS);
  connect( orderS , SIGNAL(valueChanged( int )) , this , SLOT( ChangeOrder( int ) ) );

  use_ri = false;
  QCheckBox *ribox = new QCheckBox( this );
  ribox->setText( QString("Use RI-ERIs") ); 
  connect( ribox , SIGNAL( clicked() ) , this , SLOT( SetRI() ) );

  QToolButton *compButton =  new QToolButton( this );
  compButton->setText( "Compute" ); 
  connect(compButton,SIGNAL(clicked()), this,SLOT(Compute()));

  statusbar = new QStatusBar( this );

  mainLayout->addWidget( methodlab ,      1 , 0 , 1 , 1);
  mainLayout->addWidget( methodBox ,      1 , 1 , 1 , 1);
  mainLayout->addWidget( gaslab    ,      2 , 0 , 1 , 1);
  mainLayout->addWidget( gasS      ,      2 , 1 , 1 , 1);
  mainLayout->addWidget( orblab    ,      3 , 0 , 1 , 1);
  mainLayout->addWidget( orbS      ,      3 , 1 , 1 , 1);
  mainLayout->addWidget( orderlab  ,      4 , 0 , 1 , 1);
  mainLayout->addWidget( orderS    ,      4 , 1 , 1 , 1);
  mainLayout->addWidget( ribox     ,      5 , 0 , 1 , 1);
  mainLayout->addWidget( compButton,      5 , 1 , 1 , 1);
  mainLayout->addWidget( statusbar ,      6 , 0 , 1 , 2);

  setLayout( mainLayout );

  setWindowTitle( "Ionization" );

}

void WinIon::ChangeGas(int n)
{
  gas_number = n;
}

void WinIon::ChangeOrbital(int n)
{
  orbital_number = n;
}

void WinIon::ChangeOrder(int n)
{
  order = n;
}


void WinIon::ChangeMethod( const QString &newmethod )
{
  strcpy(method,(newmethod.toLatin1()).data());
}

void WinIon::Compute( )
{
  double ip = -9999.0;

  if (xalisco->sys->ngas<=gas_number)
  {
    Report("Particle type = %d does not exist",gas_number);
    return;
  }

  // Koopmans approximation
  if ( strncmp(method,"Diagonal PT",11) == 0 ) 
  {
    propagator = new Propagator();
    ip = propagator->IonizationEnergy(xalisco->sys,gas_number,orbital_number,order,use_ri);
    delete propagator;
  }
  else if ( strncmp(method,"GWA",3) == 0 ) 
  {
    GW *gwa = new GW(xalisco->sys);
    ip = gwa->IonizationEnergy(gas_number,orbital_number,order,use_ri);
    delete gwa;
  }
   
  Report("Ionization energy = %f hartrees (%f eV)",ip,HartreeToeV(ip));
}

void WinIon::Report( const char *fmt, ... )
{
  va_list args;   
  char    s[256];

  va_start( args , fmt );
  vsprintf(s , fmt , args );
  va_end( args );
 
  if (statusbar) statusbar->showMessage( QString( s ) );
}

void WinIon::SetRI( )
{ 
  if (use_ri) use_ri = false;
  else use_ri = true;
}

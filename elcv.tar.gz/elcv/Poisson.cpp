/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <math.h>
#include <string.h>

#include <iostream>

#include <Poisson.h>
#include <Lebedev.h>
#include <System.h>
#include <Molecular.h>
#include <Atom.h>
#include <Math.h>
#include <Functional.h>
#include <GaussianGas.h>
#include <Evaluator.h>
#include <VFile.h>
#include <Becke.h>
#include <Harmonic.h>

using namespace std;

Poisson::Poisson(System *is)
{
  sys = is;
  harmonic = new Harmonic();
}

void Poisson::Setup(bool response)
{
  int i,iatom,irad,l,m,natom;
  double charge;
  double *density,*rsh,*ulm,*x,*xnorm,*y,*ynorm,*z,*znorm,*wang;
  double **indv;
  Atom *atom;

  lmax = 14;  /// Good for Lebedev with 302 points (L=29)

  RadialQuadratures(); // Setup radial quadrature
  x = new double[nradp];
  y = new double[nradp];
  z = new double[nradp];
  density = new double[nradp];

  file = new VFile((char*)"Poisson.xal", nradp);

  Becke *becke = new Becke();

  natom = sys->mol->Natom();

  int big = (lmax+1)*(lmax+1)*natom;
  adrian = new Matrix(big,nradp);
  ulm = new double[nradp];

  nangp = 302;
  xnorm = new double[nangp];
  ynorm = new double[nangp];
  znorm = new double[nangp];
  wang = new double[nangp];
  ld_by_order(nangp,xnorm,ynorm,znorm,wang);
  for (i=0;i<nangp;i++)
    wang[i] *= 4.0*X_PI;

  rsh = new double[SHP(lmax,lmax)+1];

  for (iatom=0;iatom<natom;iatom++)
  {
    atom = sys->mol->atom[iatom];
    for (l=0;l<=lmax;l++)
    {
      indv = new double*[2*l+1];
      for (m=-l;m<=l;m++)
        indv[l+m] = new double[nradp];
      for (m=-l;m<=l;m++)
        for (irad=0;irad<nradp;irad++)
          indv[l+m][irad] = 0.0;
      for (i=0;i<nangp;i++)
      {
        double pr,theta,phi;
        Vector p;
        p = Vector(xnorm[i],ynorm[i],znorm[i]);
        p.SphericalCoordinates(&pr,&theta,&phi);
        harmonic->RealSphericalHarmonics(l,theta,phi,rsh);
        for (m=-l;m<=l;m++)
          rsh[SHP(l,m)] *= wang[i];
        for (irad=0;irad<nradp;irad++)
        {
          x[irad] = xnorm[i]*r[irad] + atom->x;
          y[irad] = ynorm[i]*r[irad] + atom->y;
          z[irad] = znorm[i]*r[irad] + atom->z;
        }

        // ESP or Fukui ESP (in response variable)
        GetChargeDensity(sys,x,y,z,density,nradp,response);

        becke->Weigths(sys->mol,iatom,x,y,z,density,nradp);
        for (m=-l;m<=l;m++)
          for (irad=0;irad<nradp;irad++)
            indv[l+m][irad] += rsh[SHP(l,m)]*density[irad];
      }
      charge = 0.0;
      for (m=-l;m<=l;m++)
      {
        for (irad=0;irad<nradp;irad++)
        {
          // RHO_00 can be used to obtain angular integral of RHO
          if (l==0)
            charge += indv[l+m][irad]*wr[irad]*r[irad]*r[irad]*sqrt(4.0*X_PI); 
          indv[l+m][irad] *= -4.0*X_PI*r[irad]*step*step;  // From Poisson eq
        }
      }
      if (l==0) indv[0][nradp-1] -= sqrt(4.0*X_PI)*charge;
      for (m=-l;m<=l;m++)
      {
        ApplyInvertedTridiagonal(l,indv[l+m],ulm);
        // Save to disk
        Write(iatom,l,m,ulm);
      }
      for (m=-l;m<=l;m++)
        delete[] indv[l+m];
      delete[] indv;
    }
  }

  delete[] rsh;
  delete[] xnorm;
  delete[] ynorm;
  delete[] znorm;
  delete[] wang;
  delete[] x;
  delete[] y;
  delete[] z;
  delete[] density;
  delete[] ulm;
  delete becke;
}

// Radial quadrature
// Transformed Gauss-Chebyshev quadratures
void Poisson::RadialQuadratures()
{
  int i;
  double prev;

  step = 0.025;  
  nradp = int(20.0/step);
  r.clear();
  wr.clear();
  prev = step;
  r.push_back( prev );
  wr.push_back( step );
  for (i=1;i<nradp;i++)
  {
    prev += step;
    r.push_back( prev );
    wr.push_back( step );
  } 

}

void Poisson::ApplyInvertedTridiagonal(int lwork,double *rhov, double *potential)
{
/*----------------------------------------------------------------------------------
 List of variables
 step          Discrete points "size"
 nradp         Number of radial discrete points
 div	       Gauss-Jordan divider/multiplier placeholder
 ----------------------------------------------------------------------------------
 List of arrays
 rhov          Vector that contains densities
 tridiag       Matrix that contains numerical second order derivative operator
 unity	       Unity matrix that will become the inversed tridiagonal matrix
 potential     Vector that contains electrostatic potential
 ----------------------------------------------------------------------------------*/

  // Declaration of variables 
  double div;
  int i, j, k, jj;
  double **tridiag, **unity;

  // Declaration and allocation of 2D arrays
  tridiag = new double*[nradp]; // Rows
  for (j = 0; j < nradp; j++)   // Columns
    tridiag[j] = new double[nradp];
  unity = new double*[nradp];  // Rows
  for (j = 0; j < nradp; j++) // Columns
    unity[j] = new double[nradp];

  // Generate tridiagonal matrix
  for (i = 0; i < nradp; i++)
    for (j = 0; j < nradp; j++)
    {
      k = i - j;
      if (k == 0)
        tridiag[i][j] = -2.0 - 
          double(lwork*(lwork+1))*step*step/(r[i]*r[i]); 
      else if (k == 1 || k == -1)
        tridiag[i][j] = 1.0;
      else
         tridiag[i][j] = 0.0;
     }

  // Generate unity matrix
  for (i = 0; i < nradp; i++)
    for (j = 0; j < nradp; j++)
    {
      k = i-j;
      if (k == 0)
        unity[i][j] = 1.0;
      else
        unity[i][j] = 0.0;
     }

  // Tridiagonal matrix invertion
  //   Solve upper triangular
  //     Generate pivot
  for (i = 0; i < nradp; i++)
  {
    div = tridiag[i][i];
    for (j = 0; j <= i; j++)
      unity[i][j] /= div;
    for (j = 0; j <= min(i+1, nradp-1); j++)
      tridiag[i][j] /= div;
  // Rest lines
    if (i < nradp-1)
    {
      for (j = 0; j <= i ; j++)
        unity[i+1][j] -= unity[i][j];
      for (j = i; j <= i+1; j++)
        tridiag[i+1][j] -= tridiag[i][j];
    }
  }

  // Solve lower triangular
  for (i = nradp-1; i >= 0; i--)
    if ( i > 0)
    {
      jj = i;
      div = tridiag[i-1][jj];
      for (j = nradp-1; j >= 0; j--)
    {
      tridiag[i-1][j] -= tridiag[i][j]*div;
      unity[i-1][j] -= unity[i][j]*div;
    }
   }

  for (j = 0; j < nradp; j++)
    delete[] tridiag[j];
  delete[] tridiag;

  // Multiply inversed unity matrix times independent vector rhov
  for (i = 0; i < nradp; i++)
  {
    potential[i] = 0.0;
    for (j = 0; j < nradp; j++)
      potential[i] += unity[i][j]*rhov[j];
  }

  for (j = 0; j < nradp; j++) // Columns
    delete[] unity[j];
  delete[] unity;
}

// Electrostatic potential
void Poisson::GetElectrostaticPotential(double* x, double *y, double *z, double *v, int n)
{
  int aptr,bptr,i,iatom,irad,l,m,natom;
  double a,b,norm,ulmr,xnorm,ynorm,znorm;
  double ra[3];
  double *rsh,*ulm;
  Atom *atom;
  
  natom = sys->mol->Natom();

  for (i=0;i<n;i++)
  {
    v[i] = 0.0;
    // Contribution from classical point charges
    for (iatom=0;iatom<natom;iatom++)
    {
      atom = sys->mol->atom[iatom];
      if (atom->charge>0.0)
      {
        ra[0] = x[i] - atom->x;
        ra[1] = y[i] - atom->y;
        ra[2] = z[i] - atom->z;
        norm = sqrt(ra[0]*ra[0]+ra[1]*ra[1]+ra[2]*ra[2]);
        if (norm<0.01) norm=0.01;  // Avoid plotting at nuclear positions
        v[i] += atom->charge/norm; 
      }
    }
  }
  
  ulm = new double[nradp];

  for (iatom=0;iatom<natom;iatom++)
  {
    atom = sys->mol->atom[iatom];
    for (i=0;i<n;i++)
    { 
      ra[0] = x[i] - atom->x;
      ra[1] = y[i] - atom->y;
      ra[2] = z[i] - atom->z;
      norm = sqrt(ra[0]*ra[0] + ra[1]*ra[1] + ra[2]*ra[2]);
      if (norm<X_TOL_NUM)
      {
        xnorm = 0.0;
        ynorm = 0.0;
        znorm = 0.0;
      }
      else
      {
        xnorm = ra[0]/norm;
        ynorm = ra[1]/norm;
        znorm = ra[2]/norm;
      }
      aptr = nradp-1;
      bptr = nradp-1;
      for (irad=0;irad<nradp;irad++)
      {
        if (norm<r[irad]) 
        {
          if (irad==0)
          {
            aptr = irad;
            bptr = irad;
          }
          else
          {
            aptr = irad-1;
            bptr = irad;
          }
          break;
        } 
      }
      double pr,theta,phi;
      Vector *p;
      p = new Vector(xnorm,ynorm,znorm);
      p->SphericalCoordinates(&pr,&theta,&phi);
      rsh = new double[SHP(lmax,lmax)+1];
      harmonic->RealSphericalHarmonics(lmax,theta,phi,rsh);
      for (l=0;l<=lmax;l++)
      {
        for (m=-l;m<=l;m++)
        {
          Read(iatom,l,m,ulm);
          if (aptr==bptr)
          {
            ulmr = ulm[aptr];
          }
          else
          {
            a = norm - r[aptr];
            b = r[bptr] - norm;
            ulmr = (b*ulm[aptr] + a*ulm[bptr])/(a+b);
          }
          v[i] += ulmr*rsh[SHP(l,m)]/norm;
        }
      }
      delete[] rsh;
    }
  }
  delete[] ulm;
}

void Poisson::Write(int iatom,int l,int m,double *ulm)
{
  int i,n;
  n = (lmax+1)*(lmax+1)*iatom + l*l + l + m;
  file->Write(ulm,n);
  // Print out computed potential 
  
  for (i=0;i<nradp;i++)
    adrian->SetValue( n, i, ulm[i] );
}

void Poisson::Read(int iatom,int l,int m,double *ulm)
{
  int i,n;
  n = (lmax+1)*(lmax+1)*iatom + l*l + l + m;
  //NO la arma file->Read(ulm,n);
  for (i=0;i<nradp;i++)
    ulm[i] = (*adrian)(n, i);
}


/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: SCF Window object
//
// 2003-2015: Roberto Flores-Moreno
// ******************************************************************

#include <iostream>

#include <QtWidgets>

#include <WinSCF.h>   
#include <QChem.h>   
#include <SCF.h>   
#include <Xalisco.h>
#include <Panel.h>
#include <Viewer.h>
#include <WinPlot.h>
#include <System.h>
#include <CurvePlotter.h>
#include <Math.h>
#include <GaussianGas.h>
#include <Molecular.h>
#include <ADFT.h>
#include <Time.h>
#include <Gradient.h>

using namespace std;

WinSCF::WinSCF( Xalisco *ix , QChem *iqchem)
      : QWidget( 0 )
{
  xalisco = ix;
  qchem = iqchem;
  timer = new QTimer(this);

  setWindowTitle( "SCF" );
  tabWidget = new QTabWidget;

  stepButton =  new QToolButton( this );  
  stepButton->setText( "Step" );
  connect( stepButton,SIGNAL(clicked()),this,SLOT(Step()));

  convButton =  new QToolButton( this );  
  convButton->setText( "Converge" );
  connect( convButton,SIGNAL(clicked()),this,SLOT(Converge()));

  QGridLayout *mainLayout = new QGridLayout;

  QToolButton *startButton =  new QToolButton( this );
  startButton->setText( "Start" ); 
  connect(startButton,SIGNAL(clicked()), this,SLOT(Start())); 

  QToolButton *stopButton =  new QToolButton( this );
  stopButton->setText( "Stop" ); 
  connect(stopButton,SIGNAL(clicked()), this,SLOT(Stop())); 

  QDoubleSpinBox *mixS = new QDoubleSpinBox( this );
  mixS->setRange( 0.01 , 1.0 );
  mixS->setSingleStep( 0.01 );
  mixS->setDecimals( 2 );
  mixS->setValue( 0.3 );
  QLabel* mixlab = new QLabel(tr("Damping:"));
  mixlab->setBuddy(mixS);
  ChangeMixing( 0.3 );
  connect( mixS , SIGNAL(valueChanged( double )) ,
           this , SLOT( ChangeMixing( double ) ) );

  graphical = false;
  gbox = new QCheckBox( this );
  gbox->setText( QString("Graphical SCF") ); 
  connect( gbox , SIGNAL( clicked() ) , this , SLOT( SetGraphical() ) );

  frame = new QWidget( 0 );
  tabWidget->addTab( frame , tr("SCF Energy") );

  SCFPlotter = new CurvePlotter( this );
  SCFPlotter->resize( 200 , 200 ); 

  QComboBox* cnstBox = new QComboBox;
  cnstBox->addItem(QString("ELECTRON"));
  cnstBox->addItem(QString("PROTON"));
  cnstBox->addItem(QString("SOLVENT"));
  QLabel* cnstlab = new QLabel(tr("Constrain type:"));
  cnstlab->setBuddy(cnstBox);
  connect(cnstBox, SIGNAL(activated(const QString &)),
          this, SLOT(ChangeConstrainType(const QString &)));

  QDoubleSpinBox *cnsS = new QDoubleSpinBox( this );
  cnsS->setRange( 0.0 , 110.0 );
  cnsS->setSingleStep( 1.0 );
  cnsS->setDecimals( 1 );
  cnsS->setValue( 0.0 );
  QLabel* cnslab = new QLabel(tr("number:"));
  cnslab->setBuddy(cnsS);
  connect( cnsS , SIGNAL(valueChanged( double )) ,
           this , SLOT( ChangeConstrainCharge( double ) ) );

  QSpinBox *cnslS = new QSpinBox( this );
  cnslS->setRange( -1 , 10000 );
  cnslS->setSingleStep( 1 );
  cnslS->setValue( -1 );
  QLabel* cnsllab = new QLabel(tr("last atom:"));
  cnsllab->setBuddy(cnslS);
  connect( cnslS , SIGNAL(valueChanged( int )) ,
           this , SLOT( ChangeConstrainLastAtom( int ) ) );

  mainLayout->addWidget( tabWidget         , 1 , 0 , 5, 5 );
  mainLayout->addWidget( convButton        , 6 , 0 , 1, 1 );
  mainLayout->addWidget( stepButton        , 6 , 1 , 1, 1 );
  mainLayout->addWidget( startButton       , 6 , 2 , 1, 1 );
  mainLayout->addWidget( stopButton        , 6 , 3 , 1, 1 );
  mainLayout->addWidget( gbox              , 6 , 4 , 1, 1 );
  mainLayout->addWidget( mixlab            , 7 , 0 , 1, 1 );
  mainLayout->addWidget( mixS              , 7 , 1 , 1, 1 );
  mainLayout->addWidget( cnstlab           , 8 , 0 , 1, 1 );
  mainLayout->addWidget( cnstBox           , 8 , 1 , 1, 1 );
  mainLayout->addWidget( cnslab            , 8 , 2 , 1, 1 );
  mainLayout->addWidget( cnsS              , 8 , 3 , 1, 1 );
  mainLayout->addWidget( cnsllab           , 8 , 4 , 1, 1 );
  mainLayout->addWidget( cnslS             , 8 , 5 , 1, 1 );
  mainLayout->addWidget( SCFPlotter        , 9 , 0 , 6, 6 );
  setLayout( mainLayout );

  SCFListBox = new QListWidget;
  layout = new QVBoxLayout;
  layout->addWidget( SCFListBox );
  frame->setLayout( layout );
}

void WinSCF::Setup()
{
  energies.clear(); 
  SCFListBox->clear();
}

void WinSCF::Step()
{
  Time time = Time();
  time.Start();

  qchem->scf->Step();

  energies.push_back( qchem->sys->energy );
  int ncycle = energies.size();

  int i;
  char str[X_MAX_STR_SIZE];
  i = ncycle - 1;
  sprintf( str,"%d: energy = %20.8f , error = %20.8f, cscflm = %20.8f\n", 
      i, energies[i], qchem->scf->Error(),qchem->scf->constrain_lambda);
  SCFListBox->insertItem( 0, QString(str) );

  int ll;
  if (ncycle>20) ll = ncycle - 20;
  else ll = 0;
  double *cval;
  cval = new double[20];
  for (i=ll;i<ncycle;i++)
    cval[i-ll] = double(i);
  double *eval;
  eval = new double[20];
  for (i=ll;i<ncycle;i++)
    eval[i-ll] = energies[i];
  SCFPlotter->SetData( cval , eval ,  ncycle-ll );
  delete[] cval;
  delete[] eval;
  if (graphical) 
  {
    xalisco->panel->winplot->SetupPlot();
    xalisco->panel->winplot->BuildPlot();
  }
  xalisco->panel->viewer->Redraw();
  timer->start(40);

  cout << "SCF step has taken "<<time.Seconds()<<" seconds"<<endl;

/*
  if (qchem->scf->Converged()) 
  {
    cout << "SCF antes"<<endl;
    Gradient g(qchem);
    g.Evaluate();
    cout << "Evaluado"<<endl;
    g.Test();
    cout << "SCF despues"<<endl;
  }
*/
}

void WinSCF::Start()
{
  connect(timer,SIGNAL(timeout()),this,SLOT(Step()));
  Step();
}

void WinSCF::Stop()
{
  disconnect(timer,SIGNAL(timeout()), this,SLOT(Step()));
}

void WinSCF::SetGraphical( )
{ 
  if (graphical) graphical = false;
  else graphical = true;
}

void WinSCF::Converge()
{
  qchem->scf->SeekConvergence();
  Step();
}

void WinSCF::ChangeConstrainType(const QString &s)
{
  int type;

  if (s=="ELECTRON") type = ELECTRON;
  else if (s=="PROTON") type = PROTON;
  else if (s=="SOLVENT") type = SOLVENT;
  for (int ig=0;ig<qchem->sys->ngas;ig++)
  qchem->scf->SetupConstrain();
}

void WinSCF::ChangeConstrainCharge(double number)
{
  qchem->scf->constrain_number = number;
  qchem->scf->SetupConstrain();
}

void WinSCF::ChangeConstrainLastAtom(int last_atom)
{
  qchem->scf->constrain_last_atom = last_atom;
  qchem->scf->SetupConstrain();
}

void WinSCF::ChangeMixing(double newmix)
{
  qchem->scf->mixing = newmix;
}


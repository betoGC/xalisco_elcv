/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#ifndef X_SCF_H
#define X_SCF_H

#include <Parameter.h>

class QChem;
class System;
class Matrix;

class SCF 
{
  public:
    SCF(QChem*);

    QChem *qchem;
    System *sys;
    bool atomic;
    bool projected[NTYPES];
    double mixing;
    int constrain_last_atom;
    int constrain_particle_type;
    double constrain_number;
    double constrain_lambda;
    Matrix* constrain_matrix;

    void SetTolerance(double);
    void Setup(void);
    void SetupConstrain(void);
    void ApplyConstrain(void);
    void NewDensity(void);
    void Step(void);
    void SeekConvergence(void);
    bool Converged(void);
    double Error(void);

  protected:

    int cycle;
    double energy;
    double error;
    double tolerance;

    void Constrain(void);
};

#endif // X_SCF_H

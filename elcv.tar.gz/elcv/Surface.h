/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Surface class.
//
// 2015: Roberto Flores-Moreno
// ******************************************************************

#ifndef X_SURFACE_H
#define X_SURFACE_H

#include <vector>

using namespace std;

class System;
class Grid;
class GaussianSet;
class Matrix;
class Poisson;

class Surface 
{
  public:
    Surface(System*,Grid*);

    System* sys;
    Grid* grid;

    char name[256];
    int type;
    int style;
    int shiny;
    int set_number;
    int orbital_number;
    int point_size;
    int line_width;
    int nscalar;
    double iso;
    double color[4];
    unsigned long list;
    double* scalar;

    void Setup(void);
    void Build(void);
    void GetCubeValues(int,int,int,double*);
    void GetDerivatives(double*,double*,double*,double*,double*,double*,int);
    void GetValues(double*,double*,double*,double*,int);
    void GetExtrema(double*,double*);

  protected:

    Poisson *poisson;
    void BuildChargeDensity(bool);
    void BuildRDG(bool);
    void BuildDensityLike(Matrix*,vector<GaussianSet*>);
    void BuildElectronicSpinDensity(void);
    void BuildFrontierFukui(void);
    void BuildGTO(void);
    void BuildOrbital(void);
    void BuildParticleDensity(bool);
    void BuildShannon(void);
    void BuildShape(void);
    void BuildElectrostaticPotential(void);
};

#endif  // SURFACE_H

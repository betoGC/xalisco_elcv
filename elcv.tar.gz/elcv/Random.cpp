/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Definition of Random
//
// 2015: Roberto Flores Moreno
// ******************************************************************

#include <stdlib.h>
#include <string.h>

#include <iostream>

#include <Parameter.h>
#include <Math.h>
#include <Random.h>

using namespace std;

Random::Random(void)
{
};

int Random::Integer(int imin, int imax)
{
  if (imax<=imin)
    return imin;
  else
    return (imin + (rand() % (imax - imin + 1)));
};

double Random::Real(double rmin, double rmax)
{
  if (rmax<=rmin)
    return rmin;
  else
    return (rmin + (rand() / (double(RAND_MAX)))*(rmax-rmin));
};

int Random::Select(double* r,int n)
{
  int i;
  double s = 0.0; 
  for (i=0;i<n;i++)
  {
    s += X_ABS(r[i]);
  }
  if (s==0.0) return -1;
  for (i=0;i<n;i++)
    r[i] /= s;

  double rn = Real(0.0,1.0);
  s = 0.0;
  for (i=0;i<n;i++)
  {
    s += r[i];
    if (rn<=s) return i;
  };
  return -1;
}

/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <iostream>

#include <QtWidgets>

#include <Parameter.h>   
#include <WinSpec.h>   
#include <Xalisco.h>
#include <Chemistry.h>
#include <Species.h>
#include <Math.h>

using namespace std;

WinSpec::WinSpec( Xalisco *ix, Chemistry *ichem)
      : QWidget( 0 )
{
  xalisco = ix;
  chem = ichem;

  timer = new QTimer(this);

  setWindowTitle( "Species" );
  tabWidget = new QTabWidget;

  QGridLayout *mainLayout = new QGridLayout;

  QToolButton *addButton =  new QToolButton( this );
  addButton->setText( "Add Species" ); 
  connect(addButton,SIGNAL(clicked()), this,SLOT(AddSpecies())); 

  frame = new QWidget( 0 );
  tabWidget->addTab( frame , tr("Species") );

  mainLayout->addWidget( addButton       , 1 , 1 , 1, 1 );
  mainLayout->addWidget( tabWidget       , 2 , 0 , 6, 4 );
  setLayout( mainLayout );

  ListBox = new QTableWidget(X_MAX_N_SPECIES,4);
  connect( ListBox , SIGNAL( itemChanged(QTableWidgetItem*) ), 
           this , SLOT( Edited( QTableWidgetItem*) ));
  QStringList Headers;
  Headers << "Id" 
          << "Formula" 
          << "Concentration"
          << "Diff. Coef.";
  ListBox->setHorizontalHeaderLabels(Headers);

  layout = new QVBoxLayout;
  layout->addWidget( ListBox );
  frame->setLayout( layout );

  strcpy(name,"electron");
  concentration = 0.00;
  difcoef = 0.0;     // cm^2 s^-1
  AddSpecies();
  strcpy(name,"A");
  concentration = 7.8e-7;
  difcoef = 9.35e-7;     // cm^2 s^-1
  AddSpecies();
  strcpy(name,"B");
  concentration = 1.22e-6;
  difcoef = 9.35e-7;     // cm^2 s^-1
  AddSpecies();
  strcpy(name,"C");
  concentration = 0.0;
  difcoef = 9.35e-7;     // cm^2 s^-1
  AddSpecies();
  strcpy(name,"D");
  concentration = 0.0;
  difcoef = 9.35e-7;     // cm^2 s^-1
  AddSpecies();
  strcpy(name,"E");
  concentration = 0.0;
  difcoef = 9.35e-7;     // cm^2 s^-1
  AddSpecies();
  strcpy(name,"H");
  concentration = 1.0e-8;
  difcoef = 9.312e-5;     // cm^2 s^-1
  AddSpecies();
}

void WinSpec::AddSpecies()
{
  int nspec = chem->NumberOfSpecies();

  char str[X_MAX_STR_SIZE];
  sprintf(str,"%d",nspec);
  ListBox->setItem(nspec,0, new QTableWidgetItem( QString(str) ));

  chem->AddSpecies(name,concentration,difcoef);

  ListBox->setItem(nspec,1, new QTableWidgetItem( 
    QString(chem->specie[nspec]->Name() ) ));

  sprintf(str,"%.15f",chem->specie[nspec]->Concentration() );
  ListBox->setItem(nspec,2, new QTableWidgetItem( QString(str) ));

  sprintf(str,"%.15f",chem->specie[nspec]->DiffusionCoefficient() );
  ListBox->setItem(nspec,3, new QTableWidgetItem( QString(str) ));
}

void WinSpec::Edited( QTableWidgetItem* item ) 
{
  int row = ListBox->currentRow();
  int col = ListBox->currentColumn();

  if (row>=chem->NumberOfSpecies()) 
  {
    item->setText( QString( " " ) );
    return;
  }

  if ( col == 0 )
  {
    char str[X_MAX_STR_SIZE];
    sprintf(str,"%d",row);
    item->setText( QString( str ) );
  }
  else if ( col == 1 )
  {
    chem->specie[row]->SetName( (item->text().toLatin1()).data() );
  }
  else if ( col == 2 )
  {
    chem->specie[row]->SetConcentration( item->text().toDouble() );
  }
  else if ( col == 3 )
  {
    chem->specie[row]->SetDiffusionCoefficient( item->text().toDouble() );
  }
}

// Reading from files is mediated by windows
// (File substitutes user, not window)
void WinSpec::Read(char* filename)
{
  size_t i,ns;
  char line[X_MAX_STR_SIZE];

  chem->specie.clear();

  ifstream f(filename);
  while (f.getline(line,X_MAX_STR_SIZE))
  {
    string stringLine=line;
    int sindex=stringLine.find("Number of species:");
    if((sindex>=0)&&(sindex<(signed)stringLine.size()))
    { 
      ns = atoi(&line[18]);
      for (i=0;i<ns;i++)
      {
        f >> name;
        f >> concentration;
        f >> difcoef;
        AddSpecies();
      }
      break;
    }
  }

  f.close();
}


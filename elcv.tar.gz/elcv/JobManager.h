/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: Declaration of class JobManager
//
// 2016: Roberto Flores-Moreno
// ******************************************************************
#ifndef X_JOBMANAGER_H
#define X_JOBMANAGER_H

#include <Parameter.h>

class System;
class QChem;

class JobManager 
{
  public:

    JobManager(System*,char*);

    System *sys;
    QChem *qchem;
    char input_file[X_MAX_STR_SIZE];
    char output_file[X_MAX_STR_SIZE];

    void Load( void );
    void Run( void );
    int TypeWordToNumber( char* );
    char* TypeNumberToWord( int );

};

#endif // X_JOBMANAGER_H


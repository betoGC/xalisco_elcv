/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// ******************************************************************
// Purpose: class WinQChem functions. 
//
// 2012: Roberto Flores-Moreno
// ******************************************************************

#include <fstream>
#include <iomanip>

#include <WinQChem.h>   
#include <QChem.h>   
#include <Xalisco.h>   
#include <Panel.h>   
#include <GeometryEditor.h>   
#include <System.h>   
#include <Molecular.h>
#include <WinSCF.h>
#include <WinIon.h>
#include <WinProp.h>
#include <WinPType.h>

using namespace std;

WinQChem::WinQChem(Xalisco* ix,System* isys)
      : QWidget( 0 )
{
  xalisco = ix;
  sys = isys;

  QGridLayout *mainLayout = new QGridLayout;

  setButton =  new QToolButton( this );  
  setButton->setText( "Setup" );
  connect( setButton,SIGNAL(clicked()),this,SLOT(Setup()));

  tabPType = new QTabWidget;
  tabWidget = new QTabWidget;

  mainLayout->addWidget( tabPType     ,      1 , 0 , 1 , 4);
  mainLayout->addWidget( setButton    ,      5 , 1 , 1 , 1);
  mainLayout->addWidget( tabWidget    ,      6 , 0 , 1 , 4);

  setLayout( mainLayout );

  qchem = new QChem(sys);

  tabPType->clear();
  wine = new WinPType(qchem,ELECTRON);
  tabPType->addTab( wine , QString("ELECTRON") );
  winh = new WinPType(qchem,PROTON);
  tabPType->addTab( winh , QString("PROTON") );
  wins = new WinPType(qchem,SOLVENT);
  tabPType->addTab( wins , QString("SOLVENT") );

  tabWidget->clear();
  winscf = new WinSCF( xalisco , qchem );
  tabWidget->addTab( winscf , QString("SCF") );
  winion = new WinIon( xalisco );
  tabWidget->addTab( winion , QString("Ionization") );
  winprop = new WinProp( xalisco , qchem );
  tabWidget->addTab( winprop , QString("Properties") );

  setWindowTitle( "Run calculation" );
  hide();
}

void WinQChem::Setup()
{
  qchem->Setup();
  winscf->Setup();
}


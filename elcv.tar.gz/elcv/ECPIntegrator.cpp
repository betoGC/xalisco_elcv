/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <stdlib.h>

#include <iostream>

#include <ECPIntegrator.h>
#include <GaussianGas.h>
#include <GaussianSet.h>
#include <GaussianShell.h>
#include <Harmonic.h>
#include <Bessel.h>
#include <Becke.h>
#include <Math.h>

using namespace std;

ECPIntegrator::ECPIntegrator(GaussianGas* igas)
             : CFPIntegrator(igas)
{
  gas = igas;
}

// Calculation of semi-local ECP integrals.
// History: - Creation (25.10.05, RFM)
//          - Translated to C (23.07.15, RFM)
void ECPIntegrator::BuildMatrix(Matrix *H)
{
  // If there is no pseudopotential return fastly
  if (gas->pps.size()<=0) return;

  // Build local part
  //rfm EvaluateMatrix(H);

  int i,ib,is,lamax,lac,lla,llis;
  int j,jb,js,lbmax,lbc,llb,lljs;
  int kb,l,lcmax;
  int dao,daop,dsph,dppshl,lbasmax,lmax;
  double **intblk,**vlm;
  Vector ra,rb,rc,rac,rbc;
  GaussianShell *sa,*sb;

  lbasmax = gas->LMax(gas->basis);
  lcmax = 0;
  for (kb=0;kb<(signed)gas->pps.size();kb++)
    lcmax = X_MAX(lcmax,gas->pps[kb]->LMax()-1);
  lmax = lbasmax + lcmax;

  dao = ((lbasmax+1)*(lbasmax+2))/2;

  // Precompute angular integrals 
  Angular(0);

  intblk = new double*[dao];
  for (i=0;i<dao;i++)
    intblk[i] = new double[dao];

  vlm = new double*[lcmax+1];
  for (i=0;i<=lcmax;i++)
    vlm[i] = new double[ngp];

  rint.clear();
  for (i=0;i<=2*lbasmax;i++)
  {
    rint.push_back( Matrix(lmax+1,lmax+1) );
    rint[i].SetZero();
  }

  daop = PSDAOPointer(2*lbasmax);
  dsph = SHP( lcmax , lcmax ) + 1;
  slaa.clear();
  slab.clear();
  for (i=0;i<daop;i++)
  {
    slaa.push_back( Matrix( lmax + 1, dsph ) );
    slab.push_back( Matrix( lmax + 1, dsph ) );
    slaa[i].SetZero();
    slab[i].SetZero();
  }

  // Loop over the potential centers
  for (kb=0;kb<(signed)gas->pps.size();kb++)
  {
    current_potential = kb;
    lcmax = gas->pps[kb]->LMax() - 1;
    rc = Vector(gas->pps[kb]->x,gas->pps[kb]->y,gas->pps[kb]->z);
    TabulateRadialPotential(vlm);
    TabulateBasis(0,false);
    // Loop on primary basis shells
    llis = 0;
    for (ib=0;ib<(signed)gas->basis.size();ib++)
    {
      lamax = gas->basis[ib]->LMax();
      ra = Vector(gas->basis[ib]->x,gas->basis[ib]->y,gas->basis[ib]->z);
      rac = ra - rc;
      GeometryDependent(lamax,lcmax,rac,powa,slaa);
      dca = rac.Norm();
      lljs = 0;
      for (jb=0;jb<(signed)gas->basis.size();jb++)
      {
        lbmax = gas->basis[jb]->LMax();
        rb = Vector(gas->basis[jb]->x,gas->basis[jb]->y,gas->basis[jb]->z);
        rbc = rb - rc;
        GeometryDependent(lbmax,lcmax,rbc,powb,slab);
        dcb = rbc.Norm();
        for (is=0;is<(signed)gas->basis[ib]->shell.size();is++)
        {
          sa = gas->basis[ib]->shell[is];
          lla = gas->basis[ib]->ll+sa->ll;
          for (js=0;js<(signed)gas->basis[jb]->shell.size();js++)
          {
            sb = gas->basis[jb]->shell[js];
            llb = gas->basis[jb]->ll+sb->ll;
            if ((jb>ib)||((jb==ib)&&(js>=is))) 
            {
              Block(sa,sb,bastab[llis+is],bastab[lljs+js],vlm,intblk,0,0);
              for (i=0;i<sa->nco;i++)
                for (j=0;j<sb->nco;j++)
                  H->ShiftValue(lla+i,llb+j,intblk[i][j]);
            }
          }
        }
        lljs += gas->basis[jb]->shell.size();
      }
      llis += gas->basis[ib]->shell.size();
    }
  }
  for (i=0;i<dao;i++)
    delete[] intblk[i];
  delete[] intblk;

  for (i=0;i<=lcmax;i++)
    delete[] vlm[i];
  delete[] vlm;

  rint.clear();
  slaa.clear();
  slab.clear();
  bastab.clear();

  H->Symmetrize();
}

// ECP semi-local angular integrals.
// < S(LA,MA) | S(LB,MB) | x^i y^j z^k >  
// History: - Creation (25.10.05, RFM)
//          - Translation to C (23.07.15, RFM)
void ECPIntegrator::Angular(int l)
{
  int dang,la,lb,lbasmax,lecpmax,lmax,lp,ma,mb,parity,px,py,pz;

  lbasmax = gas->LMax(gas->basis) + l;
  lecpmax = gas->LMax(gas->pps) - 1;
  lmax = lbasmax + lecpmax;

  dang = SHP(lmax,lmax) + 1;

  angint.clear();
  for (lp=0;lp<=lbasmax;lp++)
    for (px=0;px<=lp;px++)
      for (py=0;py<=lp-px;py++)
      {
        pz = lp - px - py;
        angint.push_back( Matrix( dang, dang ) );
      } 

  for (la=0;la<=lmax;la++)
  {
    for (lb=0;lb<=lmax;lb++)
    {
      // ALERT: Notice that only selected parity is computed
      parity = X_MAX(X_MOD(la+lb,2),la-lb);
      for (lp=parity;lp<=lbasmax;lp +=2)
      {
        for (ma=-la;ma<=la;ma++)
        {
          for (mb=-lb;mb<=lb;mb++)
          {
            for (px=0;px<=lp;px++)
            {
              for (py=0;py<=lp-px;py++)
              {
                pz = lp - px - py;
                angint[gaop[px][py][pz]].SetValue(SHP(la,ma),SHP(lb,mb),
                harmonic->SSXYZ(la,ma,lb,mb,px,py,pz) );
              }
            }
          }
        }
      }
    }
  }
}

// Evaluate factors which depend only on the geometry.
void ECPIntegrator::GeometryDependent(int la,int lc,Vector a,
double *pow,vector<Matrix> slap) 
{
  int daop,i,ipol,isph,l,lmax,m,nsph,nsphc;
  double r,s,theta,phi;
  double *rsph;

  daop = PSDAOPointer(la);
  lmax = lc + la;
  nsph = SHP(lmax,lmax) + 1;
  nsphc = SHP(lc,lc) + 1;

  rsph = new double[nsph];

  // Spherical coordinates
  a.SphericalCoordinates(&r,&theta,&phi);

  // Polynomial prefactors 
  Monomial(la,a,pow);

  // Evaluate normalized real spherical harmonics 
  harmonic->RealSphericalHarmonics(lmax,theta,phi,rsph);

  // Build angular blocks 
  for (ipol=0;ipol<daop;ipol++)
  {
    for (isph=0;isph<nsphc;isph++)
    {
      for (l=0;l<=lmax;l++)
      {
        s = 0.0;
        for (m=(-l);m<=l;m++)
          s += rsph[SHP(l,m)]*angint[ipol](SHP(l,m),isph);     
        slap[ipol](l,isph) = s;
      }
    }
  }

  delete[] rsph;
}

// Pre-tabulation of effective core potential functions for 
// the numerical integration of the radial ECP integrals.
// History: - Creation (03.11.05, RFM)
//          - Translated to C (23.07.15, RFM)
void ECPIntegrator::TabulateRadialPotential(double **Vlm)
{
  int igp,lc,lmax,ngpashl;

  lmax = gas->pps[current_potential]->LMax() - 1;
  for (lc=0;lc<=lmax;lc++)
    for (igp=0;igp<ngp;igp++)
      Vlm[lc][igp] = SemilocalPotential(cfpr[igp],lc);

  ngpa = 0;
  for (lc=0;lc<=lmax;lc++)
  {
    ngpashl = 0;
    for (igp=ngp-1;igp>=0;igp--)
    {
      if (X_ABS(Vlm[lc][igp])>X_TOL_NUM)
      {
        ngpashl = igp + 1;
        break;
      }
    }
    ngpa = X_MAX(ngpa,ngpashl);
  }

  for (lc=0;lc<=lmax;lc++)
    for (igp=0;igp<ngp;igp++)
      Vlm[lc][igp] *= cfpw[igp];
}

// Pre-tabulation of basis functions for the numerical
// integration of the radial ECP integrals.
// History: - Creation (03.12.03, RFM)
//          - Translated to C (23.07.15, RFM)
void ECPIntegrator::TabulateBasis(int n, bool scaled)
{
  int i,ib,igp,is,l,lbasmax,lcmax,lmax,llis;
  double expo,factor,local_dca,x,y,z,wz;
  double *besselK;
  GaussianShell *sa;

  lbasmax = gas->LMax(gas->basis);
  lcmax = gas->pps[current_potential]->LMax()- 1;
  besselK = new double[lbasmax + n + lcmax + 1];

  llis = 0;
  bastab.clear();
  for (ib=0;ib<(signed)gas->basis.size();ib++)
  {
    x = gas->pps[current_potential]->x - gas->basis[ib]->x;
    y = gas->pps[current_potential]->y - gas->basis[ib]->y;
    z = gas->pps[current_potential]->z - gas->basis[ib]->z;
    local_dca = sqrt(x*x+y*y+z*z);
    for (is=0;is<(signed)gas->basis[ib]->shell.size();is++)
    {
      sa = gas->basis[ib]->shell[is];
      lmax = sa->l + n + lcmax;
      bastab.push_back( Matrix(lmax+1,ngpa) );
      bastab[llis+is].SetZero();
      for (i=0;i<(signed)sa->z.size();i++)
      {
        z = sa->z[i];
        factor = sa->d[i];
        if (scaled) factor *= pow(z,n);
        for (igp=0;igp<ngpa;igp++)
        {
          wz = 2.0*z*local_dca*cfpr[igp];
          bessel->SKMSExp(lmax,wz,besselK);
          expo = factor*exp(-z*pow(local_dca - cfpr[igp],2.0));
          for (l=0;l<=lmax;l++)
            bastab[llis+is](l,igp) += expo*besselK[l];
        }
      }
    }
    llis += gas->basis[ib]->shell.size();
  }
  delete[] besselK;
}

// Add the contribution of the ECP semi-local integrals.
// History: - Creation (25.10.05, RFM)
void ECPIntegrator::Block(GaussianShell *sa,GaussianShell *sb,Matrix a,Matrix b,double **pot,double **intblk,int nsda, int nsdb)
{
  int daopa,i,laa,na;
  int daopb,j,lbb,nb;
  int lc,lcmax;
  double **ocint;

  laa = sa->l + nsda;
  lbb = sb->l + nsdb;

  daopa = PSDAOPointer(laa);
  daopb = PSDAOPointer(lbb);
  ocint = new double*[daopa];
  for (i=0;i<daopa;i++)
    ocint[i] = new double[daopb];

  for (i=0;i<daopa;i++)
    for (j=0;j<daopb;j++)
      ocint[i][j] = 0.0;

  // Compute ECP one-center integrals 
  lcmax = gas->pps[current_potential]->LMax() - 1;
  for (lc=0;lc<=lcmax;lc++)
  {
    // Use pre-tabulation over contracted Gaussians 
    if (!SemilocalRadial(laa,lbb,lc,a,b,pot))
      SemilocalOverPrimitives(sa,sb,lc,nsda,nsdb);

    // Save the one-center integral block 
    SemilocalOneCenter(laa,lbb,lc,ocint);
  }
  

  // Evaluate the integral using the one-center blocks 
  ThreeCenter(laa,lbb,ocint,intblk);

  for (i=0;i<daopa;i++)
    delete[] ocint[i];
  delete[] ocint;

  // Angular normalization 16 pi^2 
  for (i=0;i<sa->nco;i++)
    for (j=0;j<sb->nco;j++)
      intblk[i][j] *= 16.0*X_PI*X_PI*sa->ncsto[i]*sb->ncsto[j];
}

// Perform adaptive Gauss-Chebyshev quadratures for the 
// semi-local radial part using pre-tabulated functions.
// History: - Creation (09.01.04, RFM)
bool ECPIntegrator::SemilocalRadial(int la,int lb, int lc,Matrix a, 
Matrix b, double **c)
{
  int even,l,laa,lab,lac,lbb,lbc,odd;
  double ival;
  double aa[X_MAX_NRQP],bb[X_MAX_NRQP];
  bool status,ret;
  
  lab = la + lb;
  lac = la + lc;
  lbc = lb + lc;

  even = lab/2;
  odd = (lab-1)/2;
  ret = true;

  // Gauss-Chebyshev quadrature with pre-tabulated functions 
  for (laa=0;laa<=lac;laa++)
  {
    a.GetRowValues( laa, aa ); 
    for (lbb=0;lbb<=lbc;lbb++)
    {
      b.GetRowValues( lbb, bb ); 
      // Radial integrals with even radial power 
      if (X_MOD(laa+lbb,2)==0)
      {
        for (l=0;l<=even;l++)
        {
          status = RadialQuadrature(aa,bb,c[lc],2*l,&ival);
          if (!status) ret = false;
          rint[l+l](laa,lbb) = ival;
        }
      }
      // Radial integrals with odd radial power ***
      else if (odd>=0)
      {
        for (l=0;l<=odd;l++)
        {
          if (l+l+1<=lab)
          {
            status = RadialQuadrature(aa,bb,c[lc],2*l+1,&ival);
            if (!status) ret = false;
            rint[l+l+1](laa,lbb) = ival;
          }
        }
      }
    }
  }
  return ret;
}

bool ECPIntegrator::RadialQuadrature(double *a, double *b, double *pot, int l, double *ival)
{
  int i,igp;
  double qt,qtp,qtpp,term;

  qt = 0.0;

  // (p-1)/2 points 
  for (igp=3;igp<ngpa;igp +=4)  
  {
    term = a[igp]*b[igp]*pot[igp];
    if (l>0) term *= pow(cfpr[igp],l);
    qt += term;
  }

  qtpp = 4.0*qt;

  // p points 
  for (igp=1;igp<ngpa;igp +=4)  
  {
    term = a[igp]*b[igp]*pot[igp];
    if (l>0) term *= pow(cfpr[igp],l);
    qt += term;
  }

  qtp = 2.0*qt;

  // 2p+1 points 
  for (igp=0;igp<ngpa;igp +=2)  
  {
    term = a[igp]*b[igp]*pot[igp];
    if (l>0) term *= pow(cfpr[igp],l);
    qt += term;
  }

  *ival = qt; 

  // Check convergence 
  qtp = pow(qt-qtp,2.0) - tol*X_ABS(qt- qtpp);
  if (qtp>0.0)
    if (X_ABS(qt-qtpp)>tol) return false;

  return true;
}

// Evaluate ECP one-center semi-local integral terms.
// History: - Creation (25.10.05, RFM)
void ECPIntegrator::SemilocalOneCenter(int la, int lb, int lc, double **ocint)
{
  int dlaa,laa,llkac,kac,lacmax,l1,para;
  int dlbb,lbb,llkbc,kbc,lbcmax,l2,parb;
  int is,lab,llsh,ulsh;
  double s,termint;

  lacmax = la + lc;
  lbcmax = lb + lc;
  llsh = SHP(lc,-lc);     // m = -l
  ulsh = SHP(lc,lc);      // m = l

  // Loop over polynoms derived from center A 
  for (laa=0;laa<=la;laa++)
  {
    if (laa==0)
    {
      llkac = 0;
      para = lc;
    }
    else
    {
      llkac = PSDAOPointer(laa-1);
      para = X_MAX(X_MOD(laa+lc,2),lc-laa);
    }
    dlaa = PSDAOPointer(laa);
    for (kac=llkac;kac<dlaa;kac++)
    {
      // Loop over polynoms derived from center B 
      for (lbb=0;lbb<=lb;lbb++)
      {
        lab = laa + lbb;
        if (lbb==0)
        {
          llkbc = 0;
          parb = lc;
        }
        else
        {
          llkbc = PSDAOPointer(lbb-1);
          parb = X_MAX(X_MOD(lc+lbb,2),lc-lbb);
        }
        dlbb = PSDAOPointer(lbb);
        for (kbc=llkbc;kbc<dlbb;kbc++)
        {
          termint = 0.0;
          for (l1=para;l1<=lacmax;l1+=2)
          {
            for (l2=parb;l2<=lbcmax;l2+=2)
            {
              s = 0.0;
              for (is=llsh;is<=ulsh;is++)
                s += slaa[kac](l1,is)*slab[kbc](l2,is);
              termint += rint[lab](l1,l2)*s;
            }
          }
          ocint[kac][kbc] += termint;
        }
      }
    }
  }
}

// Perform adaptive Gauss-Chebyshev quadratures for the semilocal radial part.
// History: - Creation (28.02.03, RFM)
//          - Translated to C (1.08.15, RFM)
void ECPIntegrator::SemilocalOverPrimitives(GaussianShell *sa, 
GaussianShell *sb, int lc, int nsda, int nsdb) 
{
  int gpstep,i,igp,j,lab,lac,lbc,l1,l2,l3,llgp,local_ngp,ulgp;
  double a,b,expf,expo,factora,factor,ka,kb,left,r,right,rpow,w;
  double bessela[X_MAX_L+X_MAX_L_ECPS+1];
  double besselb[X_MAX_L+X_MAX_L_ECPS+1];
  double qt[2*X_MAX_L+1][X_MAX_L+X_MAX_L_ECPS+1][X_MAX_L+X_MAX_L_ECPS+1];
  double qtp[2*X_MAX_L+1][X_MAX_L+X_MAX_L_ECPS+1][X_MAX_L+X_MAX_L_ECPS+1];
  double qtpp[2*X_MAX_L+1][X_MAX_L+X_MAX_L_ECPS+1][X_MAX_L+X_MAX_L_ECPS+1];
  double qtw[2*X_MAX_L+1][X_MAX_L+X_MAX_L_ECPS+1][X_MAX_L+X_MAX_L_ECPS+1];
  bool converged;

  cout << "Integration over primitives"<<endl;

  lab = sa->l + sb->l;
  lac = sa->l + lc;
  lbc = sb->l + lc;

  for (l1=0;l1<=lab;l1++)
    for (l2=0;l2<=lac;l2++)
      for (l3=0;l3<=lbc;l3++)
        rint[l1](l2,l3) = 0.0;

  for (i=0;i<(signed)sa->z.size();i++)
  {
    ka = 2.0*dca*sa->z[i];
    factora = sa->d[i];
    if (nsda>0) factora *= pow(sa->z[i],nsda);
    for (j=0;j<(signed)sb->z.size();j++)
    {
      // Linear mapping 
      InitializeMapping(sa->z[i],sb->z[j],&a,&b);

      kb = 2.0*dcb*sb->z[j];
      factor = factora*sb->d[j];
      if (nsdb>0) factor *= pow(sb->z[j],nsdb);
      local_ngp = ((ngp - 1)/2 - 1)/2;
      llgp = int(pow(2,ncycmax-1));
      ulgp = ngpmax - llgp + 1;
      gpstep = llgp;

      for (l1=0;l1<=lab;l1++)
        for (l2=0;l2<=lac;l2++)
          for (l3=0;l3<=lbc;l3++) 
          {
            qt[l1][l2][l3] = 0.0;
            qtp[l1][l2][l3] = 0.0;
            qtpp[l1][l2][l3] = 0.0;
            qtw[l1][l2][l3] = 0.0;
          }

      converged = false;
      while (!converged) 
      {
        for (igp=llgp-1;igp<ulgp;igp+=gpstep)
        {
          Map(a,b,x[igp],wx[igp],&r,&w);
          expo = - sa->z[i]*pow(dca-r,2.0) - sb->z[j]*pow(dcb-r,2.0);
          if (expo>=minexp)
          {
            bessel->SKMSExp(lac,ka*r,bessela);
            bessel->SKMSExp(lbc,kb*r,besselb);
            expf = factor*w*exp(expo);
            expf *= SemilocalPotential(r,lc);
            for (l1=0;l1<=lab;l1++)
            {
              if (l1==0) rpow = expf;
              else rpow *= r;
              for (l2=0;l2<=lac;l2++)
                for (l3=0;l3<=lbc;l3++)
                {
                  if (X_MOD(l2+l3,2)==X_MOD(l1,2))
                    qtw[l1][l2][l3] += rpow*bessela[l2]*besselb[l3];
                }
            }
          }
        }
        for (l1=0;l1<=lab;l1++)
          for (l2=0;l2<=lac;l2++)
            for (l3=0;l3<=lbc;l3++)
            {
              if (X_MOD(l2+l3,2)==X_MOD(l1,2))
              {
                qtpp[l1][l2][l3] = qtp[l1][l2][l3];
                qtp[l1][l2][l3] = qt[l1][l2][l3];
                qt[l1][l2][l3] = double(llgp)*qtw[l1][l2][l3];
              }
            }
        if (local_ngp>=ngp) 
        {
          converged = true;
          for (l1=0;l1<=lab;l1++)
            for (l2=0;l2<=lac;l2++)
              for (l3=0;l3<=lbc;l3++)
              {
                if (X_MOD(l2+l3,2)==X_MOD(l1,2))
                {
                  left = pow(qt[l1][l2][l3] - qtp[l1][l2][l3],2.0);
                  right = X_ABS(qt[l1][l2][l3] - qtpp[l1][l2][l3]);
                  if (left>tol*right)
                  {
                    if (right>tol)
                    {
                      converged = false;
                      goto MIL;
                    }
                  }
                }
              }
MIL:
            cout << "ECP q: "<<left<<"  "<<right<<endl;
          if ((local_ngp==ngpmax)&&(!converged)) 
          {
            cout << "ECP quadrature failed: "<<left<<"  "<<right<<endl;
            break;
          }
        }
        local_ngp  = 2*local_ngp + 1;
        gpstep = llgp;
        llgp = llgp/2;
        ulgp = ngpmax - llgp + 1;
      }

      for (l1=0;l1<=lab;l1++)
        for (l2=0;l2<=lac;l2++)
          for (l3=0;l3<=lbc;l3++)
            if (X_MOD(l2+l3,2)==X_MOD(l1,2))
              rint[l1](l2,l3) += qt[l1][l2][l3];
    }
  }
}

double ECPIntegrator::SemilocalPotential(double r, int lc)
{
  int igp,ks;
  double vlm;
  GaussianShell *sc;

  vlm = 0.0;

  // Loop over all (semi-local) ECP shells 
  for (ks=0;ks<(signed)gas->pps[current_potential]->shell.size();ks++)
  {
    sc = gas->pps[current_potential]->shell[ks];
    if ((sc->type==SEMILOCAL_ECP_SHELL)&&(sc->l==lc))
      vlm += sc->RadialPotential(r)*pow(r,double(sc->n+2));
  }
  return vlm;
}


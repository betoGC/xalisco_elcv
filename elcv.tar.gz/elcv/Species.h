/*
This file is part of Xalisco 120.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#ifndef X_SPECIES_H
#define X_SPECIES_H

#include <fstream>

#include <Parameter.h>

using namespace std;

class Species
{
  public:
    Species(char*);

    char name[X_MAX_STR_SIZE];               // Label: Chemical formula
    double concentration;                    // Molarity
    double concentration_shift;       
    double diffusion_coefficient;            // cm^2 s^-1

    bool IsElectron(void);
    char* Name(void);
    double Concentration(void);
    double DiffusionCoefficient(void);
    void SetName(char*);
    void SetConcentration(double);
    void SetConcentrationShift(double);
    void SetDiffusionCoefficient(double);
    void ShiftConcentration(double);
    void ChangeConcentrationShift(double);
    void Write(ofstream*);
};

#endif

/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <stdlib.h>

#include <iostream>
#include <iomanip>

#include <SCF.h>   
#include <QChem.h>
#include <System.h>
#include <Math.h>
#include <GaussianGas.h>
#include <Molecular.h>
#include <ADFT.h>
#include <Time.h>

using namespace std;

SCF::SCF(QChem *iqchem)
{
  qchem = iqchem;
  sys = qchem->sys;
  atomic = false;
  mixing = 1.0;
  constrain_last_atom = -1;
  constrain_number = 0.0; 
  constrain_lambda = 0.0; 
  constrain_particle_type = ELECTRON; 
  constrain_matrix = 0;

  for (int itype=0;itype<NTYPES;itype++)
    projected[itype] = false;

  Setup();
}

void SCF::Setup()
{
  cycle = 0;
  error = 99999.0;
  energy = 99999.0;
  tolerance = 1.0e-6;

  if (constrain_last_atom>=0) constrain_lambda = 0.0;
}

void SCF::Step()
{
  int ig,jg,source;
  double penergy;

  cycle++;

  penergy = energy;

  energy = 0.0;

  // Load core matrix
  for (ig=0;ig<sys->ngas;ig++)
  {
    sys->gas[ig]->F->Copy(sys->gas[ig]->H);  
    energy += 0.5*sys->gas[ig]->F->QTrace(sys->gas[ig]->P);
  }

  for (ig=0;ig<sys->ngas;ig++)
  {
    source = sys->gas[ig]->copy_source;
    if (source<0)
    {
      for (jg=0;jg<sys->ngas;jg++)
      {
        if (sys->qchem->adft)
        {
          sys->gas[ig]->TwoParticleMatrixDF(
            sys->gas[ig]->F,sys->gas[jg],sys->gas[jg]->x,
            sys->gas[ig]->particle_charge*sys->gas[jg]->particle_charge);
        }
        else
        {
          if (jg==ig)  
            sys->gas[ig]->TwoParticleMatrix(sys->gas[ig]->F,sys->gas[jg],true);
          else 
            sys->gas[ig]->TwoParticleMatrix(sys->gas[ig]->F,sys->gas[jg],false);
        }
      }
      energy += 0.5*sys->gas[ig]->F->QTrace(sys->gas[ig]->P);
    }
    else
    {
      energy += 0.5*sys->gas[source]->F->QTrace(sys->gas[ig]->P);
    }
  }

  // XC
  if (qchem->adft) 
  {
    qchem->adft->PotentialAndEnergy(sys);

    for (ig=0;ig<sys->ngas;ig++)
    {
      source = sys->gas[ig]->copy_source;
      if (source<0)
        sys->gas[ig]->TwoParticleMatrixDF(
          sys->gas[ig]->F,sys->gas[ig],sys->gas[ig]->z,1.0);
    }
    energy += sys->exc;

  }


  ApplyConstrain();

  NewDensity();

  // Fitting
  if (sys->qchem->adft) 
  {
    for (ig=0;ig<sys->ngas;ig++)
    {
      source = sys->gas[ig]->copy_source;
      if (source<0)
        sys->gas[ig]->FittingCoefficients();
      else
      {
        for (int i=0;i<sys->gas[ig]->auxnco;i++)
        {
          sys->gas[ig]->x[i] = sys->gas[source]->x[i];
          sys->gas[ig]->z[i] = sys->gas[source]->z[i];
        }
      }
    }
  }

  energy += sys->mol->NuclearRepulsionEnergy();

  sys->energy = energy;

  error = penergy - energy;

  if (!atomic) sys->Print((char*)"Backup.xal");

}

void SCF::SetTolerance(double tol)
{
  tolerance = tol;
}

double SCF::Error()
{
  return error;
}

bool SCF::Converged()
{
  if (X_ABS(error)<tolerance) return true;
  else return false;
}

void SCF::SeekConvergence()
{
  int ncyc = 0;
  while (!Converged())
  {
    Step();
    cout << "SCF energy = "
         <<fixed<<setw(15)<<setprecision(6)<<sys->energy<<" Error = "
         <<fixed<<setw(15)<<setprecision(8)<<Error()<<endl;
    ncyc++;
    if (ncyc>1000) break;
  } 
}

void SCF::SetupConstrain()
{
  int ig,nco;

  // Quick return if not constrain requested
  if (sys->qchem->scf->constrain_last_atom<0) return;

  constrain_lambda = 0.0;

  for (ig=0;ig<sys->ngas;ig++)
    if (sys->gas[ig]->type==constrain_particle_type) 
      nco = sys->gas[ig]->nco;

  if (constrain_matrix) delete constrain_matrix;
  constrain_matrix = new Matrix(nco,nco);
  constrain_matrix->SetZero();

  Matrix *P0 = new Matrix(nco,nco);

  sys->qchem->EvaluatePromolecularDensity(P0);
  DFT *dft = new DFT(sys->qchem,(char*)"None-None");
  for (ig=0;ig<sys->ngas;ig++)
  {
    if (sys->gas[ig]->type==constrain_particle_type) 
    {
      dft->HirshfeldMatrix(P0,constrain_matrix,sys->gas[ig]->basis,0,constrain_last_atom);
      break;
    }
  }

  delete dft;
  delete P0;
}

void SCF::ApplyConstrain()
{
  int ig,nco,nit;
  int aptr,bptr;
  bool bisect;
  double d1,d2,delta;
  double eshift;
  double lam[1002],old[1002];

  // Quick return if not constrain requested
  if (sys->qchem->scf->constrain_last_atom<0) return;
  if (sys->mol->Natom()<2) return;
  if (cycle<=1) return;

  for (ig=0;ig<sys->ngas;ig++)
  {
    if (sys->gas[ig]->type==constrain_particle_type) 
      nco = sys->gas[ig]->nco;
  }

  //Backup
  for (ig=0;ig<sys->ngas;ig++)
  {
    if (sys->gas[ig]->type==constrain_particle_type) 
      sys->gas[ig]->P1->Copy(sys->gas[ig]->F);
  }

  bisect = false;
  for (nit=1;nit<1000;nit++)
  {
    d1 = 0.0;
    for (ig=0;ig<sys->ngas;ig++)
    {
      if (sys->gas[ig]->type==constrain_particle_type) 
        d1 += constrain_matrix->QTrace(sys->gas[ig]->P);
    }
    d1 -= constrain_number; 

    lam[nit] = constrain_lambda;
    old[nit] = d1;

    if (!(bisect)) 
    {
      if (nit>1)
      {
        if (((old[nit]<0.0)&&(old[nit-1]>0.0))||
            ((old[nit]>0.0)&&(old[nit-1]<0.0)))
        {
          aptr = nit;
          bptr = nit - 1;
          bisect = true;
        }
      }
    }

    if (bisect) 
    {
      if (((old[nit]<0.0)&&(old[aptr]<0.0))||
          ((old[nit]>0.0)&&(old[aptr]>0.0))) aptr = nit;
      else bptr = nit;
      delta = 0.5*(lam[aptr] + lam[bptr])-constrain_lambda;
    }
    else
    {
      d2 = 0.0;
      for (ig=0;ig<sys->ngas;ig++)
      {
        if (sys->gas[ig]->type==constrain_particle_type) 
        {
          sys->gas[ig]->F->Copy(constrain_matrix);
          sys->gas[ig]->McWeeny(sys->gas[ig]->F);
          d2 -= sys->gas[ig]->F->QTrace(constrain_matrix);
        }
      }
      cout << "D2 = "<<d2<<endl;
      delta = -d1/d2;
      if (delta>0.1) delta = 0.1;
      else if (delta<-0.1) delta = -0.1;
    }

    constrain_lambda += delta;
    eshift = -constrain_lambda*d1;
    cout << nit<< " D1 = "<<d1<< " lambda = "<<constrain_lambda<<endl;
    for (ig=0;ig<sys->ngas;ig++)
    {
      if (sys->gas[ig]->type==constrain_particle_type) 
      {
        sys->gas[ig]->F->Copy(sys->gas[ig]->P1);
        if (constrain_lambda!=0.0)
        {
          constrain_matrix->Scale(-constrain_lambda);
          sys->gas[ig]->F->Add(constrain_matrix,0,0);
          constrain_matrix->Scale(-1.0/constrain_lambda);
        }
      }
    }
    NewDensity();
    if (X_ABS(delta*d1)<X_MIN(1.0e-6,X_ABS(error))) break;
  }

  // Make sure to release modified matrix properly
  for (ig=0;ig<sys->ngas;ig++)
  {
    if (sys->gas[ig]->type==constrain_particle_type) 
    {
      sys->gas[ig]->F->Copy(sys->gas[ig]->P1);
      if ((X_ABS(delta*d1)<X_MIN(1.0e-6,X_ABS(error)))&&
          (constrain_lambda!=0.0)) 
      {
        constrain_matrix->Scale(-constrain_lambda);
        sys->gas[ig]->F->Add(constrain_matrix,0,0);
        constrain_matrix->Scale(-1.0/constrain_lambda);
      }
      else
      {
        constrain_lambda = 0.0;
      }
    }
  }
}

void SCF::NewDensity()
{
  int ig,source;

  // RHF
  for (ig=0;ig<sys->ngas;ig++)
  {
    source = sys->gas[ig]->copy_source;
    if (source<0)
      sys->gas[ig]->NewMOs(projected[sys->gas[ig]->type]);
    else
    {
      sys->gas[ig]->C->Copy(sys->gas[source]->C);
      for (int i=0;i<sys->gas[ig]->nco;i++)
        sys->gas[ig]->energies[i] = sys->gas[source]->energies[i];
    }
  }

  // New density
  for (ig=0;ig<sys->ngas;ig++)
  {
    source = sys->gas[ig]->copy_source;
    if (source<0)
    {
      if (cycle==1) sys->gas[ig]->SCFDensityMatrix(1.0);
      else sys->gas[ig]->SCFDensityMatrix(mixing);
    }
    else sys->gas[ig]->P->Copy(sys->gas[source]->P);
  }
}

/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

// Master object for Quantum Chemistry calculations
#ifndef X_QCHEM_H
#define X_QCHEM_H

#include <Parameter.h>
#include <Matrix.h>

class System;
class SCF;
class ADFT;

class QChem
{
  public:

    QChem(System*);

    System* sys;
    SCF *scf;
    ADFT *adft;

    double temperature;
    double chemical_potential;

    void Setup();
    void Polarizability(Matrix);
    void EvaluatePromolecularDensity(Matrix*);
    void ChangeBasis(char*,int);
    void ChangePseudos(char*,int);
    void ChangeMethod(char*,int);
    void ChangeGuess(char*,int);
    void ChangeRestricted(int);
    void ChangeProjected(int);
    void ChangeDirect(int);
    double SCFEnergy(void);
    double MP2Energy(void);

    char basname[NTYPES][X_MAX_STR_SIZE];
    char potname[NTYPES][X_MAX_STR_SIZE];
    char method[NTYPES][X_MAX_STR_SIZE];
    char guess[NTYPES][X_MAX_STR_SIZE];
    bool restricted[NTYPES];
    bool direct[NTYPES];
};

#endif // X_QCHEM_H

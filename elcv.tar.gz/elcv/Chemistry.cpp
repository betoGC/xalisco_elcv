/*
This file is part of Xalisco software.

    Xalisco is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Xalisco is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Xalisco.  If not, see <http://www.gnu.org/licenses/>.

    Cite as follows:

    R. Flores-Moreno, A. Venegas-Reynoso, Xalisco 120, Guadalajara Jal. (2016)
*/

#include <iostream>

#include <Chemistry.h>
#include <Species.h>
#include <Reaction.h>
#include <Random.h>
#include <Math.h>

using namespace std;

Chemistry::Chemistry()
{
  specie.clear();
  reaction.clear();
  random = new Random();
}

int Chemistry::NumberOfSpecies()
{
  return specie.size();
}

int Chemistry::NumberOfReactions()
{
  return reaction.size();
}

void Chemistry::AddSpecies(char* name, double c, double d)
{
  specie.push_back( new Species( name ) );
  specie[specie.size()-1]->SetConcentration( c );
  specie[specie.size()-1]->SetDiffusionCoefficient( d );
}

void Chemistry::AddReaction( Reaction *rxn )
{
  reaction.push_back( new Reaction( *rxn ) );
}

// Run evolution simulation for chemical reaction
// Roberto Flores-Moreno (Oct 2014, Jul 2015)
void Chemistry::Evolve(double temperature,double voltage, double tmax,
double *charge_collected, bool has_electrode)
{
  int i,nav;
  double r,t;
  double time_step;
  double *weight;
  int nrxns = reaction.size();
  //Se inicializan los shifts de todas las especies
  for (i=0;i<(signed)specie.size();i++)
    specie[i]->SetConcentrationShift( 0.0 );

  if (!has_electrode)
  {
    nav = nrxns;
    for (i=0;i<nrxns;i++)
      if (reaction[i]->IsHeterogeneous()) nav--;
    if (nav<=0) return;
  }
  // Apagamos esto del estocastico
  for (i=0;i<nrxns;i++)
  {
    reaction[i]->Advance(temperature,voltage,tmax,has_electrode);
  }
  for (i=0;i<(signed)specie.size();i++)
  {
    specie[i]->ShiftConcentration( specie[i]->concentration_shift );
    specie[i]->SetConcentrationShift( 0.0 );
  }

  if (has_electrode)
  {
    for (i=0;i<(signed)specie.size();i++)
    {
      if (specie[i]->IsElectron())
      {
        *charge_collected += specie[i]->Concentration();
        specie[i]->SetConcentration( 0.0 ); 
      }
    }
  }
}

void Chemistry::Write(char* filename)
{
  size_t i,ns,nr;

  ofstream f(filename);

  ns = specie.size();
  f << "==========================================="<<endl;
  f << "Number of species: "<<ns<<endl;
  f << endl;
  for (i=0;i<ns;i++)
    specie[i]->Write(&f);
  
  nr = reaction.size();
  f << "==========================================="<<endl;
  f << "Number of reactions: "<<nr<<endl;
  f << endl;
  for (i=0;i<nr;i++)
  {
    reaction[i]->Write(&f);
    f <<endl;
  }

  f.close();
}


